/* ================================================================
   rpds.c  --  Research Publication Database System (RPDS) v6.0
   Department of Mechanical Engineering, BUET
   Console Application -- Plain-text pipe-delimited data files

   HOW TO BUILD IN CODE::BLOCKS
   ---------------------------------------------------------------
   1. File > New > Project > Console Application > C
   2. Delete the auto-generated main.c
   3. Project > Add Files > select rpds.c
   4. Build > Build & Run (F9)

   HOW TO BUILD FROM COMMAND LINE
   ---------------------------------------------------------------
   gcc -o rpds rpds.c -Wall

   DATA FILES  (placed next to rpds.exe)
   ---------------------------------------------------------------
   faculty.txt           -- faculty records (formatted table)
   publications.txt      -- publication records (formatted table)
   undo_faculty.txt      -- undo snapshot
   undo_publications.txt
   history.txt           -- activity log
   reports/              -- generated report .txt files

   ANSI hyperlinks are used for faculty profile URLs and
   publication URLs in terminals that support OSC-8 sequences
   (Windows Terminal, most modern Linux terminals).
   ================================================================ */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>

#ifdef _WIN32
  #include <direct.h>
  #include <conio.h>
  #define MKDIR(p)   _mkdir(p)
  #define CLEAR_CMD  "cls"
  /* Enable VT100 / ANSI on Windows 10+ */
  #include <windows.h>
  static void enable_ansi(void){
      HANDLE h=GetStdHandle(STD_OUTPUT_HANDLE);
      DWORD m=0; GetConsoleMode(h,&m);
      SetConsoleMode(h,m|ENABLE_VIRTUAL_TERMINAL_PROCESSING);
  }
#else
  #include <sys/stat.h>
  #include <unistd.h>
  #define MKDIR(p)   mkdir((p),0755)
  #define CLEAR_CMD  "clear"
  static void enable_ansi(void){}
#endif

/* ================================================================
   CONSTANTS
   ================================================================ */
#define MAX_FACULTY        200
#define MAX_PUBS           500
#define MAX_RA             10
#define MAX_AUTHORS        10
#define MAX_STR            256
#define MAX_TITLE          512
#define MAX_HIST           2000
#define MAX_LOGIN_TRIES    3     /* wrong creds before 15s lockout */
#define LOCKOUT_SECS       15
#define BAR_WIDTH          40

/* Data files */
#define FACULTY_FILE      "faculty.txt"
#define PUB_FILE          "publications.txt"
#define UNDO_FAC_FILE     "undo_faculty.txt"
#define UNDO_PUB_FILE     "undo_publications.txt"
#define HISTORY_FILE      "history.txt"
#define REPORTS_DIR       "reports"

/* ================================================================
   DATA STRUCTURES
   ================================================================ */
typedef struct {
    char id[MAX_STR];
    char sn[MAX_STR];
    char full_name[MAX_STR];
    char desi[MAX_STR];
    char ra[MAX_RA][MAX_STR];
    int  ra_count;
    char profile_url[MAX_TITLE];
    char last_edited_by[MAX_STR];
    char last_edited_at[MAX_STR];
} Faculty;

typedef struct {
    char title[MAX_TITLE];
    char year[MAX_STR];
    char type[MAX_STR];
    char authors[MAX_AUTHORS][MAX_STR];
    int  author_count;
    char journal[MAX_TITLE];
    char url[MAX_TITLE];
    char indexing[MAX_STR];
    int  citations;
    char last_edited_by[MAX_STR];
    char last_edited_at[MAX_STR];
} Publication;

/* ================================================================
   GLOBALS
   ================================================================ */
static Faculty     g_fac[MAX_FACULTY];
static int         g_fac_count  = 0;
static Publication g_pub[MAX_PUBS];
static int         g_pub_count  = 0;
static char        g_admin[MAX_STR] = "";
static int         g_attempts        = 0;
static time_t      g_locked_until    = 0;

static const char *ADMIN_IDS[6] =
    {"admin-1","admin-2","admin-3","admin-4","admin-5","admin-6"};
static const char *ADMIN_PWD[6] =
    {"jannat67","abiba68","nirob69","hridoy70","rahat71","nafis72"};

/* ================================================================
   STRING HELPERS
   ================================================================ */
static void trim(char *s)
{
    char *p=s;
    while(isspace((unsigned char)*p)) p++;
    if(p!=s) memmove(s,p,strlen(p)+1);
    int n=(int)strlen(s);
    while(n>0&&isspace((unsigned char)s[n-1])) s[--n]='\0';
}

static void str_upper(char *s)
{ for(;*s;s++) *s=(char)toupper((unsigned char)*s); }

static void to_title_case(char *s)
{
    int nw=1;
    for(;*s;s++){
        if(isspace((unsigned char)*s))      nw=1;
        else if(nw){*s=(char)toupper((unsigned char)*s);nw=0;}
        else         *s=(char)tolower((unsigned char)*s);
    }
}

static int str_ieq(const char *a,const char *b)
{
    char ca[MAX_TITLE],cb[MAX_TITLE];
    strncpy(ca,a,MAX_TITLE-1); ca[MAX_TITLE-1]='\0';
    strncpy(cb,b,MAX_TITLE-1); cb[MAX_TITLE-1]='\0';
    str_upper(ca); str_upper(cb);
    return strcmp(ca,cb)==0;
}

static int str_ihas(const char *hay,const char *ndl)
{
    char h[MAX_TITLE],n[MAX_TITLE];
    if(!ndl||!ndl[0]) return 1;
    strncpy(h,hay,MAX_TITLE-1); h[MAX_TITLE-1]='\0';
    strncpy(n,ndl,MAX_TITLE-1); n[MAX_TITLE-1]='\0';
    str_upper(h); str_upper(n);
    return strstr(h,n)!=NULL;
}

static void now_str(char *buf)
{
    time_t t=time(NULL);
    struct tm *tm=localtime(&t);
    strftime(buf,MAX_STR,"%Y-%m-%d %H:%M:%S",tm);
}

#define SCOPY(dst,src) do{strncpy((dst),(src),sizeof(dst)-1);(dst)[sizeof(dst)-1]='\0';}while(0)

/* ================================================================
   PIPE-FIELD HELPERS
   ================================================================ */
static int next_field(const char **ln, char *out, int sz)
{
    out[0]='\0';
    if(!*ln||!**ln) return 0;
    const char *s=*ln, *e=strchr(s,'|');
    if(e){ int n=(int)(e-s); if(n>sz-1)n=sz-1; strncpy(out,s,n); out[n]='\0'; *ln=e+1; }
    else { strncpy(out,s,sz-1); out[sz-1]='\0'; *ln=s+strlen(s); }
    trim(out); return 1;
}

static int split_list(const char *s, char items[][MAX_STR], int mx)
{
    int c=0; char cp[MAX_TITLE];
    strncpy(cp,s,MAX_TITLE-1); cp[MAX_TITLE-1]='\0';
    int n=(int)strlen(cp);
    while(n>0&&cp[n-1]==';') cp[--n]='\0';
    if(!cp[0]) return 0;
    char *t=strtok(cp,";");
    while(t&&c<mx){ trim(t); if(t[0]){strncpy(items[c],t,MAX_STR-1);items[c][MAX_STR-1]='\0';c++;} t=strtok(NULL,";"); }
    return c;
}

static void join_list(char items[][MAX_STR], int c, char *out, int sz)
{
    out[0]='\0';
    for(int i=0;i<c;i++){
        if(i>0) strncat(out,";",sz-strlen(out)-1);
        strncat(out,items[i],sz-strlen(out)-1);
    }
}

/* ================================================================
   DISPLAY / UI HELPERS
   ================================================================ */
static void clrscr(void) { system(CLEAR_CMD); }
static void hr(void)     { printf("----------------------------------------------------------------\n"); }
static void hr2(void)    { printf("================================================================\n"); }

static void section(const char *t){ hr2(); printf("  %s\n",t); hr2(); }

/* Fixed-width column -- never truncates with '+', just cuts */
static void pcol(const char *s, int w)
{
    int n=(int)strlen(s);
    if(n<=w){ printf("%s",s); for(int i=n;i<w;i++) putchar(' '); }
    else     { for(int i=0;i<w;i++) putchar(s[i]); }
}

/* Prompt: returns 1 if non-empty */
static int prompt(const char *lbl, char *buf, int sz)
{
    printf("  %-30s: ",lbl); fflush(stdout);
    if(!fgets(buf,sz,stdin)){buf[0]='\0';return 0;}
    int n=(int)strlen(buf);
    if(n>0&&buf[n-1]=='\n') buf[n-1]='\0';
    n=(int)strlen(buf);
    if(n>0&&buf[n-1]=='\r') buf[n-1]='\0';
    trim(buf); return buf[0]!='\0';
}

static void read_password(char *buf, int sz)
{
    printf("  %-30s: ","Password"); fflush(stdout);
#ifdef _WIN32
    int i=0,c;
    while(i<sz-1){
        c=_getch();
        if(c=='\r'||c=='\n') break;
        if((c=='\b'||c==127)&&i>0){i--;printf("\b \b");fflush(stdout);continue;}
        if(c<32) continue;
        buf[i++]=(char)c; printf("*"); fflush(stdout);
    }
    buf[i]='\0'; printf("\n");
#else
    if(!fgets(buf,sz,stdin)){buf[0]='\0';return;}
    int n=(int)strlen(buf);
    if(n>0&&buf[n-1]=='\n') buf[n-1]='\0';
    printf("\n");
#endif
}

/* Read a single raw line (no prompt text) */
static void read_line(char *buf, int sz)
{
    if(!fgets(buf,sz,stdin)){buf[0]='\0';return;}
    int n=(int)strlen(buf);
    if(n>0&&buf[n-1]=='\n') buf[n-1]='\0';
    n=(int)strlen(buf);
    if(n>0&&buf[n-1]=='\r') buf[n-1]='\0';
    trim(buf);
}

static void pause_enter(void)
{
    printf("\n  Press Enter to continue..."); fflush(stdout);
    int c; while((c=getchar())!='\n'&&c!=EOF);
}

static void pause_any_key(void)
{
    printf("\n  Press any key to exit..."); fflush(stdout);
#ifdef _WIN32
    _getch();
#else
    getchar();
#endif
}

/* Countdown timer printed on the SAME LINE, overwriting in place.
   Prints: "  Please wait XX seconds." and counts down to 0.       */
static void countdown(int secs)
{
    for(int s=secs; s>=0; s--){
        printf("\r  Please wait %2d second(s)...  ", s);
        fflush(stdout);
        if(s>0){
#ifdef _WIN32
            Sleep(1000);
#else
            sleep(1);
#endif
        }
    }
    printf("\n");
}

/* ================================================================
   ANSI OSC-8 HYPERLINK helpers
   Prints: ESC ] 8 ; ; url ST  display_text  ESC ] 8 ; ; ST
   Falls back to plain text if url is empty.
   ================================================================ */


/* Print a hyperlink in a fixed-width column using ANSI OSC-8 */
static void pcol_link(const char *display, const char *url, int w)
{
    int n=(int)strlen(display);
    if(url && url[0]){
        printf("\033]8;;%s\033\\", url);
        if(n<=w){ printf("%s",display); for(int i=n;i<w;i++) putchar(' '); }
        else     { for(int i=0;i<w;i++) putchar(display[i]); }
        printf("\033]8;;\033\\");
    } else {
        pcol(display, w);
    }
}

/* Write a cell to a file table with word-wrap continuation rows */

/* Print a table border row given array of column widths, n cols */
static void tbl_border(const int *cw, int nc)
{
    printf("  +");
    for(int i=0;i<nc;i++){ for(int j=0;j<cw[i]+2;j++) putchar('-'); putchar('+'); }
    printf("\n");
}

/* Print a plain table row */
static void tbl_row_plain(const char **cells, const int *cw, int nc);  /* forward decl */

/* Print a hyperlink in a fixed-width column using ANSI OSC-8 */

/* Write exactly w chars of s to file, padding with spaces */
static void fwrite_col(FILE *f, const char *s, int w)
{
    int n=(int)strlen(s);
    if(n>w) n=w;
    for(int i=0;i<n;i++) fputc(s[i],f);
    for(int i=n;i<w;i++) fputc(' ',f);
}

/* First-chunk word-wrap size: how many chars fit in width w with word-break */
static int first_chunk_w(const char *s, int w)
{
    int len=(int)strlen(s);
    if(len<=w) return len;
    int k=w; while(k>0&&s[k]!=' ') k--;
    return (k>0)?k:w;
}

static void tbl_row_plain(const char **cells, const int *cw, int nc)
{
    printf("  |");
    for(int i=0;i<nc;i++){ printf(" "); pcol(cells[i],cw[i]); printf(" |"); }
    printf("\n");
}

/* tbl_row with ANSI links for specified columns.
   link_col: index of col that gets a link, or -1 for none.
   link_url: the URL to embed.                                */
/* Wrap a long string into multiple lines, each fitting 'w' chars,
   printing continuation lines with 'indent' leading spaces.
   Returns number of lines printed. */
/* File-based table helpers (for reports) */
static void ftbl_border(FILE *f, const int *cw, int nc)
{
    fprintf(f,"  +");
    for(int i=0;i<nc;i++){ for(int j=0;j<cw[i]+2;j++) fputc('-',f); fputc('+',f); }
    fprintf(f,"\n");
}

static void ftbl_row(FILE *f, const char **cells, const int *cw, int nc)
{
    fprintf(f,"  |");
    for(int i=0;i<nc;i++){
        fprintf(f," ");
        int len=(int)strlen(cells[i]);
        if(len<=cw[i]){ fprintf(f,"%s",cells[i]); for(int j=len;j<cw[i];j++) fputc(' ',f); }
        else           { for(int j=0;j<cw[i];j++) fputc(cells[i][j],f); }
        fprintf(f," |");
    }
    fprintf(f,"\n");
}

/* ASCII bar chart */
static void bar_chart(const char *lbl, int val, int mx, int bw)
{
    int f=(mx>0)?(val*bw/mx):0;
    printf("  %-38s | ",lbl);
    for(int i=0;i<f;i++) putchar('#');
    for(int i=f;i<bw;i++) putchar('.');
    printf(" | %d\n",val);
}

/* ================================================================
   SAVE / LOAD
   The text files are now formatted as human-readable tables.
   The pipe-delimited data rows are preceded by a decorative header.
   Loading still uses the pipe-delimited parser (ignores # lines).
   ================================================================ */
static void save_fac_to(const char *path)
{
    FILE *f=fopen(path,"w");
    if(!f){fprintf(stderr,"ERROR: Cannot write %s\n",path);return;}

    /* Compute dynamic column widths from actual data */
    int w_id=2, w_sn=2, w_name=9, w_desi=11, w_ra=16, w_url=11;
    for(int i=0;i<g_fac_count;i++){
        Faculty *m=&g_fac[i];
        char ra_str[MAX_TITLE]="";
        for(int r=0;r<m->ra_count;r++){
            if(r>0) strncat(ra_str," / ",sizeof(ra_str)-strlen(ra_str)-1);
            strncat(ra_str,m->ra[r],sizeof(ra_str)-strlen(ra_str)-1);
        }
        int n;
        n=(int)strlen(m->id);           if(n>w_id)   w_id=n;
        n=(int)strlen(m->sn);           if(n>w_sn)   w_sn=n;
        n=(int)strlen(m->full_name);    if(n>w_name) w_name=n;
        n=(int)strlen(m->desi);         if(n>w_desi) w_desi=n;
        n=(int)strlen(ra_str);          if(n>w_ra)   w_ra=n;
        n=(int)strlen(m->profile_url);  if(n>w_url)  w_url=n;
    }

    /* Header */
    fprintf(f,"# ================================================================\n");
    fprintf(f,"# RPDS Faculty Data  --  Department of Mechanical Engineering, BUET\n");
    fprintf(f,"# Fields: ID|SN|FullName|Designation|ResearchAreas(;sep)|ProfileURL|EditedBy|EditedAt\n");
    fprintf(f,"# ----------------------------------------------------------------\n");
    /* Decorative table header using actual widths */
    fprintf(f,"# %-*s | %-*s | %-*s | %-*s | %-*s | %-*s\n",
            w_id,"ID", w_sn,"SN", w_name,"Full Name",
            w_desi,"Designation", w_ra,"Research Area(s)", w_url,"Profile URL");
    /* Separator row */
    fprintf(f,"# ");
    for(int k=0;k<w_id;  k++) fputc('-',f);
    fprintf(f," | ");
    for(int k=0;k<w_sn;  k++) fputc('-',f);
    fprintf(f," | ");
    for(int k=0;k<w_name;k++) fputc('-',f);
    fprintf(f," | ");
    for(int k=0;k<w_desi;k++) fputc('-',f);
    fprintf(f," | ");
    for(int k=0;k<w_ra;  k++) fputc('-',f);
    fprintf(f," | ");
    for(int k=0;k<w_url; k++) fputc('-',f);
    fprintf(f,"\n");

    for(int i=0;i<g_fac_count;i++){
        Faculty *m=&g_fac[i];
        char ra_str[MAX_TITLE]="";
        join_list(m->ra,m->ra_count,ra_str,sizeof(ra_str));
        fprintf(f,"%s|%s|%s|%s|%s|%s|%s|%s\n",
                m->id,m->sn,m->full_name,m->desi,ra_str,
                m->profile_url,m->last_edited_by,m->last_edited_at);
    }
    fprintf(f,"# ----------------------------------------------------------------\n");
    fprintf(f,"# Total records: %d\n",g_fac_count);
    fclose(f);
}

static void load_fac_from(const char *path)
{
    g_fac_count=0;
    FILE *f=fopen(path,"r"); if(!f) return;
    char line[MAX_TITLE*4];
    while(fgets(line,sizeof(line),f)){
        int n=(int)strlen(line);
        while(n>0&&(line[n-1]=='\n'||line[n-1]=='\r')) line[--n]='\0';
        if(line[0]=='#'||line[0]=='\0') continue;
        Faculty m; memset(&m,0,sizeof(m));
        const char *p=line;
        char ra_str[MAX_TITLE]="";
        next_field(&p,m.id,sizeof(m.id));
        next_field(&p,m.sn,sizeof(m.sn));
        next_field(&p,m.full_name,sizeof(m.full_name));
        next_field(&p,m.desi,sizeof(m.desi));
        next_field(&p,ra_str,sizeof(ra_str));
        next_field(&p,m.profile_url,sizeof(m.profile_url));
        next_field(&p,m.last_edited_by,sizeof(m.last_edited_by));
        next_field(&p,m.last_edited_at,sizeof(m.last_edited_at));
        m.ra_count=split_list(ra_str,m.ra,MAX_RA);
        if(m.id[0]&&g_fac_count<MAX_FACULTY) g_fac[g_fac_count++]=m;
    }
    fclose(f);
}

static void save_pub_to(const char *path)
{
    FILE *f=fopen(path,"w");
    if(!f){fprintf(stderr,"ERROR: Cannot write %s\n",path);return;}

    fprintf(f,"# ================================================================\n");
    fprintf(f,"# RPDS Publications Data  --  Department of Mechanical Engineering, BUET\n");
    fprintf(f,"# ================================================================\n");
    fprintf(f,"# Fields (pipe-delimited):\n");
    fprintf(f,"#   Title | Year | Type | Authors(;sep) | Journal | URL |\n");
    fprintf(f,"#   Indexing | Citations | LastEditedBy | LastEditedAt\n");
    fprintf(f,"# ----------------------------------------------------------------\n");

    /* Compute dynamic widths from actual data */
    int pw_num=1, pw_title=5, pw_year=4, pw_type=4,
        pw_auth=9, pw_jour=7, pw_idx=8, pw_cit=3;
    for(int i=0;i<g_pub_count;i++){
        Publication *p=&g_pub[i];
        char auth_str2[MAX_TITLE]="";
        join_list((char(*)[MAX_STR])p->authors,p->author_count,auth_str2,sizeof(auth_str2));
        char num2[16]; snprintf(num2,sizeof(num2),"%d",i+1);
        char cit2[8]; snprintf(cit2,sizeof(cit2),"%d",p->citations);
        int n;
        n=(int)strlen(num2);       if(n>pw_num)   pw_num=n;
        n=(int)strlen(p->title);   if(n>pw_title) pw_title=n;
        n=(int)strlen(p->year);    if(n>pw_year)  pw_year=n;
        n=(int)strlen(p->type);    if(n>pw_type)  pw_type=n;
        n=(int)strlen(auth_str2);  if(n>pw_auth)  pw_auth=n;
        n=(int)strlen(p->journal); if(n>pw_jour)  pw_jour=n;
        n=(int)strlen(p->indexing);if(n>pw_idx)   pw_idx=n;
        n=(int)strlen(cit2);       if(n>pw_cit)   pw_cit=n;
    }
    if(pw_title>60) pw_title=60;
    if(pw_jour >40) pw_jour =40;
    if(pw_auth >20) pw_auth =20;

    fprintf(f,"# %-*s | %-*s | %-*s | %-*s | %-*s | %-*s | %-*s | %-*s\n",
            pw_num,"#", pw_title,"Title", pw_year,"Year", pw_type,"Type",
            pw_auth,"Author(s)", pw_jour,"Journal", pw_idx,"Indexing", pw_cit,"Cit");
    fprintf(f,"# ");
    for(int k=0;k<pw_num;  k++) fputc('-',f);
    fprintf(f," | ");
    for(int k=0;k<pw_title;k++) fputc('-',f);
    fprintf(f," | ");
    for(int k=0;k<pw_year; k++) fputc('-',f);
    fprintf(f," | ");
    for(int k=0;k<pw_type; k++) fputc('-',f);
    fprintf(f," | ");
    for(int k=0;k<pw_auth; k++) fputc('-',f);
    fprintf(f," | ");
    for(int k=0;k<pw_jour; k++) fputc('-',f);
    fprintf(f," | ");
    for(int k=0;k<pw_idx;  k++) fputc('-',f);
    fprintf(f," | ");
    for(int k=0;k<pw_cit;  k++) fputc('-',f);
    fprintf(f,"\n");

    for(int i=0;i<g_pub_count;i++){
        Publication *p=&g_pub[i];
        char auth_str[MAX_TITLE]="";
        join_list(p->authors,p->author_count,auth_str,sizeof(auth_str));
        fprintf(f,"%s|%s|%s|%s|%s|%s|%s|%d|%s|%s\n",
                p->title,p->year,p->type,auth_str,p->journal,
                p->url,p->indexing,p->citations,
                p->last_edited_by,p->last_edited_at);
    }
    fprintf(f,"# ----------------------------------------------------------------\n");
    fprintf(f,"# Total records: %d\n",g_pub_count);
    fclose(f);
}

static void load_pub_from(const char *path)
{
    g_pub_count=0;
    FILE *f=fopen(path,"r"); if(!f) return;
    char line[MAX_TITLE*4];
    while(fgets(line,sizeof(line),f)){
        int n=(int)strlen(line);
        while(n>0&&(line[n-1]=='\n'||line[n-1]=='\r')) line[--n]='\0';
        if(line[0]=='#'||line[0]=='\0') continue;
        Publication p; memset(&p,0,sizeof(p));
        const char *ptr=line;
        char auth_str[MAX_TITLE]="", cit_str[MAX_STR]="";
        next_field(&ptr,p.title,sizeof(p.title));
        next_field(&ptr,p.year,sizeof(p.year));
        next_field(&ptr,p.type,sizeof(p.type));
        next_field(&ptr,auth_str,sizeof(auth_str));
        next_field(&ptr,p.journal,sizeof(p.journal));
        next_field(&ptr,p.url,sizeof(p.url));
        next_field(&ptr,p.indexing,sizeof(p.indexing));
        next_field(&ptr,cit_str,sizeof(cit_str));
        next_field(&ptr,p.last_edited_by,sizeof(p.last_edited_by));
        next_field(&ptr,p.last_edited_at,sizeof(p.last_edited_at));
        p.author_count=split_list(auth_str,p.authors,MAX_AUTHORS);
        p.citations=cit_str[0]?atoi(cit_str):0;
        if(p.title[0]&&g_pub_count<MAX_PUBS) g_pub[g_pub_count++]=p;
    }
    fclose(f);
}

static void save_faculty(void) { save_fac_to(FACULTY_FILE); }
static void load_faculty(void) { load_fac_from(FACULTY_FILE); }
static void save_pubs(void)    { save_pub_to(PUB_FILE); }
static void load_pubs(void)    { load_pub_from(PUB_FILE); }

/* ================================================================
   UNDO  -- in-memory snapshot (100% reliable, no file I/O issues)
   ================================================================ */
static Faculty     g_undo_fac[MAX_FACULTY];
static int         g_undo_fac_count = 0;
static Publication g_undo_pub[MAX_PUBS];
static int         g_undo_pub_count = 0;
static int         g_undo_valid     = 0;  /* 1 = snapshot exists */

static void save_undo_snapshot(void)
{
    /* Copy current arrays into undo buffers */
    g_undo_fac_count = g_fac_count;
    memcpy(g_undo_fac, g_fac, sizeof(Faculty) * (size_t)g_fac_count);
    g_undo_pub_count = g_pub_count;
    memcpy(g_undo_pub, g_pub, sizeof(Publication) * (size_t)g_pub_count);
    g_undo_valid = 1;
    /* Also persist to disk so undo survives a program restart */
    save_fac_to(UNDO_FAC_FILE);
    save_pub_to(UNDO_PUB_FILE);
}

static int restore_undo_snapshot(void)
{
    if(!g_undo_valid){
        /* Try loading from disk if in-memory snapshot not set */
        FILE *ff=fopen(UNDO_FAC_FILE,"r");
        FILE *fp=fopen(UNDO_PUB_FILE,"r");
        if(!ff||!fp){ if(ff)fclose(ff); if(fp)fclose(fp); return 0; }
        fclose(ff); fclose(fp);
        load_fac_from(UNDO_FAC_FILE);
        load_pub_from(UNDO_PUB_FILE);
    } else {
        /* Restore directly from in-memory snapshot */
        g_fac_count = g_undo_fac_count;
        memcpy(g_fac, g_undo_fac, sizeof(Faculty) * (size_t)g_undo_fac_count);
        g_pub_count = g_undo_pub_count;
        memcpy(g_pub, g_undo_pub, sizeof(Publication) * (size_t)g_undo_pub_count);
        g_undo_valid = 0;  /* consume the snapshot */
    }
    /* Write the restored state to disk */
    save_faculty();
    save_pubs();
    return 1;
}

/* ================================================================
   LOGGING
   ================================================================ */
static void log_action(const char *adm, const char *act, const char *det)
{
    FILE *f=fopen(HISTORY_FILE,"a"); if(!f) return;
    char ts[MAX_STR]; now_str(ts);
    fprintf(f,"[%s] | Admin: %s | Action: %s | %s\n",ts,adm,act,det);
    fclose(f);
}

/* Return timestamp of last log entry, or "No edits recorded yet" */
static void get_last_edit_time(char *buf)
{
    buf[0]='\0';
    FILE *f=fopen(HISTORY_FILE,"r"); if(!f){strcpy(buf,"No edits recorded yet");return;}
    char last[MAX_TITLE]="";
    char line[MAX_TITLE];
    while(fgets(line,sizeof(line),f)){
        int n=(int)strlen(line);
        while(n>0&&(line[n-1]=='\n'||line[n-1]=='\r')) line[--n]='\0';
        if(line[0]) strncpy(last,line,MAX_TITLE-1);
    }
    fclose(f);
    if(!last[0]){strcpy(buf,"No edits recorded yet");return;}
    /* Extract timestamp: line starts with [YYYY-MM-DD HH:MM:SS] */
    if(last[0]=='['){
        int end=0; while(last[end]&&last[end]!=']') end++;
        int len=end-1; if(len>MAX_STR-1)len=MAX_STR-1;
        strncpy(buf,last+1,len); buf[len]='\0';
    } else strncpy(buf,last,MAX_STR-1);
}

/* ================================================================
   BUSINESS LOGIC HELPERS
   ================================================================ */
static void next_fac_id(char *buf)
{
    int mx=0;
    for(int i=0;i<g_fac_count;i++){
        const char *d=strchr(g_fac[i].id,'-');
        if(d){ int n=atoi(d+1); if(n>mx) mx=n; }
    }
    sprintf(buf,"MEF-%02d",mx+1);
}

static int sn_taken(const char *sn, const char *excl)
{
    for(int i=0;i<g_fac_count;i++){
        if(str_ieq(g_fac[i].sn,sn)){
            if(excl&&excl[0]&&strcmp(g_fac[i].id,excl)==0) continue;
            return 1;
        }
    }
    return 0;
}

static int title_taken(const char *t, int excl)
{
    for(int i=0;i<g_pub_count;i++){
        if(i==excl) continue;
        if(str_ieq(g_pub[i].title,t)) return 1;
    }
    return 0;
}

static int pubs_for_sn(const char *sn)
{
    int c=0;
    for(int i=0;i<g_pub_count;i++)
        for(int a=0;a<g_pub[i].author_count;a++)
            if(str_ieq(g_pub[i].authors[a],sn)){c++;break;}
    return c;
}

static void pub_ra_display(Publication *p, char *out, int sz)
{
    out[0]='\0';
    for(int a=0;a<p->author_count;a++)
        for(int f=0;f<g_fac_count;f++){
            if(!str_ieq(g_fac[f].sn,p->authors[a])) continue;
            for(int r=0;r<g_fac[f].ra_count;r++)
                if(!str_ihas(out,g_fac[f].ra[r])){
                    if(out[0]) strncat(out,"; ",sz-strlen(out)-1);
                    strncat(out,g_fac[f].ra[r],sz-strlen(out)-1);
                }
        }
    if(!out[0]) strncpy(out,"--",sz-1);
}

static void authors_str(Publication *p, char *out, int sz)
{
    out[0]='\0';
    for(int a=0;a<p->author_count;a++){
        if(!p->authors[a][0]) continue;   /* skip empty slots */
        if(out[0]) strncat(out,", ",sz-strlen(out)-1);
        strncat(out,p->authors[a],sz-strlen(out)-1);
    }
    if(!out[0]) strncpy(out,"--",sz-1);
}

/* Validate admin ID string (must be one of the 6) */
static int valid_admin_id(const char *id)
{
    for(int i=0;i<6;i++) if(strcmp(id,ADMIN_IDS[i])==0) return 1;
    return 0;
}

/* ================================================================
   AUTH
   ================================================================ */
static int logged_in(void) { return g_admin[0]!='\0'; }

static int is_locked(void)
{
    if(g_attempts<MAX_LOGIN_TRIES) return 0;
    if(time(NULL)<g_locked_until)  return 1;
    g_attempts=0; g_locked_until=0; return 0;
}

static int check_creds(const char *id, const char *pw)
{
    for(int i=0;i<6;i++)
        if(strcmp(id,ADMIN_IDS[i])==0&&strcmp(pw,ADMIN_PWD[i])==0) return 1;
    return 0;
}

/* ================================================================
   SCREEN: LOGIN  (stays open; retry / back-to-menu; countdown)
   ================================================================ */
static void screen_login(void)
{
    while(1){
        clrscr(); section("ADMIN LOGIN");
        printf("\n  Available IDs: admin-1  admin-2  admin-3  admin-4  admin-5  admin-6\n\n");

        /* ---- Check lockout ---- */
        if(is_locked()){
            long secs=(long)(g_locked_until-time(NULL));
            printf("  Login Portal locked due to too many wrong attempts.\n");
            printf("  Try again after ");
            /* live countdown */
            for(long s=secs;s>=0;s--){
                printf("\r  Try again after %2ld second(s)...  ",s);
                fflush(stdout);
                if(s>0){
#ifdef _WIN32
                    Sleep(1000);
#else
                    sleep(1);
#endif
                }
            }
            printf("\n\n  Lockout expired. ");
            /* fall through to retry */
            g_attempts=0; g_locked_until=0;
        }

        /* ---- Credential input ---- */
        char id[MAX_STR]="", pw[MAX_STR]="";
        printf("  %-30s: ","Admin ID"); fflush(stdout);
        read_line(id,sizeof(id));

        /* Validate ID format first */
        if(!id[0]){
            printf("\n  [ERROR] Admin ID cannot be empty.\n");
            printf("\n  [1] Retry   [2] Back to menu\n");
            char opt[4]=""; prompt("Choice",opt,sizeof(opt));
            if(opt[0]=='2') return;
            continue;
        }
        if(!valid_admin_id(id)){
            printf("\n  [ERROR] '%s' is not a valid Admin ID.\n",id);
            printf("  Valid IDs: admin-1 through admin-6\n");
            printf("\n  [1] Retry   [2] Back to menu\n");
            char opt[4]=""; prompt("Choice",opt,sizeof(opt));
            if(opt[0]=='2') return;
            continue;
        }

        read_password(pw,sizeof(pw));

        if(check_creds(id,pw)){
            SCOPY(g_admin,id);
            g_attempts=0;
            log_action(id,"LOGIN","Logged in successfully");
            printf("\n  Welcome, %s!\n",id);
            pause_enter();
            return;
        }

        /* ---- Wrong credentials ---- */
        g_attempts++;
        char det[MAX_TITLE];
        snprintf(det,sizeof(det),"Admin ID: %s  (wrong credentials)",id);
        log_action(id,"FAILED_LOGIN",det);

        if(g_attempts>=MAX_LOGIN_TRIES){
            g_locked_until=time(NULL)+LOCKOUT_SECS;
            printf("\n  [ERROR] Wrong credentials entered too many times.\n");
            printf("  Please wait ");
            countdown(LOCKOUT_SECS);
            g_attempts=0; g_locked_until=0;
            printf("\n  Lockout expired. You may try again.\n");
            printf("\n  [1] Retry   [2] Back to menu\n");
            char opt[4]=""; prompt("Choice",opt,sizeof(opt));
            if(opt[0]=='2') return;
            /* opt[0]=='1': loop back for retry */
        } else {
            int left=MAX_LOGIN_TRIES-g_attempts;
            printf("\n  [ERROR] Wrong credentials. %d attempt(s) remaining.\n",left);
            printf("\n  [1] Retry   [2] Back to menu\n");
            char opt[4]=""; prompt("Choice",opt,sizeof(opt));
            if(opt[0]=='2') return;
            /* loop: retry */
        }
    }
}

static void screen_logout(void)
{
    log_action(g_admin,"LOGOUT","Logged out");
    printf("\n  Logged out (%s).\n",g_admin);
    g_admin[0]='\0';
    pause_enter();
}

/* ================================================================
   SHARED: PRINT FACULTY TABLE  (screen version with ANSI links)
   ================================================================ */
/* Columns: ID(8) SN(6) Full Name+ANSI-link(28) Designation(22)
            Research Area(s)(38) Publications(12) -- URL anchored to name */
#define FC_ID   0
#define FC_SN   1
#define FC_NAME 2
#define FC_DESI 3
#define FC_RA   4
#define FC_PUBS 5
static const int FAC_CW[]={8,6,30,22,42,12};
static const int FAC_NC=6;
static const char *FAC_HDR[]={"ID","SN","Full Name","Designation","Research Area(s)","Publications"};

static void print_fac_table_screen(int *indices, int count)
{
    tbl_border(FAC_CW,FAC_NC);
    tbl_row_plain(FAC_HDR,FAC_CW,FAC_NC);
    tbl_border(FAC_CW,FAC_NC);

    for(int ii=0;ii<count;ii++){
        Faculty *m=&g_fac[indices[ii]];
        char ra_buf[MAX_TITLE]="";
        for(int r=0;r<m->ra_count;r++){
            if(r>0) strncat(ra_buf," / ",sizeof(ra_buf)-strlen(ra_buf)-1);
            strncat(ra_buf,m->ra[r],sizeof(ra_buf)-strlen(ra_buf)-1);
        }
        if(!ra_buf[0]) strcpy(ra_buf,"--");
        char pc[8]; sprintf(pc,"%d",pubs_for_sn(m->sn));

        /* Print row: Full Name is ANSI hyperlink to profile URL (no URL column) */
        printf("  |");
        printf(" "); pcol(m->id,   FAC_CW[FC_ID]);   printf(" |");
        printf(" "); pcol(m->sn,   FAC_CW[FC_SN]);   printf(" |");
        printf(" "); pcol_link(m->full_name,m->profile_url,FAC_CW[FC_NAME]); printf(" |");
        printf(" "); pcol(m->desi, FAC_CW[FC_DESI]); printf(" |");
        /* RA: first line in the row */
        {
            int ra_len=(int)strlen(ra_buf);
            int tw=FAC_CW[FC_RA];
            printf(" ");
            int first_chunk=(ra_len<=tw)?ra_len:tw;
            /* word-wrap first line */
            if(ra_len>tw){
                int k=tw; while(k>0&&ra_buf[k]!=' ') k--; if(k>0) first_chunk=k;
            }
            for(int k=0;k<first_chunk;k++) putchar(ra_buf[k]);
            for(int k=first_chunk;k<tw;k++) putchar(' ');
            printf(" |");
            printf(" "); pcol(pc, FAC_CW[FC_PUBS]); printf(" |");
            printf("\n");
            /* continuation lines for RA -- no blank line between them */
            int pos=first_chunk;
            while(pos<ra_len&&ra_buf[pos]==' ') pos++;
            while(pos<ra_len){
                int chunk=tw; if(pos+chunk>=ra_len) chunk=ra_len-pos;
                else{int k=chunk;while(k>0&&ra_buf[pos+k]!=' ')k--;if(k>0)chunk=k;}
                printf("  |");
                for(int ci=0;ci<FC_RA;ci++){printf(" ");for(int k=0;k<FAC_CW[ci];k++) putchar(' ');printf(" |");}
                printf(" ");
                for(int k=0;k<chunk;k++) putchar(ra_buf[pos+k]);
                for(int k=chunk;k<tw;k++) putchar(' ');
                printf(" |");
                for(int k=0;k<FAC_CW[FC_PUBS];k++) putchar(' ');
                printf(" |");
                printf("\n");
                pos+=chunk; while(pos<ra_len&&ra_buf[pos]==' ') pos++;
            }
        }
    }
    tbl_border(FAC_CW,FAC_NC);
}

/* ================================================================
   SHARED: PRINT PUBLICATIONS TABLE (screen version with ANSI links)
   ================================================================ */
/* Columns: #(3) Title+link(42, wraps) Year(4) Type(11)
            Authors(14) Journal(26) RA(26) Indexing(14) Cit(4) */
#define PC_NUM   0
#define PC_TITLE 1
#define PC_YEAR  2
#define PC_TYPE  3
#define PC_AUTH  4
#define PC_JOUR  5
#define PC_RA    6
#define PC_IDX   7
#define PC_CIT   8
static const int PUB_CW[]={3,42,4,11,14,26,26,14,4};
static const int PUB_NC=9;
static const char *PUB_HDR[]={"#","Title","Year","Type","Author(s)","Journal","Research Area(s)","Indexing","Cit"};

static void print_pub_table_screen(int *indices, int count)
{
    tbl_border(PUB_CW,PUB_NC);
    tbl_row_plain(PUB_HDR,PUB_CW,PUB_NC);
    tbl_border(PUB_CW,PUB_NC);

    for(int ii=0;ii<count;ii++){
        int idx=indices[ii];
        Publication *p=&g_pub[idx];
        char num[16]; snprintf(num,sizeof(num),"%d",ii+1);
        char cit[8];  sprintf(cit,"%d",p->citations);
        char auth[MAX_STR]; authors_str(p,auth,sizeof(auth));
        char ra_buf[MAX_TITLE]; pub_ra_display(p,ra_buf,sizeof(ra_buf));

        /* Helper macro: print a wrapped string in a column, returns lines used */
        #define WRAP_COL_START(str, colw, url_str) do { \
            int _len=(int)strlen(str), _tw=(colw); \
            int _fc=_tw; if(_len>_tw){int _k=_tw;while(_k>0&&(str)[_k]!=' ')_k--;if(_k>0)_fc=_k;} \
            else _fc=_len; \
            printf(" "); \
            if((url_str)&&(url_str)[0]) printf("\033]8;;%s\033\\",(url_str)); \
            for(int _k=0;_k<_fc;_k++) putchar((str)[_k]); \
            for(int _k=_fc;_k<_tw;_k++) putchar(' '); \
            if((url_str)&&(url_str)[0]) printf("\033]8;;\033\\"); \
        } while(0)

        int title_len=(int)strlen(p->title);
        int jour_len=(int)strlen(p->journal);
        int ra_len=(int)strlen(ra_buf);
        int tw=PUB_CW[PC_TITLE];
        int jw=PUB_CW[PC_JOUR];
        int rw=PUB_CW[PC_RA];

        /* --- compute first-line chunks for wrapping columns --- */
        int t_fc=tw; /* title first chunk */
        if(title_len>tw){int k=tw;while(k>0&&p->title[k]!=' ')k--;if(k>0)t_fc=k;} else t_fc=title_len;
        int j_fc=jw; /* journal first chunk */
        if(jour_len>jw){int k=jw;while(k>0&&p->journal[k]!=' ')k--;if(k>0)j_fc=k;} else j_fc=jour_len;
        int r_fc=rw; /* RA first chunk */
        if(ra_len>rw){int k=rw;while(k>0&&ra_buf[k]!=' ')k--;if(k>0)r_fc=k;} else r_fc=ra_len;

        /* --- First row --- */
        printf("  |");
        printf(" "); pcol(num,PUB_CW[PC_NUM]); printf(" |");
        WRAP_COL_START(p->title,tw,p->url); printf(" |");
        printf(" "); pcol(p->year,    PUB_CW[PC_YEAR]); printf(" |");
        printf(" "); pcol(p->type,    PUB_CW[PC_TYPE]); printf(" |");
        printf(" "); pcol(auth,       PUB_CW[PC_AUTH]); printf(" |");
        printf(" ");
        for(int k=0;k<j_fc;k++) putchar(p->journal[k]);
        for(int k=j_fc;k<jw;k++) putchar(' ');
        printf(" |");
        printf(" ");
        for(int k=0;k<r_fc;k++) putchar(ra_buf[k]);
        for(int k=r_fc;k<rw;k++) putchar(' ');
        printf(" |");
        printf(" "); pcol(p->indexing,PUB_CW[PC_IDX]);  printf(" |");
        printf(" "); pcol(cit,        PUB_CW[PC_CIT]);  printf(" |");
        printf("\n");
        #undef WRAP_COL_START

        /* --- Continuation rows (title, journal, RA can all wrap independently) --- */
        {
            int t_pos=t_fc; while(t_pos<title_len&&p->title[t_pos]==' ') t_pos++;
            int j_pos=j_fc; while(j_pos<jour_len&&p->journal[j_pos]==' ') j_pos++;
            int r_pos=r_fc; while(r_pos<ra_len&&ra_buf[r_pos]==' ') r_pos++;
            while(t_pos<title_len||j_pos<jour_len||r_pos<ra_len){
                printf("  |");
                /* # col blank */
                printf(" "); for(int k=0;k<PUB_CW[PC_NUM];k++) putchar(' '); printf(" |");
                /* title continuation */
                printf(" ");
                if(t_pos<title_len){
                    int chunk=tw; if(t_pos+chunk>=title_len) chunk=title_len-t_pos;
                    else{int k=chunk;while(k>0&&p->title[t_pos+k]!=' ')k--;if(k>0)chunk=k;}
                    if(p->url[0]) printf("\033]8;;%s\033\\",p->url);
                    for(int k=0;k<chunk;k++) putchar(p->title[t_pos+k]);
                    for(int k=chunk;k<tw;k++) putchar(' ');
                    if(p->url[0]) printf("\033]8;;\033\\");
                    t_pos+=chunk; while(t_pos<title_len&&p->title[t_pos]==' ') t_pos++;
                } else { for(int k=0;k<tw;k++) putchar(' '); }
                printf(" |");
                /* year/type/auth blank */
                printf(" "); for(int k=0;k<PUB_CW[PC_YEAR];k++) putchar(' '); printf(" |");
                printf(" "); for(int k=0;k<PUB_CW[PC_TYPE];k++) putchar(' '); printf(" |");
                printf(" "); for(int k=0;k<PUB_CW[PC_AUTH];k++) putchar(' '); printf(" |");
                /* journal continuation */
                printf(" ");
                if(j_pos<jour_len){
                    int chunk=jw; if(j_pos+chunk>=jour_len) chunk=jour_len-j_pos;
                    else{int k=chunk;while(k>0&&p->journal[j_pos+k]!=' ')k--;if(k>0)chunk=k;}
                    for(int k=0;k<chunk;k++) putchar(p->journal[j_pos+k]);
                    for(int k=chunk;k<jw;k++) putchar(' ');
                    j_pos+=chunk; while(j_pos<jour_len&&p->journal[j_pos]==' ') j_pos++;
                } else { for(int k=0;k<jw;k++) putchar(' '); }
                printf(" |");
                /* RA continuation */
                printf(" ");
                if(r_pos<ra_len){
                    int chunk=rw; if(r_pos+chunk>=ra_len) chunk=ra_len-r_pos;
                    else{int k=chunk;while(k>0&&ra_buf[r_pos+k]!=' ')k--;if(k>0)chunk=k;}
                    for(int k=0;k<chunk;k++) putchar(ra_buf[r_pos+k]);
                    for(int k=chunk;k<rw;k++) putchar(' ');
                    r_pos+=chunk; while(r_pos<ra_len&&ra_buf[r_pos]==' ') r_pos++;
                } else { for(int k=0;k<rw;k++) putchar(' '); }
                printf(" |");
                /* indexing/cit blank */
                printf(" "); for(int k=0;k<PUB_CW[PC_IDX];k++) putchar(' '); printf(" |");
                printf(" "); for(int k=0;k<PUB_CW[PC_CIT];k++) putchar(' '); printf(" |");
                printf("\n");
            }
        }
    }
    tbl_border(PUB_CW,PUB_NC);
}

/* ================================================================
   SCREEN: VIEW ALL FACULTY
   ================================================================ */
static void screen_view_faculty(void)
{
    clrscr(); section("ALL FACULTY");
    if(g_fac_count==0){printf("\n  No faculty records.\n");pause_enter();return;}
    printf("\n");
    int indices[MAX_FACULTY];
    for(int i=0;i<g_fac_count;i++) indices[i]=i;
    print_fac_table_screen(indices,g_fac_count);
    printf("  Total: %d faculty member(s)\n",g_fac_count);
    pause_enter();
}

/* ================================================================
   SCREEN: VIEW ALL PUBLICATIONS
   ================================================================ */
static void screen_view_pubs(void)
{
    clrscr(); section("ALL PUBLICATIONS");
    if(g_pub_count==0){printf("\n  No publications.\n");pause_enter();return;}
    printf("\n");
    int indices[MAX_PUBS];
    for(int i=0;i<g_pub_count;i++) indices[i]=i;
    print_pub_table_screen(indices,g_pub_count);
    printf("  Total: %d publication(s)\n",g_pub_count);
    pause_enter();
}

/* ================================================================
   SCREEN: ADD FACULTY
   ================================================================ */
static void screen_add_faculty(void)
{
    clrscr(); section("ADD FACULTY");
    Faculty m; memset(&m,0,sizeof(m));
    next_fac_id(m.id);
    printf("\n  Auto-assigned ID: %s\n\n",m.id);

    if(!prompt("Short Name / Initials (e.g. MHK)",m.sn,sizeof(m.sn)))
        {printf("  [Error] Required.\n");pause_enter();return;}
    str_upper(m.sn);
    if(sn_taken(m.sn,""))
        {printf("  [Error] '%s' already in use.\n",m.sn);pause_enter();return;}

    if(!prompt("Full Name",m.full_name,sizeof(m.full_name)))
        {printf("  [Error] Required.\n");pause_enter();return;}
    to_title_case(m.full_name);

    while(1){
        printf("\n  1=Professor  2=Associate Professor  3=Assistant Professor  4=Lecturer\n");
        char ch[4]=""; prompt("Designation (1-4)",ch,sizeof(ch));
        if(strlen(ch)==1){
            switch(ch[0]){
                case '1': SCOPY(m.desi,"Professor");           goto desi_ok;
                case '2': SCOPY(m.desi,"Associate Professor"); goto desi_ok;
                case '3': SCOPY(m.desi,"Assistant Professor"); goto desi_ok;
                case '4': SCOPY(m.desi,"Lecturer");            goto desi_ok;
            }
        }
        printf("  [Error] Please enter 1, 2, 3, or 4.\n");
    }
    desi_ok:;

    printf("\n  Enter research areas one per line (blank line to finish):\n");
    m.ra_count=0;
    while(m.ra_count<MAX_RA){
        char ra[MAX_STR]="";
        printf("  Area %d: ",m.ra_count+1); fflush(stdout);
        if(!fgets(ra,sizeof(ra),stdin)) break;
        int n=(int)strlen(ra); if(n>0&&ra[n-1]=='\n') ra[n-1]='\0'; trim(ra);
        if(!ra[0]) break;
        to_title_case(ra); SCOPY(m.ra[m.ra_count],ra); m.ra_count++;
    }
    if(m.ra_count==0){printf("  [Error] At least one required.\n");pause_enter();return;}

    prompt("Profile URL (optional)",m.profile_url,sizeof(m.profile_url));
    SCOPY(m.last_edited_by,g_admin); now_str(m.last_edited_at);

    save_undo_snapshot();
    g_fac[g_fac_count++]=m; save_faculty();
    char det[MAX_TITLE]; snprintf(det,sizeof(det),"Name: %.100s, ID: %s",m.full_name,m.id);
    log_action(g_admin,"ADD_FACULTY",det);
    printf("\n  [OK] '%s' added (ID: %s).\n",m.full_name,m.id);
    pause_enter();
}

/* ================================================================
   SCREEN: EDIT FACULTY
   ================================================================ */
static void screen_edit_faculty(void)
{
    clrscr(); section("EDIT FACULTY");
    if(g_fac_count==0){printf("\n  No faculty.\n");pause_enter();return;}
    printf("\n");
    for(int i=0;i<g_fac_count;i++)
        printf("  [%d] %s -- %s (%s)\n",i+1,g_fac[i].id,g_fac[i].full_name,g_fac[i].sn);
    printf("\n");
    while(1){
        char sel[8]=""; prompt("Number to edit (0=cancel)",sel,sizeof(sel));
        if(sel[0]=='0'){printf("  Cancelled.\n");pause_enter();return;}
        int idx=atoi(sel)-1;
        if(idx>=0&&idx<g_fac_count) {
            Faculty *m=&g_fac[idx];
            char buf[MAX_TITLE]="";
            save_undo_snapshot();   /* snapshot BEFORE any edits */
            printf("\n  Editing: %s  (blank = keep current)\n\n",m->full_name);

            printf("  Short Name [%s]: ",m->sn); fflush(stdout);
            read_line(buf,sizeof(buf));
            if(buf[0]){ str_upper(buf); if(sn_taken(buf,m->id)){printf("  [Error] Taken.\n");pause_enter();return;} SCOPY(m->sn,buf); }

            printf("  Full Name [%s]: ",m->full_name); fflush(stdout);
            read_line(buf,sizeof(buf));
            if(buf[0]){ to_title_case(buf); SCOPY(m->full_name,buf); }

            while(1){
                printf("  Designation [%s]\n  1=Prof 2=Assoc 3=Asst 4=Lecturer 0=Keep\n",m->desi);
                prompt("  Choice",buf,sizeof(buf));
                if(strlen(buf)==1){
                    if(buf[0]=='0') break;
                    if(buf[0]=='1'){SCOPY(m->desi,"Professor");           break;}
                    if(buf[0]=='2'){SCOPY(m->desi,"Associate Professor"); break;}
                    if(buf[0]=='3'){SCOPY(m->desi,"Assistant Professor"); break;}
                    if(buf[0]=='4'){SCOPY(m->desi,"Lecturer");            break;}
                }
                printf("  [Error] Enter 0-4.\n");
            }

            printf("\n  Current RAs: ");
            for(int r=0;r<m->ra_count;r++){if(r>0)printf(" / ");printf("%s",m->ra[r]);}
            printf("\n  Replace all? (y/N): "); fflush(stdout);
            read_line(buf,sizeof(buf));
            if(buf[0]=='y'||buf[0]=='Y'){
                m->ra_count=0;
                while(m->ra_count<MAX_RA){
                    char ra[MAX_STR]="";
                    printf("  Area %d: ",m->ra_count+1); fflush(stdout);
                    if(!fgets(ra,sizeof(ra),stdin)) break;
                    int rn=(int)strlen(ra); if(rn>0&&ra[rn-1]=='\n') ra[rn-1]='\0'; trim(ra);
                    if(!ra[0]) break;
                    to_title_case(ra); SCOPY(m->ra[m->ra_count],ra); m->ra_count++;
                }
            }

            printf("  Profile URL [%s]: ",m->profile_url); fflush(stdout);
            read_line(buf,sizeof(buf));
            if(buf[0]) SCOPY(m->profile_url,buf);

            SCOPY(m->last_edited_by,g_admin); now_str(m->last_edited_at);
            save_faculty();
            char det[MAX_TITLE]; snprintf(det,sizeof(det),"ID: %s, Name: %.100s",m->id,m->full_name);
            log_action(g_admin,"EDIT_FACULTY",det);
            printf("\n  [OK] Faculty updated.\n"); pause_enter(); return;
        }
        printf("  [Error] Invalid number. Enter 1-%d or 0 to cancel.\n",g_fac_count);
    }
}

/* ================================================================
   SCREEN: DELETE FACULTY
   ================================================================ */
static void screen_delete_faculty(void)
{
    clrscr(); section("DELETE FACULTY");
    if(g_fac_count==0){printf("\n  No faculty.\n");pause_enter();return;}
    printf("\n");
    for(int i=0;i<g_fac_count;i++)
        printf("  [%d] %s -- %s\n",i+1,g_fac[i].id,g_fac[i].full_name);
    printf("\n");
    while(1){
        char sel[8]=""; prompt("Number to delete (0=cancel)",sel,sizeof(sel));
        if(sel[0]=='0'){printf("  Cancelled.\n");pause_enter();return;}
        int idx=atoi(sel)-1;
        if(idx>=0&&idx<g_fac_count){
            printf("\n  Delete: %s (%s)\n",g_fac[idx].full_name,g_fac[idx].id);
            char cf[16]=""; prompt("Type 'yes' to confirm",cf,sizeof(cf));
            if(strcmp(cf,"yes")!=0){printf("  Cancelled.\n");pause_enter();return;}
            char name[MAX_STR],idc[MAX_STR];
            SCOPY(name,g_fac[idx].full_name); SCOPY(idc,g_fac[idx].id);
            save_undo_snapshot();
            for(int i=idx;i<g_fac_count-1;i++) g_fac[i]=g_fac[i+1];
            g_fac_count--; save_faculty();
            char det[MAX_TITLE]; snprintf(det,sizeof(det),"ID: %s, Name: %.100s",idc,name);
            log_action(g_admin,"DELETE_FACULTY",det);
            printf("\n  [OK] '%s' deleted.\n",name); pause_enter(); return;
        }
        printf("  [Error] Invalid number. Enter 1-%d or 0 to cancel.\n",g_fac_count);
    }
}

/* ================================================================
   SCREEN: ADD PUBLICATION
   ================================================================ */
static void screen_add_pub(void)
{
    clrscr(); section("ADD PUBLICATION");
    if(g_fac_count==0){printf("\n  Add faculty first.\n");pause_enter();return;}
    Publication p; memset(&p,0,sizeof(p));

    if(!prompt("Title",p.title,sizeof(p.title))){printf("  [Error] Required.\n");pause_enter();return;}
    to_title_case(p.title);
    if(title_taken(p.title,-1)){printf("  [Error] Title already exists.\n");pause_enter();return;}

    if(!prompt("Year (1876-2026)",p.year,sizeof(p.year))){printf("  [Error] Required.\n");pause_enter();return;}
    {int yr=atoi(p.year); if(yr<1876||yr>2026){printf("  [Error] Year must be between 1876 and 2026.\n");pause_enter();return;}}

    while(1){
        printf("\n  1=Journal  2=Conference  3=Review  4=Book Chapter\n");
        char ch[4]=""; prompt("Type (1-4)",ch,sizeof(ch));
        if(strlen(ch)==1){
            switch(ch[0]){
                case '1': SCOPY(p.type,"Journal");      goto type_ok;
                case '2': SCOPY(p.type,"Conference");   goto type_ok;
                case '3': SCOPY(p.type,"Review");       goto type_ok;
                case '4': SCOPY(p.type,"Book Chapter"); goto type_ok;
            }
        }
        printf("  [Error] Please enter 1, 2, 3, or 4.\n");
    }
    type_ok:;

    /* Author selection with validation */
    while(1){
        printf("\n  Faculty:\n");
        for(int i=0;i<g_fac_count;i++)
            printf("    [%d] %s -- %s\n",i+1,g_fac[i].sn,g_fac[i].full_name);
        printf("  Author numbers (space-separated): "); fflush(stdout);
        char al[MAX_STR]=""; read_line(al,sizeof(al));
        p.author_count=0;
        int bad=0;
        char tmp[MAX_STR]; strncpy(tmp,al,MAX_STR-1); tmp[MAX_STR-1]='\0';
        char *t=strtok(tmp," ,\t");
        while(t){
            int ai=atoi(t)-1;
            if(ai<0||ai>=g_fac_count){
                printf("  [Error] '%s' is not a valid faculty number.\n",t);
                bad=1; break;
            }
            if(p.author_count<MAX_AUTHORS) SCOPY(p.authors[p.author_count++],g_fac[ai].sn);
            t=strtok(NULL," ,\t");
        }
        if(!bad&&p.author_count>0) break;
        if(!bad) printf("  [Error] At least one author required.\n");
    }

    if(!prompt("Journal / Conference Name",p.journal,sizeof(p.journal)))
        {printf("  [Error] Required.\n");pause_enter();return;}
    to_title_case(p.journal);
    prompt("URL / DOI (optional)",p.url,sizeof(p.url));
    prompt("Indexing (e.g. Scopus, SCI)",p.indexing,sizeof(p.indexing));
    char cb[16]=""; prompt("Citations (default 0)",cb,sizeof(cb));
    p.citations=cb[0]?atoi(cb):0;

    SCOPY(p.last_edited_by,g_admin); now_str(p.last_edited_at);
    save_undo_snapshot();
    g_pub[g_pub_count++]=p; save_pubs();
    char det[MAX_TITLE]; snprintf(det,sizeof(det),"Title: %.200s, Year: %s",p.title,p.year);
    log_action(g_admin,"ADD_PUBLICATION",det);
    printf("\n  [OK] Publication added.\n"); pause_enter();
}

/* ================================================================
   SCREEN: EDIT PUBLICATION
   ================================================================ */
static void screen_edit_pub(void)
{
    clrscr(); section("EDIT PUBLICATION");
    if(g_pub_count==0){printf("\n  No publications.\n");pause_enter();return;}
    printf("\n");
    for(int i=0;i<g_pub_count;i++){
        char t[52]; strncpy(t,g_pub[i].title,50); t[50]='\0';
        if((int)strlen(g_pub[i].title)>50) strcat(t,"...");
        printf("  [%d] %s  (%s)\n",i+1,t,g_pub[i].year);
    }
    printf("\n");
    while(1){
        char sel[8]=""; prompt("Number to edit (0=cancel)",sel,sizeof(sel));
        if(sel[0]=='0'){printf("  Cancelled.\n");pause_enter();return;}
        int idx=atoi(sel)-1;
        if(idx>=0&&idx<g_pub_count){
            Publication *p=&g_pub[idx];
            char buf[MAX_TITLE]="";
            save_undo_snapshot();   /* snapshot BEFORE any edits */
            printf("\n  Editing: %s  (blank = keep)\n\n",p->title);

            printf("  Title [%s]: ",p->title); fflush(stdout);
            read_line(buf,sizeof(buf));
            if(buf[0]){to_title_case(buf);if(title_taken(buf,idx)){printf("  [Error] Title exists.\n");pause_enter();return;}SCOPY(p->title,buf);}

            printf("  Year [%s]: ",p->year); fflush(stdout);
            read_line(buf,sizeof(buf));
            if(buf[0]){int y=atoi(buf);if(y<1876||y>2026){printf("  [Error] Year must be between 1876 and 2026.\n");pause_enter();return;}SCOPY(p->year,buf);}

            while(1){
                printf("  Type [%s] 1=Journal 2=Conference 3=Review 4=Book Chapter 0=Keep\n",p->type);
                prompt("  Choice",buf,sizeof(buf));
                if(strlen(buf)==1){
                    if(buf[0]=='0') break;
                    if(buf[0]=='1'){SCOPY(p->type,"Journal");      break;}
                    if(buf[0]=='2'){SCOPY(p->type,"Conference");   break;}
                    if(buf[0]=='3'){SCOPY(p->type,"Review");       break;}
                    if(buf[0]=='4'){SCOPY(p->type,"Book Chapter"); break;}
                }
                printf("  [Error] Enter 0-4.\n");
            }

            printf("  Current authors: ");
            for(int a=0;a<p->author_count;a++){if(a>0)printf(", ");printf("%s",p->authors[a]);}
            printf("\n  Replace? (y/N): "); fflush(stdout);
            read_line(buf,sizeof(buf));
            if(buf[0]=='y'||buf[0]=='Y'){
                while(1){
                    printf("  Faculty:\n");
                    for(int i=0;i<g_fac_count;i++) printf("    [%d] %s -- %s\n",i+1,g_fac[i].sn,g_fac[i].full_name);
                    printf("  Numbers: "); fflush(stdout);
                    char al[MAX_STR]=""; read_line(al,sizeof(al));
                    p->author_count=0; int bad=0;
                    char tmp[MAX_STR]; strncpy(tmp,al,MAX_STR-1); tmp[MAX_STR-1]='\0';
                    char *tk=strtok(tmp," ,\t");
                    while(tk){
                        int ai=atoi(tk)-1;
                        if(ai<0||ai>=g_fac_count){printf("  [Error] '%s' is not valid.\n",tk);bad=1;break;}
                        if(p->author_count<MAX_AUTHORS) SCOPY(p->authors[p->author_count++],g_fac[ai].sn);
                        tk=strtok(NULL," ,\t");
                    }
                    if(!bad&&p->author_count>0) break;
                    if(!bad) printf("  [Error] At least one required.\n");
                }
            }

            printf("  Journal [%s]: ",p->journal); fflush(stdout);
            read_line(buf,sizeof(buf)); if(buf[0]){to_title_case(buf);SCOPY(p->journal,buf);}
            printf("  URL [%s]: ",p->url); fflush(stdout);
            read_line(buf,sizeof(buf)); if(buf[0]) SCOPY(p->url,buf);
            printf("  Indexing [%s]: ",p->indexing); fflush(stdout);
            read_line(buf,sizeof(buf)); if(buf[0]) SCOPY(p->indexing,buf);
            printf("  Citations [%d]: ",p->citations); fflush(stdout);
            read_line(buf,sizeof(buf)); if(buf[0]) p->citations=atoi(buf);

            SCOPY(p->last_edited_by,g_admin); now_str(p->last_edited_at);
            save_pubs();
            char det[MAX_TITLE]; snprintf(det,sizeof(det),"Title: %.200s",p->title);
            log_action(g_admin,"EDIT_PUBLICATION",det);
            printf("\n  [OK] Updated.\n"); pause_enter(); return;
        }
        printf("  [Error] Invalid number. Enter 1-%d or 0 to cancel.\n",g_pub_count);
    }
}

/* ================================================================
   SCREEN: DELETE PUBLICATION
   ================================================================ */
static void screen_delete_pub(void)
{
    clrscr(); section("DELETE PUBLICATION");
    if(g_pub_count==0){printf("\n  No publications.\n");pause_enter();return;}
    printf("\n");
    for(int i=0;i<g_pub_count;i++){
        char t[52]; strncpy(t,g_pub[i].title,50); t[50]='\0';
        if((int)strlen(g_pub[i].title)>50) strcat(t,"...");
        printf("  [%d] %s  (%s)\n",i+1,t,g_pub[i].year);
    }
    printf("\n");
    while(1){
        char sel[8]=""; prompt("Number to delete (0=cancel)",sel,sizeof(sel));
        if(sel[0]=='0'){printf("  Cancelled.\n");pause_enter();return;}
        int idx=atoi(sel)-1;
        if(idx>=0&&idx<g_pub_count){
            printf("\n  Deleting: %s\n",g_pub[idx].title);
            char cf[16]=""; prompt("Type 'yes' to confirm",cf,sizeof(cf));
            if(strcmp(cf,"yes")!=0){printf("  Cancelled.\n");pause_enter();return;}
            char tc[MAX_TITLE]; SCOPY(tc,g_pub[idx].title);
            save_undo_snapshot();
            for(int i=idx;i<g_pub_count-1;i++) g_pub[i]=g_pub[i+1];
            g_pub_count--; save_pubs();
            char det[MAX_TITLE]; snprintf(det,sizeof(det),"Title: %.200s",tc);
            log_action(g_admin,"DELETE_PUBLICATION",det);
            printf("\n  [OK] Deleted.\n"); pause_enter(); return;
        }
        printf("  [Error] Invalid number. Enter 1-%d or 0 to cancel.\n",g_pub_count);
    }
}

/* ================================================================
   SCREEN: SEARCH  (stays in loop until option 6 is chosen)
   ================================================================ */
static void screen_search(void)
{
    while(1){
        clrscr(); section("SEARCH");
        printf("\n  Search modes:\n");
        printf("    [1] Keyword     (title / journal / indexing)\n");
        printf("    [2] Faculty     (SN / ID / name / designation)\n");
        printf("    [3] Year\n");
        printf("    [4] Publication Type\n");
        printf("    [5] Research Area\n");
        printf("    [6] Exit Search\n\n");

        char sel[4]="";
        while(1){
            prompt("Mode (1-6)",sel,sizeof(sel));
            if(strlen(sel)==1&&sel[0]>='1'&&sel[0]<='6') break;
            printf("  [Error] Please enter a number from 1 to 6.\n");
        }
        if(sel[0]=='6') return;

        char query[MAX_TITLE]="";
        prompt("Query",query,sizeof(query));
        trim(query);
        if(!query[0]){printf("  Empty query. Returning to search menu.\n");pause_enter();continue;}

        int mode=atoi(sel);
        int fhits=0, phits=0;
        printf("\n"); hr2();

        /* Faculty matches -- shown for faculty search, RA search, and keyword */
        if(mode==1||mode==2||mode==5){
            printf("  FACULTY MATCHES\n\n");
            int fi[MAX_FACULTY]; int fc=0;
            for(int i=0;i<g_fac_count;i++){
                Faculty *m=&g_fac[i]; int hit=0;
                if(mode==2) hit=str_ieq(m->id,query)||str_ieq(m->sn,query)||str_ihas(m->full_name,query)||str_ihas(m->desi,query);
                else if(mode==5){ for(int r=0;r<m->ra_count&&!hit;r++) if(str_ihas(m->ra[r],query)) hit=1; }
                else if(mode==1){
                    hit=str_ihas(m->full_name,query)||str_ieq(m->sn,query)||str_ihas(m->desi,query);
                    for(int r=0;r<m->ra_count&&!hit;r++) if(str_ihas(m->ra[r],query)) hit=1;
                }
                if(hit) fi[fc++]=i;
            }
            fhits=fc;
            if(fc>0) print_fac_table_screen(fi,fc);
            else printf("  (no faculty matched)\n");
            printf("\n");
        }

        /* Publication matches */
        printf("  PUBLICATION MATCHES\n\n");
        int pi[MAX_PUBS]; int pc=0;
        for(int i=0;i<g_pub_count;i++){
            Publication *p=&g_pub[i]; int hit=0;
            if(mode==1) hit=str_ihas(p->title,query)||str_ihas(p->journal,query)||str_ihas(p->indexing,query);
            else if(mode==2){
                for(int f=0;f<g_fac_count&&!hit;f++){
                    Faculty *m=&g_fac[f];
                    int fh=str_ieq(m->id,query)||str_ieq(m->sn,query)||str_ihas(m->full_name,query)||str_ihas(m->desi,query);
                    if(fh) for(int a=0;a<p->author_count&&!hit;a++) if(str_ieq(p->authors[a],m->sn)) hit=1;
                }
            } else if(mode==3) hit=str_ieq(p->year,query);
            else if(mode==4) hit=str_ihas(p->type,query);
            else if(mode==5){
                for(int f=0;f<g_fac_count&&!hit;f++){
                    Faculty *m=&g_fac[f]; int fh=0;
                    for(int r=0;r<m->ra_count&&!fh;r++) if(str_ihas(m->ra[r],query)) fh=1;
                    if(fh) for(int a=0;a<p->author_count&&!hit;a++) if(str_ieq(p->authors[a],m->sn)) hit=1;
                }
            }
            if(hit) pi[pc++]=i;
        }
        phits=pc;
        if(pc>0) print_pub_table_screen(pi,pc);
        else printf("  (no publications matched)\n");

        hr2();
        printf("  Results: %d faculty,  %d publications\n",fhits,phits);
        pause_enter();
        /* loop back to search menu */
    }
}

/* ================================================================
   SCREEN: SYSTEM OVERVIEW
   ================================================================ */
static void screen_overview(void)
{
    clrscr(); section("SYSTEM OVERVIEW");

    float avg=(g_fac_count>0)?(float)g_pub_count/g_fac_count:0.0f;
    int mny=9999,mxy=0;
    for(int i=0;i<g_pub_count;i++){int y=atoi(g_pub[i].year);if(y>0){if(y<mny)mny=y;if(y>mxy)mxy=y;}}

    printf("\n  Total Faculty      : %d\n",g_fac_count);
    printf("  Total Publications : %d\n",g_pub_count);
    printf("  Avg Pubs/Faculty   : %.2f\n",avg);
    if(g_pub_count>0&&mny<=mxy) printf("  Publication Span   : %d -- %d\n",mny,mxy);

    /* ---- Faculty by Designation ---- */
    printf("\n"); hr();
    printf("  NUMBER OF FACULTY BY DESIGNATION\n"); hr();
    const char *ds[]={"Professor","Associate Professor","Assistant Professor","Lecturer"};
    int dc[4]={0,0,0,0};
    for(int i=0;i<g_fac_count;i++) for(int d=0;d<4;d++) if(strcmp(g_fac[i].desi,ds[d])==0) dc[d]++;
    {int cw[]={26,12}; int nc=2; const char *hdr[]={"Designation","Count"};
     tbl_border(cw,nc); tbl_row_plain(hdr,cw,nc); tbl_border(cw,nc);
     for(int d=0;d<4;d++){char c[8];sprintf(c,"%d",dc[d]);const char *r[]={ds[d],c};tbl_row_plain(r,cw,nc);}
     char tot[8]; sprintf(tot,"%d",g_fac_count); const char *tr[]={"TOTAL",tot}; tbl_row_plain(tr,cw,nc);
     tbl_border(cw,nc);}

    /* ---- RA table ---- */
    printf("\n"); hr();
    printf("  FACULTY AND PUBLICATIONS BY RESEARCH AREA\n"); hr();
    static char all_ra[MAX_FACULTY*MAX_RA][MAX_STR];
    int n_ra=0; memset(all_ra,0,sizeof(all_ra));
    for(int i=0;i<g_fac_count;i++)
        for(int r=0;r<g_fac[i].ra_count;r++){
            int dup=0; for(int x=0;x<n_ra;x++) if(strcmp(all_ra[x],g_fac[i].ra[r])==0){dup=1;break;}
            if(!dup&&n_ra<MAX_FACULTY*MAX_RA){strncpy(all_ra[n_ra],g_fac[i].ra[r],MAX_STR-1);all_ra[n_ra][MAX_STR-1]='\0';n_ra++;}
        }
    {int cw[]={40,10,14}; int nc=3; const char *hdr[]={"Research Area","Faculty","Publications"};
     tbl_border(cw,nc); tbl_row_plain(hdr,cw,nc); tbl_border(cw,nc);
     for(int ri=0;ri<n_ra;ri++){
         int fc=0,pc2=0;
         for(int i=0;i<g_fac_count;i++)
             for(int r=0;r<g_fac[i].ra_count;r++)
                 if(strcmp(g_fac[i].ra[r],all_ra[ri])==0){fc++;pc2+=pubs_for_sn(g_fac[i].sn);break;}
         char fc_s[8],pc_s[8]; sprintf(fc_s,"%d",fc); sprintf(pc_s,"%d",pc2);
         const char *row[]={all_ra[ri],fc_s,pc_s}; tbl_row_plain(row,cw,nc);
     }
     if(!n_ra) printf("  (no data)\n");
     tbl_border(cw,nc);}

    /* ---- Year table ---- */
    printf("\n"); hr(); printf("  PUBLICATION COUNT BY YEAR\n"); hr();
    char yrs[64][8]; int yrc[64]; int ny=0;
    for(int i=0;i<g_pub_count;i++){
        int f=0; for(int y=0;y<ny;y++) if(strcmp(yrs[y],g_pub[i].year)==0){yrc[y]++;f=1;break;}
        if(!f&&ny<64){strncpy(yrs[ny],g_pub[i].year,7);yrs[ny][7]='\0';yrc[ny++]=1;}
    }
    for(int a=0;a<ny-1;a++) for(int b=a+1;b<ny;b++) if(strcmp(yrs[a],yrs[b])>0){char ty[8];strcpy(ty,yrs[a]);strcpy(yrs[a],yrs[b]);strcpy(yrs[b],ty);int tc=yrc[a];yrc[a]=yrc[b];yrc[b]=tc;}
    {int cw[]={10,12}; int nc=2; const char *hdr[]={"Year","Count"};
     tbl_border(cw,nc); tbl_row_plain(hdr,cw,nc); tbl_border(cw,nc);
     for(int y=0;y<ny;y++){char c[8];sprintf(c,"%d",yrc[y]);const char *r[]={yrs[y],c};tbl_row_plain(r,cw,nc);}
     if(!ny) printf("  (no data)\n");
     tbl_border(cw,nc); }

    /* ---- Type table ---- */
    printf("\n"); hr(); printf("  PUBLICATION COUNT BY TYPE\n"); hr();
    char tps[10][MAX_STR]; int tpc[10]; int nt=0;
    for(int i=0;i<g_pub_count;i++){
        int f=0; for(int t=0;t<nt;t++) if(strcmp(tps[t],g_pub[i].type)==0){tpc[t]++;f=1;break;}
        if(!f&&nt<10){SCOPY(tps[nt],g_pub[i].type);tpc[nt++]=1;}
    }
    {int cw[]={18,12}; int nc=2; const char *hdr[]={"Type","Count"};
     tbl_border(cw,nc); tbl_row_plain(hdr,cw,nc); tbl_border(cw,nc);
     for(int t=0;t<nt;t++){char c[8];sprintf(c,"%d",tpc[t]);const char *r[]={tps[t],c};tbl_row_plain(r,cw,nc);}
     if(!nt) printf("  (no data)\n");
     tbl_border(cw,nc); }

    /* ---- Faculty publications table ---- */
    printf("\n"); hr(); printf("  PUBLICATION COUNT BY FACULTY\n"); hr();
    int order[MAX_FACULTY];
    for(int i=0;i<g_fac_count;i++) order[i]=i;
    for(int a=0;a<g_fac_count-1;a++) for(int b=a+1;b<g_fac_count;b++)
        if(pubs_for_sn(g_fac[order[a]].sn)<pubs_for_sn(g_fac[order[b]].sn)){int t=order[a];order[a]=order[b];order[b]=t;}
    {int cw[]={8,30,14}; int nc=3; const char *hdr[]={"SN","Name","Publications"};
     tbl_border(cw,nc); tbl_row_plain(hdr,cw,nc); tbl_border(cw,nc);
     for(int i=0;i<g_fac_count;i++){Faculty *m=&g_fac[order[i]];char c[8];sprintf(c,"%d",pubs_for_sn(m->sn));const char *r[]={m->sn,m->full_name,c};tbl_row_plain(r,cw,nc);}
     if(!g_fac_count) printf("  (no data)\n");
     tbl_border(cw,nc); }

    /* ---- ASCII bar charts ---- */
    int maxRApub=0;
    for(int ri=0;ri<n_ra;ri++){int pc2=0;for(int i=0;i<g_fac_count;i++) for(int r=0;r<g_fac[i].ra_count;r++) if(strcmp(g_fac[i].ra[r],all_ra[ri])==0){pc2+=pubs_for_sn(g_fac[i].sn);break;} if(pc2>maxRApub) maxRApub=pc2;}
    int maxRAfac=0;
    for(int ri=0;ri<n_ra;ri++){int fc=0;for(int i=0;i<g_fac_count;i++) for(int r=0;r<g_fac[i].ra_count;r++) if(strcmp(g_fac[i].ra[r],all_ra[ri])==0){fc++;break;} if(fc>maxRAfac) maxRAfac=fc;}
    int maxYr=0; for(int y=0;y<ny;y++) if(yrc[y]>maxYr) maxYr=yrc[y];
    int maxTp=0; for(int t=0;t<nt;t++) if(tpc[t]>maxTp) maxTp=tpc[t];

    printf("\n"); hr2(); printf("  CHART: PUBLICATIONS PER RESEARCH AREA\n"); hr2();
    printf("  %-38s | %-*s | Count\n","Research Area",BAR_WIDTH,"Bar"); hr();
    for(int ri=0;ri<n_ra;ri++){int pc2=0;for(int i=0;i<g_fac_count;i++) for(int r=0;r<g_fac[i].ra_count;r++) if(strcmp(g_fac[i].ra[r],all_ra[ri])==0){pc2+=pubs_for_sn(g_fac[i].sn);break;} bar_chart(all_ra[ri],pc2,maxRApub>0?maxRApub:1,BAR_WIDTH);}
    if(!n_ra) printf("  (no data)\n");

    printf("\n"); hr2(); printf("  CHART: FACULTY PER RESEARCH AREA\n"); hr2();
    printf("  %-38s | %-*s | Count\n","Research Area",BAR_WIDTH,"Bar"); hr();
    for(int ri=0;ri<n_ra;ri++){int fc=0;for(int i=0;i<g_fac_count;i++) for(int r=0;r<g_fac[i].ra_count;r++) if(strcmp(g_fac[i].ra[r],all_ra[ri])==0){fc++;break;} bar_chart(all_ra[ri],fc,maxRAfac>0?maxRAfac:1,BAR_WIDTH);}
    if(!n_ra) printf("  (no data)\n");

    printf("\n"); hr2(); printf("  CHART: YEAR-WISE PUBLICATION COUNT\n"); hr2();
    printf("  %-38s | %-*s | Count\n","Year",BAR_WIDTH,"Bar"); hr();
    for(int y=0;y<ny;y++) bar_chart(yrs[y],yrc[y],maxYr>0?maxYr:1,BAR_WIDTH);
    if(!ny) printf("  (no data)\n");

    printf("\n"); hr2(); printf("  CHART: PUBLICATIONS BY TYPE\n"); hr2();
    printf("  %-38s | %-*s | Count\n","Type",BAR_WIDTH,"Bar"); hr();
    for(int t=0;t<nt;t++) bar_chart(tps[t],tpc[t],maxTp>0?maxTp:1,BAR_WIDTH);
    if(!nt) printf("  (no data)\n");

    pause_enter();
}


/* ================================================================
   REPORT HELPERS: write one aligned text table cell (w chars, pad/clip)
   ================================================================ */
/* fwrite_col already defined earlier */

/* ================================================================
   REPORT: HTML faculty table
   Full Name is <a href="profile_url">Full Name</a>
   ================================================================ */
static void html_fac_table(FILE *h)
{
    fprintf(h,"<table>\n<thead><tr>"
              "<th>ID</th><th>SN</th><th>Full Name</th>"
              "<th>Designation</th><th>Research Area(s)</th>"
              "<th>Publications</th></tr></thead>\n<tbody>\n");
    for(int i=0;i<g_fac_count;i++){
        Faculty *m=&g_fac[i];
        char ra_buf[MAX_TITLE]="";
        for(int r=0;r<m->ra_count;r++){
            if(r>0) strncat(ra_buf,"; ",sizeof(ra_buf)-strlen(ra_buf)-1);
            strncat(ra_buf,m->ra[r],sizeof(ra_buf)-strlen(ra_buf)-1);
        }
        if(!ra_buf[0]) strcpy(ra_buf,"--");
        char pc[8]; sprintf(pc,"%d",pubs_for_sn(m->sn));
        fprintf(h,"<tr><td>%s</td><td>%s</td><td>",m->id,m->sn);
        if(m->profile_url[0])
            fprintf(h,"<a href=\"%s\">%s</a>",m->profile_url,m->full_name);
        else
            fprintf(h,"%s",m->full_name);
        fprintf(h,"</td><td>%s</td><td>%s</td><td>%s</td></tr>\n",
                m->desi,ra_buf,pc);
    }
    fprintf(h,"</tbody>\n</table>\n");
}

/* ================================================================
   REPORT: HTML publication table
   Title is <a href="url">Title</a>
   ================================================================ */
static void html_pub_table(FILE *h, int *indices, int count)
{
    fprintf(h,"<table>\n<thead><tr>"
              "<th>#</th><th>Title</th><th>Year</th><th>Type</th>"
              "<th>Author(s)</th><th>Journal</th>"
              "<th>Research Area(s)</th><th>Indexing</th><th>Cit</th>"
              "</tr></thead>\n<tbody>\n");
    for(int ii=0;ii<count;ii++){
        Publication *p=&g_pub[indices[ii]];
        char auth[MAX_STR]; authors_str(p,auth,sizeof(auth));
        char ra_buf[MAX_TITLE]; pub_ra_display(p,ra_buf,sizeof(ra_buf));
        fprintf(h,"<tr><td>%d</td><td>",ii+1);
        if(p->url[0])
            fprintf(h,"<a href=\"%s\">%s</a>",p->url,p->title);
        else
            fprintf(h,"%s",p->title);
        fprintf(h,"</td><td>%s</td><td>%s</td><td>%s</td>"
                  "<td>%s</td><td>%s</td><td>%s</td><td>%d</td></tr>\n",
                p->year,p->type,auth,p->journal,ra_buf,p->indexing,p->citations);
    }
    fprintf(h,"</tbody>\n</table>\n");
}

/* ================================================================
   REPORT: TXT faculty table  (ID | SN | Full Name | Desi | RA | Profile URL)
   Profile URL is a separate column.
   ================================================================ */
static void txt_fac_table(FILE *f)
{
    /* Compute dynamic widths */
    int w_id=2, w_sn=2, w_name=9, w_desi=11, w_ra=16, w_url=12;
    for(int i=0;i<g_fac_count;i++){
        Faculty *m=&g_fac[i];
        char ra_tmp[MAX_TITLE]="";
        for(int r=0;r<m->ra_count;r++){
            if(r>0) strncat(ra_tmp," / ",sizeof(ra_tmp)-strlen(ra_tmp)-1);
            strncat(ra_tmp,m->ra[r],sizeof(ra_tmp)-strlen(ra_tmp)-1);
        }
        int n;
        n=(int)strlen(m->id);          if(n>w_id)   w_id=n;
        n=(int)strlen(m->sn);          if(n>w_sn)   w_sn=n;
        n=(int)strlen(m->full_name);   if(n>w_name) w_name=n;
        n=(int)strlen(m->desi);        if(n>w_desi) w_desi=n;
        n=(int)strlen(ra_tmp);         if(n>w_ra)   w_ra=n;
        n=(int)strlen(m->profile_url); if(n>w_url)  w_url=n;
    }
    if(w_ra  >50) w_ra  =50;
    if(w_url >60) w_url =60;
    /* Ensure header labels fit */
    if(w_id  <2)  w_id  =2;
    if(w_sn  <2)  w_sn  =2;
    if(w_name<9)  w_name=9;
    if(w_desi<11) w_desi=11;
    if(w_url <11) w_url =11;

    int nc=6;
    int cw[]={w_id,w_sn,w_name,w_desi,w_ra,w_url};
    const char *hdr[]={"ID","SN","Full Name","Designation","Research Area(s)","Profile URL"};
    ftbl_border(f,cw,nc);
    ftbl_row(f,hdr,cw,nc);
    ftbl_border(f,cw,nc);

    for(int i=0;i<g_fac_count;i++){
        Faculty *m=&g_fac[i];
        char ra_buf[MAX_TITLE]="";
        for(int r=0;r<m->ra_count;r++){
            if(r>0) strncat(ra_buf," / ",sizeof(ra_buf)-strlen(ra_buf)-1);
            strncat(ra_buf,m->ra[r],sizeof(ra_buf)-strlen(ra_buf)-1);
        }
        if(!ra_buf[0]) strcpy(ra_buf,"--");

        int ra_len=(int)strlen(ra_buf);
        int r_fc=first_chunk_w(ra_buf,w_ra);

        fprintf(f,"  |");
        fprintf(f," "); fwrite_col(f,m->id,w_id);        fprintf(f," |");
        fprintf(f," "); fwrite_col(f,m->sn,w_sn);        fprintf(f," |");
        fprintf(f," "); fwrite_col(f,m->full_name,w_name);fprintf(f," |");
        fprintf(f," "); fwrite_col(f,m->desi,w_desi);    fprintf(f," |");
        fprintf(f," ");
        for(int k=0;k<r_fc;k++) fputc(ra_buf[k],f);
        for(int k=r_fc;k<w_ra;k++) fputc(' ',f);
        fprintf(f," |");
        fprintf(f," "); fwrite_col(f,m->profile_url[0]?m->profile_url:"--",w_url); fprintf(f," |\n");

        /* RA continuation rows (no blank lines between) */
        int r_pos=r_fc; while(r_pos<ra_len&&ra_buf[r_pos]==' ') r_pos++;
        while(r_pos<ra_len){
            int chunk=w_ra; if(r_pos+chunk>=ra_len) chunk=ra_len-r_pos;
            else{int k=chunk;while(k>0&&ra_buf[r_pos+k]!=' ')k--;if(k>0)chunk=k;}
            fprintf(f,"  |");
            for(int ci=0;ci<4;ci++){fprintf(f," ");fwrite_col(f,"",cw[ci]);fprintf(f," |");}
            fprintf(f," ");
            for(int k=0;k<chunk;k++) fputc(ra_buf[r_pos+k],f);
            for(int k=chunk;k<w_ra;k++) fputc(' ',f);
            fprintf(f," |");
            fprintf(f," "); fwrite_col(f,"",w_url); fprintf(f," |\n");
            r_pos+=chunk; while(r_pos<ra_len&&ra_buf[r_pos]==' ') r_pos++;
        }
    }
    ftbl_border(f,cw,nc);
}

/* ================================================================
   REPORT: TXT publication table  (URL is a separate column)
   ================================================================ */
static void txt_pub_table(FILE *f, int *indices, int count)
{
    if(count==0){ fprintf(f,"  (no publications)\n"); return; }

    /* Compute dynamic column widths */
    int w_num=1, w_title=5, w_year=4, w_type=4,
        w_auth=9, w_jour=7, w_ra=16, w_idx=8, w_cit=3, w_url=3;
    for(int ii=0;ii<count;ii++){
        Publication *p=&g_pub[indices[ii]];
        char auth[MAX_STR]; authors_str(p,auth,sizeof(auth));
        char ra_buf[MAX_TITLE]; pub_ra_display(p,ra_buf,sizeof(ra_buf));
        char num[16]; snprintf(num,sizeof(num),"%d",ii+1);
        char cit[8]; snprintf(cit,sizeof(cit),"%d",p->citations);
        int n;
        n=(int)strlen(num);        if(n>w_num)   w_num=n;
        n=(int)strlen(p->title);   if(n>w_title) w_title=n;
        n=(int)strlen(p->year);    if(n>w_year)  w_year=n;
        n=(int)strlen(p->type);    if(n>w_type)  w_type=n;
        n=(int)strlen(auth);       if(n>w_auth)  w_auth=n;
        n=(int)strlen(p->journal); if(n>w_jour)  w_jour=n;
        n=(int)strlen(ra_buf);     if(n>w_ra)    w_ra=n;
        n=(int)strlen(p->indexing);if(n>w_idx)   w_idx=n;
        n=(int)strlen(cit);        if(n>w_cit)   w_cit=n;
        n=(int)strlen(p->url);     if(n>w_url)   w_url=n;
    }
    /* Cap wrapping columns */
    if(w_title>60) w_title=60;
    if(w_jour >40) w_jour =40;
    if(w_ra   >40) w_ra   =40;
    if(w_auth >20) w_auth =20;
    if(w_idx  >16) w_idx  =16;
    if(w_url  >60) w_url  =60;
    /* Ensure header labels fit */
    if(w_url  < 3) w_url  = 3;

    int nc=10;
    int cw[]={w_num,w_title,w_year,w_type,w_auth,w_jour,w_ra,w_idx,w_cit,w_url};
    const char *hdr[]={"#","Title","Year","Type","Author(s)",
                       "Journal","Research Area(s)","Indexing","Cit","URL"};
    ftbl_border(f,cw,nc);
    ftbl_row(f,hdr,cw,nc);
    ftbl_border(f,cw,nc);

    for(int ii=0;ii<count;ii++){
        Publication *p=&g_pub[indices[ii]];
        char num[16]; snprintf(num,sizeof(num),"%d",ii+1);
        char cit[8];  snprintf(cit,sizeof(cit),"%d",p->citations);
        char auth[MAX_STR];  authors_str(p,auth,sizeof(auth));
        char ra_buf[MAX_TITLE]; pub_ra_display(p,ra_buf,sizeof(ra_buf));

        int title_len=(int)strlen(p->title);
        int jour_len =(int)strlen(p->journal);
        int ra_len   =(int)strlen(ra_buf);
        int url_len  =(int)strlen(p->url);

        int t_fc=first_chunk_w(p->title,  w_title);
        int j_fc=first_chunk_w(p->journal,w_jour);
        int r_fc=first_chunk_w(ra_buf,    w_ra);
        int u_fc=first_chunk_w(p->url,    w_url);

        /* First row */
        fprintf(f,"  |");
        fprintf(f," "); fwrite_col(f,num,w_num);    fprintf(f," |");
        fprintf(f," ");
        for(int k=0;k<t_fc;k++) fputc(p->title[k],f);
        for(int k=t_fc;k<w_title;k++) fputc(' ',f);
        fprintf(f," |");
        fprintf(f," "); fwrite_col(f,p->year,    w_year); fprintf(f," |");
        fprintf(f," "); fwrite_col(f,p->type,    w_type); fprintf(f," |");
        fprintf(f," "); fwrite_col(f,auth,        w_auth); fprintf(f," |");
        fprintf(f," ");
        for(int k=0;k<j_fc;k++) fputc(p->journal[k],f);
        for(int k=j_fc;k<w_jour;k++) fputc(' ',f);
        fprintf(f," |");
        fprintf(f," ");
        for(int k=0;k<r_fc;k++) fputc(ra_buf[k],f);
        for(int k=r_fc;k<w_ra;k++) fputc(' ',f);
        fprintf(f," |");
        fprintf(f," "); fwrite_col(f,p->indexing,w_idx); fprintf(f," |");
        fprintf(f," "); fwrite_col(f,cit,         w_cit); fprintf(f," |");
        fprintf(f," ");
        for(int k=0;k<u_fc;k++) fputc(p->url[k],f);
        for(int k=u_fc;k<w_url;k++) fputc(' ',f);
        fprintf(f," |\n");

        /* Continuation rows -- title, journal, RA, URL each wrap independently */
        {
            int t_pos=t_fc; while(t_pos<title_len&&p->title[t_pos]==' ')   t_pos++;
            int j_pos=j_fc; while(j_pos<jour_len &&p->journal[j_pos]==' ') j_pos++;
            int r_pos=r_fc; while(r_pos<ra_len   &&ra_buf[r_pos]==' ')     r_pos++;
            int u_pos=u_fc; while(u_pos<url_len  &&p->url[u_pos]==' ')     u_pos++;
            while(t_pos<title_len||j_pos<jour_len||r_pos<ra_len||u_pos<url_len){
                fprintf(f,"  |");
                fprintf(f," "); fwrite_col(f,"",w_num); fprintf(f," |");
                /* title */
                fprintf(f," ");
                if(t_pos<title_len){
                    int chunk=w_title; if(t_pos+chunk>=title_len) chunk=title_len-t_pos;
                    else{int k=chunk;while(k>0&&p->title[t_pos+k]!=' ')k--;if(k>0)chunk=k;}
                    for(int k=0;k<chunk;k++) fputc(p->title[t_pos+k],f);
                    for(int k=chunk;k<w_title;k++) fputc(' ',f);
                    t_pos+=chunk; while(t_pos<title_len&&p->title[t_pos]==' ') t_pos++;
                } else fwrite_col(f,"",w_title);
                fprintf(f," |");
                fprintf(f," "); fwrite_col(f,"",w_year); fprintf(f," |");
                fprintf(f," "); fwrite_col(f,"",w_type); fprintf(f," |");
                fprintf(f," "); fwrite_col(f,"",w_auth); fprintf(f," |");
                /* journal */
                fprintf(f," ");
                if(j_pos<jour_len){
                    int chunk=w_jour; if(j_pos+chunk>=jour_len) chunk=jour_len-j_pos;
                    else{int k=chunk;while(k>0&&p->journal[j_pos+k]!=' ')k--;if(k>0)chunk=k;}
                    for(int k=0;k<chunk;k++) fputc(p->journal[j_pos+k],f);
                    for(int k=chunk;k<w_jour;k++) fputc(' ',f);
                    j_pos+=chunk; while(j_pos<jour_len&&p->journal[j_pos]==' ') j_pos++;
                } else fwrite_col(f,"",w_jour);
                fprintf(f," |");
                /* RA */
                fprintf(f," ");
                if(r_pos<ra_len){
                    int chunk=w_ra; if(r_pos+chunk>=ra_len) chunk=ra_len-r_pos;
                    else{int k=chunk;while(k>0&&ra_buf[r_pos+k]!=' ')k--;if(k>0)chunk=k;}
                    for(int k=0;k<chunk;k++) fputc(ra_buf[r_pos+k],f);
                    for(int k=chunk;k<w_ra;k++) fputc(' ',f);
                    r_pos+=chunk; while(r_pos<ra_len&&ra_buf[r_pos]==' ') r_pos++;
                } else fwrite_col(f,"",w_ra);
                fprintf(f," |");
                fprintf(f," "); fwrite_col(f,"",w_idx); fprintf(f," |");
                fprintf(f," "); fwrite_col(f,"",w_cit); fprintf(f," |");
                /* URL */
                fprintf(f," ");
                if(u_pos<url_len){
                    int chunk=w_url; if(u_pos+chunk>=url_len) chunk=url_len-u_pos;
                    else{int k=chunk;while(k>0&&p->url[u_pos+k]!=' ')k--;if(k>0)chunk=k;}
                    for(int k=0;k<chunk;k++) fputc(p->url[u_pos+k],f);
                    for(int k=chunk;k<w_url;k++) fputc(' ',f);
                    u_pos+=chunk; while(u_pos<url_len&&p->url[u_pos]==' ') u_pos++;
                } else fwrite_col(f,"",w_url);
                fprintf(f," |\n");
            }
        }
    }
    ftbl_border(f,cw,nc);
}

/* ================================================================
   REPORT: write summary statistics block to file f (txt or html)
   ================================================================ */
static void write_summary_txt(FILE *f, int *pub_idx, int n_pi)
{
    fprintf(f,"\n----------------------------------------------------------------\n");
    fprintf(f,"  SUMMARY STATISTICS\n");
    fprintf(f,"----------------------------------------------------------------\n");
    fprintf(f,"  Total Faculty         : %d\n",g_fac_count);
    fprintf(f,"  Total Publications    : %d\n\n",n_pi);

    /* Per-faculty */
    fprintf(f,"  Publications per Faculty:\n");
    {
        int w_sn=2,w_name=4,w_desi=11,w_cnt=12;
        for(int i=0;i<g_fac_count;i++){
            int n;
            n=(int)strlen(g_fac[i].sn);       if(n>w_sn)   w_sn=n;
            n=(int)strlen(g_fac[i].full_name); if(n>w_name) w_name=n;
            n=(int)strlen(g_fac[i].desi);      if(n>w_desi) w_desi=n;
        }
        int nc2=4; int cw2[]={w_sn,w_name,w_desi,w_cnt};
        const char *sh[]={"SN","Name","Designation","Publications"};
        ftbl_border(f,cw2,nc2); ftbl_row(f,sh,cw2,nc2); ftbl_border(f,cw2,nc2);
        for(int i=0;i<g_fac_count;i++){
            Faculty *m=&g_fac[i]; int cnt=0;
            for(int k=0;k<n_pi;k++){
                Publication *p=&g_pub[pub_idx[k]];
                for(int a=0;a<p->author_count;a++) if(str_ieq(p->authors[a],m->sn)){cnt++;break;}
            }
            char cs[8]; sprintf(cs,"%d",cnt);
            const char *r[]={m->sn,m->full_name,m->desi,cs}; ftbl_row(f,r,cw2,nc2);
        }
        ftbl_border(f,cw2,nc2);
    }

    /* Year-wise */
    fprintf(f,"\n  Year-wise Count:\n");
    {
        char yrs[64][8]; int yrc[64]; int ny=0;
        for(int k=0;k<n_pi;k++){
            int fd=0; for(int y=0;y<ny;y++) if(strcmp(yrs[y],g_pub[pub_idx[k]].year)==0){yrc[y]++;fd=1;break;}
            if(!fd&&ny<64){strncpy(yrs[ny],g_pub[pub_idx[k]].year,7);yrs[ny][7]='\0';yrc[ny++]=1;}
        }
        for(int a=0;a<ny-1;a++) for(int b=a+1;b<ny;b++) if(strcmp(yrs[a],yrs[b])>0){
            char ty[8];strcpy(ty,yrs[a]);strcpy(yrs[a],yrs[b]);strcpy(yrs[b],ty);
            int tc=yrc[a];yrc[a]=yrc[b];yrc[b]=tc;}
        int nc2=2; int cw2[]={10,12};
        const char *sh[]={"Year","Count"};
        ftbl_border(f,cw2,nc2); ftbl_row(f,sh,cw2,nc2); ftbl_border(f,cw2,nc2);
        for(int y=0;y<ny;y++){char c[8];sprintf(c,"%d",yrc[y]);const char *r[]={yrs[y],c};ftbl_row(f,r,cw2,nc2);}
        ftbl_border(f,cw2,nc2);
    }

    /* Type-wise */
    fprintf(f,"\n  Type-wise Count:\n");
    {
        char tp[10][MAX_STR]; int tpc[10]; int nt=0;
        for(int k=0;k<n_pi;k++){
            int fd=0; for(int t=0;t<nt;t++) if(strcmp(tp[t],g_pub[pub_idx[k]].type)==0){tpc[t]++;fd=1;break;}
            if(!fd&&nt<10){SCOPY(tp[nt],g_pub[pub_idx[k]].type);tpc[nt++]=1;}
        }
        int nc2=2; int cw2[]={18,12};
        const char *sh[]={"Type","Count"};
        ftbl_border(f,cw2,nc2); ftbl_row(f,sh,cw2,nc2); ftbl_border(f,cw2,nc2);
        for(int t=0;t<nt;t++){char c[8];sprintf(c,"%d",tpc[t]);const char *r[]={tp[t],c};ftbl_row(f,r,cw2,nc2);}
        ftbl_border(f,cw2,nc2);
    }
}

static void write_summary_html(FILE *h, int *pub_idx, int n_pi)
{
    fprintf(h,"<h2>Summary Statistics</h2>\n");
    fprintf(h,"<p>Total Faculty: <strong>%d</strong> &nbsp; "
              "Total Publications: <strong>%d</strong></p>\n",g_fac_count,n_pi);

    fprintf(h,"<h3>Publications per Faculty</h3>\n");
    fprintf(h,"<table><thead><tr><th>SN</th><th>Name</th><th>Designation</th><th>Publications</th></tr></thead>\n<tbody>\n");
    for(int i=0;i<g_fac_count;i++){
        Faculty *m=&g_fac[i]; int cnt=0;
        for(int k=0;k<n_pi;k++){
            Publication *p=&g_pub[pub_idx[k]];
            for(int a=0;a<p->author_count;a++) if(str_ieq(p->authors[a],m->sn)){cnt++;break;}
        }
        fprintf(h,"<tr><td>%s</td><td>%s</td><td>%s</td><td>%d</td></tr>\n",m->sn,m->full_name,m->desi,cnt);
    }
    fprintf(h,"</tbody></table>\n");

    /* Year-wise */
    {
        char yrs[64][8]; int yrc[64]; int ny=0;
        for(int k=0;k<n_pi;k++){
            int fd=0; for(int y=0;y<ny;y++) if(strcmp(yrs[y],g_pub[pub_idx[k]].year)==0){yrc[y]++;fd=1;break;}
            if(!fd&&ny<64){strncpy(yrs[ny],g_pub[pub_idx[k]].year,7);yrs[ny][7]='\0';yrc[ny++]=1;}
        }
        for(int a=0;a<ny-1;a++) for(int b=a+1;b<ny;b++) if(strcmp(yrs[a],yrs[b])>0){
            char ty[8];strcpy(ty,yrs[a]);strcpy(yrs[a],yrs[b]);strcpy(yrs[b],ty);
            int tc=yrc[a];yrc[a]=yrc[b];yrc[b]=tc;}
        fprintf(h,"<h3>Publications by Year</h3>\n<table><thead><tr><th>Year</th><th>Count</th></tr></thead>\n<tbody>\n");
        for(int y=0;y<ny;y++) fprintf(h,"<tr><td>%s</td><td>%d</td></tr>\n",yrs[y],yrc[y]);
        fprintf(h,"</tbody></table>\n");
    }

    /* Type-wise */
    {
        char tp[10][MAX_STR]; int tpc[10]; int nt=0;
        for(int k=0;k<n_pi;k++){
            int fd=0; for(int t=0;t<nt;t++) if(strcmp(tp[t],g_pub[pub_idx[k]].type)==0){tpc[t]++;fd=1;break;}
            if(!fd&&nt<10){SCOPY(tp[nt],g_pub[pub_idx[k]].type);tpc[nt++]=1;}
        }
        fprintf(h,"<h3>Publications by Type</h3>\n<table><thead><tr><th>Type</th><th>Count</th></tr></thead>\n<tbody>\n");
        for(int t=0;t<nt;t++) fprintf(h,"<tr><td>%s</td><td>%d</td></tr>\n",tp[t],tpc[t]);
        fprintf(h,"</tbody></table>\n");
    }
}

/* ================================================================
   SCREEN: GENERATE REPORT  (stays in loop until option 4)
   Produces TWO files per report: .txt (plain table) and .html (styled)
   ================================================================ */
static void screen_generate_report(void)
{
    while(1){
        clrscr(); section("GENERATE REPORT");
        printf("\n  Report types:\n");
        printf("    [1] Annual Departmental Report    (all publications for a chosen year)\n");
        printf("    [2] Accreditation Documentation   (all-time + designation breakdown)\n");
        printf("    [3] Custom Filter Report          (filter by RA / year / type)\n");
        printf("    [4] Exit Report Generation\n\n");

        char sel[4]="";
        while(1){
            prompt("Report type (1-4)",sel,sizeof(sel));
            if(strlen(sel)==1&&sel[0]>='1'&&sel[0]<='4') break;
            printf("  [Error] Please enter 1, 2, 3, or 4.\n");
        }
        if(sel[0]=='4') return;
        int rtype=atoi(sel);

        /* Collect year/type/RA lists */
        char yrs[64][8]; int ny=0;
        for(int i=0;i<g_pub_count;i++){
            int f=0; for(int y=0;y<ny;y++) if(strcmp(yrs[y],g_pub[i].year)==0){f=1;break;}
            if(!f&&ny<64){strncpy(yrs[ny],g_pub[i].year,7);yrs[ny][7]='\0';ny++;}
        }
        for(int a=0;a<ny-1;a++) for(int b=a+1;b<ny;b++) if(strcmp(yrs[a],yrs[b])>0){char ty[8];strcpy(ty,yrs[a]);strcpy(yrs[a],yrs[b]);strcpy(yrs[b],ty);}

        char tps[10][MAX_STR]; int nt=0;
        for(int i=0;i<g_pub_count;i++){int f=0;for(int t=0;t<nt;t++) if(strcmp(tps[t],g_pub[i].type)==0){f=1;break;}if(!f&&nt<10)SCOPY(tps[nt++],g_pub[i].type);}

        static char all_ra2[MAX_FACULTY*MAX_RA][MAX_STR];
        int n_ra2=0; memset(all_ra2,0,sizeof(all_ra2));
        for(int i=0;i<g_fac_count;i++)
            for(int r=0;r<g_fac[i].ra_count;r++){
                int dup=0; for(int x=0;x<n_ra2;x++) if(strcmp(all_ra2[x],g_fac[i].ra[r])==0){dup=1;break;}
                if(!dup&&n_ra2<MAX_FACULTY*MAX_RA){strncpy(all_ra2[n_ra2],g_fac[i].ra[r],MAX_STR-1);all_ra2[n_ra2][MAX_STR-1]='\0';n_ra2++;}
            }

        char selected_year[MAX_STR]="";
        char filter_by[MAX_STR]="";
        char filter_val[MAX_STR]="";

        if(rtype==1){
            if(ny==0){printf("  No publications.\n");pause_enter();continue;}
            printf("\n  Available years: ");
            for(int y=0;y<ny;y++){if(y>0)printf(", ");printf("%s",yrs[y]);}
            printf("\n");
            while(1){
                if(!prompt("Enter year",selected_year,sizeof(selected_year))){printf("  [Error] Required.\n");continue;}
                int found=0; for(int y=0;y<ny;y++) if(strcmp(yrs[y],selected_year)==0){found=1;break;}
                if(found) break;
                printf("  [Error] '%s' not found. Available: ",selected_year);
                for(int y=0;y<ny;y++){if(y>0)printf(", ");printf("%s",yrs[y]);}
                printf("\n");
            }
        } else if(rtype==3){
            printf("\n  Filter by:\n");
            printf("    [1] Research Area\n    [2] Year\n    [3] Publication Type\n    [0] No filter (show all)\n\n");
            char fsub[4]="";
            while(1){
                prompt("Filter choice (0-3)",fsub,sizeof(fsub));
                if(strlen(fsub)==1&&fsub[0]>='0'&&fsub[0]<='3') break;
                printf("  [Error] Enter 0, 1, 2, or 3.\n");
            }
            if(fsub[0]=='1'){
                SCOPY(filter_by,"research_area");
                if(n_ra2==0){printf("  No research areas.\n");pause_enter();continue;}
                printf("  Areas:\n");
                for(int r=0;r<n_ra2;r++) printf("    [%d] %s\n",r+1,all_ra2[r]);
                while(1){
                    char rs[8]=""; prompt("Select number",rs,sizeof(rs));
                    int ri=atoi(rs)-1;
                    if(ri>=0&&ri<n_ra2){SCOPY(filter_val,all_ra2[ri]);break;}
                    printf("  [Error] Enter 1-%d.\n",n_ra2);
                }
            } else if(fsub[0]=='2'){
                SCOPY(filter_by,"year");
                if(ny==0){printf("  No years.\n");pause_enter();continue;}
                printf("  Years:\n");
                for(int y=0;y<ny;y++) printf("    [%d] %s\n",y+1,yrs[y]);
                while(1){
                    char ys2[8]=""; prompt("Select number",ys2,sizeof(ys2));
                    int yi=atoi(ys2)-1;
                    if(yi>=0&&yi<ny){SCOPY(filter_val,yrs[yi]);break;}
                    printf("  [Error] Enter 1-%d.\n",ny);
                }
            } else if(fsub[0]=='3'){
                SCOPY(filter_by,"pub_type");
                if(nt==0){printf("  No types.\n");pause_enter();continue;}
                printf("  Types:\n");
                for(int t=0;t<nt;t++) printf("    [%d] %s\n",t+1,tps[t]);
                while(1){
                    char ts2[8]=""; prompt("Select number",ts2,sizeof(ts2));
                    int ti=atoi(ts2)-1;
                    if(ti>=0&&ti<nt){SCOPY(filter_val,tps[ti]);break;}
                    printf("  [Error] Enter 1-%d.\n",nt);
                }
            }
        }

        /* Build publication subset */
        int pub_idx[MAX_PUBS]; int n_pi=0;
        for(int i=0;i<g_pub_count;i++){
            int inc=0;
            if(rtype==1) inc=str_ieq(g_pub[i].year,selected_year);
            else if(rtype==2) inc=1;
            else{
                if(!filter_by[0]) inc=1;
                else if(str_ieq(filter_by,"year")) inc=str_ieq(g_pub[i].year,filter_val);
                else if(str_ieq(filter_by,"pub_type")) inc=str_ihas(g_pub[i].type,filter_val);
                else if(str_ieq(filter_by,"research_area")){
                    for(int f=0;f<g_fac_count&&!inc;f++){
                        int fm=0;
                        for(int r=0;r<g_fac[f].ra_count&&!fm;r++) if(str_ihas(g_fac[f].ra[r],filter_val)) fm=1;
                        if(fm) for(int a=0;a<g_pub[i].author_count&&!inc;a++) if(str_ieq(g_pub[i].authors[a],g_fac[f].sn)) inc=1;
                    }
                }
            }
            if(inc&&n_pi<MAX_PUBS) pub_idx[n_pi++]=i;
        }

        /* Build base filename (without extension) */
        MKDIR(REPORTS_DIR);
        char ts_fn[MAX_STR]; now_str(ts_fn);
        for(int i=0;ts_fn[i];i++) if(ts_fn[i]==' '||ts_fn[i]==':'||ts_fn[i]=='-') ts_fn[i]='_';
        ts_fn[19]='\0';
        char base[MAX_TITLE*2];
        if(rtype==1)      snprintf(base,sizeof(base),"%s/annual_%s_%s",REPORTS_DIR,selected_year,ts_fn);
        else if(rtype==2) snprintf(base,sizeof(base),"%s/accreditation_%s",REPORTS_DIR,ts_fn);
        else              snprintf(base,sizeof(base),"%s/custom_%s",REPORTS_DIR,ts_fn);

        char fname_txt[MAX_TITLE*2+8], fname_html[MAX_TITLE*2+8];
        snprintf(fname_txt, sizeof(fname_txt), "%s.txt",  base);
        snprintf(fname_html,sizeof(fname_html),"%s.html", base);

        char ts_now[MAX_STR]; now_str(ts_now);
        char last_edit[MAX_STR]; get_last_edit_time(last_edit);

        /* ============================================================
           WRITE TXT REPORT
           ============================================================ */
        FILE *rep=fopen(fname_txt,"w");
        if(!rep){printf("  [Error] Cannot create TXT report.\n");pause_enter();continue;}

        fprintf(rep,"================================================================\n");
        fprintf(rep,"  Department of Mechanical Engineering, BUET\n");
        fprintf(rep,"  Research Publication Database System -- RPDS v6.0\n");
        fprintf(rep,"================================================================\n\n");
        if(rtype==1)      fprintf(rep,"  ANNUAL DEPARTMENTAL REPORT -- Year: %s\n\n  Generated: %s\n\n",selected_year,ts_now);
        else if(rtype==2) fprintf(rep,"  ACCREDITATION DOCUMENTATION\n\n  Generated: %s\n\n",ts_now);
        else{
            fprintf(rep,"  CUSTOM FILTER REPORT\n");
            if(filter_by[0]) fprintf(rep,"  Filter: %s = %s\n",filter_by,filter_val);
            fprintf(rep,"  Generated: %s\n\n",ts_now);
        }

        if(rtype==2){
            fprintf(rep,"----------------------------------------------------------------\n");
            fprintf(rep,"  FACULTY BY DESIGNATION\n");
            fprintf(rep,"----------------------------------------------------------------\n");
            const char *ds2[]={"Professor","Associate Professor","Assistant Professor","Lecturer"};
            int dc2[4]={0,0,0,0};
            for(int i=0;i<g_fac_count;i++) for(int d=0;d<4;d++) if(strcmp(g_fac[i].desi,ds2[d])==0) dc2[d]++;
            for(int d=0;d<4;d++) fprintf(rep,"  %-26s : %d\n",ds2[d],dc2[d]);
            fprintf(rep,"  %-26s : %d\n","TOTAL",g_fac_count);
            fprintf(rep,"\n");
            fprintf(rep,"----------------------------------------------------------------\n");
            fprintf(rep,"  ALL FACULTY  (Profile URL in separate column)\n");
            fprintf(rep,"----------------------------------------------------------------\n\n");
            txt_fac_table(rep);
            fprintf(rep,"\n");
        }

        fprintf(rep,"----------------------------------------------------------------\n");
        if(rtype==1) fprintf(rep,"  PUBLICATIONS IN %s  (%d record(s))  -- URL in separate column\n",selected_year,n_pi);
        else         fprintf(rep,"  PUBLICATIONS  (%d record(s))  -- URL in separate column\n",n_pi);
        fprintf(rep,"----------------------------------------------------------------\n\n");
        if(n_pi==0) fprintf(rep,"  No publications match the selected criteria.\n\n");
        else        txt_pub_table(rep,pub_idx,n_pi);

        if(rtype==1||rtype==2) write_summary_txt(rep,pub_idx,n_pi);

        fprintf(rep,"\n================================================================\n");
        fprintf(rep,"  Database last edited: %s\n",last_edit);
        fprintf(rep,"  End of Report\n");
        fprintf(rep,"================================================================\n");
        fclose(rep);

        /* ============================================================
           WRITE HTML REPORT
           ============================================================ */
        FILE *htm=fopen(fname_html,"w");
        if(!htm){printf("  [Error] Cannot create HTML report.\n");pause_enter();continue;}

        /* Determine title string */
        char htitle[MAX_STR*4];
        if(rtype==1)      snprintf(htitle,sizeof(htitle),"Annual Report %s",selected_year);
        else if(rtype==2) snprintf(htitle,sizeof(htitle),"Accreditation Documentation");
        else{
            if(filter_by[0]) snprintf(htitle,sizeof(htitle),"Custom Report: %s = %s",filter_by,filter_val);
            else              snprintf(htitle,sizeof(htitle),"Custom Report (All)");
        }

        fprintf(htm,"<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n");
        fprintf(htm,"<meta charset=\"UTF-8\">\n");
        fprintf(htm,"<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">\n");
        fprintf(htm,"<title>RPDS Report - %s</title>\n",htitle);
        fprintf(htm,"<style>\n"
"  body{font-family:Arial,Helvetica,sans-serif;margin:2em;color:#1a1a1a;background:#f9f9f9;}\n"
"  h1{color:#003366;border-bottom:3px solid #003366;padding-bottom:.4em;}\n"
"  h2{color:#003366;margin-top:1.8em;}\n"
"  h3{color:#005599;margin-top:1.2em;}\n"
"  .meta{color:#555;font-size:.9em;margin-bottom:1.5em;}\n"
"  table{border-collapse:collapse;width:100%%;margin:1em 0;font-size:.9em;}\n"
"  th{background:#003366;color:#fff;padding:8px 10px;text-align:left;white-space:nowrap;}\n"
"  td{padding:6px 10px;border-bottom:1px solid #ddd;vertical-align:top;}\n"
"  tr:nth-child(even){background:#f2f7ff;}\n"
"  tr:hover{background:#ddeeff;}\n"
"  a{color:#0055aa;text-decoration:none;}\n"
"  a:hover{text-decoration:underline;}\n"
"  .stat-block{background:#eef3ff;border-left:4px solid #003366;padding:.8em 1.2em;margin:1em 0;}\n"
"  @media print{body{background:#fff;}th{-webkit-print-color-adjust:exact;}}\n"
"</style>\n</head>\n<body>\n");

        fprintf(htm,"<h1>Department of Mechanical Engineering, BUET</h1>\n");
        fprintf(htm,"<h2>%s</h2>\n",htitle);
        fprintf(htm,"<p class=\"meta\">Generated: %s &nbsp;|&nbsp; Database last edited: %s</p>\n",ts_now,last_edit);

        if(rtype==2){
            fprintf(htm,"<h2>Faculty by Designation</h2>\n");
            const char *ds2[]={"Professor","Associate Professor","Assistant Professor","Lecturer"};
            int dc2[4]={0,0,0,0};
            for(int i=0;i<g_fac_count;i++) for(int d=0;d<4;d++) if(strcmp(g_fac[i].desi,ds2[d])==0) dc2[d]++;
            fprintf(htm,"<table><thead><tr><th>Designation</th><th>Count</th></tr></thead>\n<tbody>\n");
            for(int d=0;d<4;d++) fprintf(htm,"<tr><td>%s</td><td>%d</td></tr>\n",ds2[d],dc2[d]);
            fprintf(htm,"<tr><td><strong>TOTAL</strong></td><td><strong>%d</strong></td></tr>\n",g_fac_count);
            fprintf(htm,"</tbody></table>\n");

            fprintf(htm,"<h2>All Faculty</h2>\n<p><em>Faculty names link to their profile pages.</em></p>\n");
            html_fac_table(htm);
        }

        if(rtype==1) fprintf(htm,"<h2>Publications in %s (%d record(s))</h2>\n",selected_year,n_pi);
        else         fprintf(htm,"<h2>Publications (%d record(s))</h2>\n",n_pi);
        fprintf(htm,"<p><em>Publication titles link to their DOI / URL.</em></p>\n");
        if(n_pi==0) fprintf(htm,"<p>No publications match the selected criteria.</p>\n");
        else        html_pub_table(htm,pub_idx,n_pi);

        if(rtype==1||rtype==2) write_summary_html(htm,pub_idx,n_pi);

        fprintf(htm,"</body>\n</html>\n");
        fclose(htm);

        printf("\n  [OK] Reports saved:\n");
        printf("       TXT : %s\n", fname_txt);
        printf("       HTML: %s\n", fname_html);
        pause_enter();
    }
}

/* ================================================================
   SCREEN: ACTIVITY LOG
   ================================================================ */
static void screen_history(void)
{
    clrscr(); section("ACTIVITY LOG");
    FILE *f=fopen(HISTORY_FILE,"r");
    if(!f){printf("\n  No activity logged yet.\n");pause_enter();return;}
    char lines[MAX_HIST][MAX_TITLE]; int cnt=0;
    while(cnt<MAX_HIST&&fgets(lines[cnt],MAX_TITLE,f)){
        int n=(int)strlen(lines[cnt]);
        while(n>0&&(lines[cnt][n-1]=='\n'||lines[cnt][n-1]=='\r')) lines[cnt][--n]='\0';
        cnt++;
    }
    fclose(f);
    if(!cnt){printf("\n  Log empty.\n");pause_enter();return;}
    printf("\n");
    for(int i=cnt-1;i>=0;i--) printf("  %s\n",lines[i]);
    printf("\n  Total: %d entries\n",cnt);
    pause_enter();
}

/* ================================================================
   SCREEN: UNDO
   ================================================================ */
static void screen_undo(void)
{
    clrscr(); section("UNDO LAST CHANGE");
    printf("\n  Restores faculty and publications to state before last change.\n\n");
    char cf[16]=""; prompt("Type 'yes' to confirm",cf,sizeof(cf));
    if(strcmp(cf,"yes")!=0){printf("  Cancelled.\n");pause_enter();return;}
    if(restore_undo_snapshot()){
        log_action(g_admin,"UNDO","Restored previous snapshot");
        printf("\n  [OK] Last change has been undone.\n");
    } else {
        printf("\n  [Error] No undo snapshot found.\n");
    }
    pause_enter();
}

/* ================================================================
   MAIN MENU
   ================================================================ */
static void show_menu(int admin)
{
    hr2();
    printf("  Research Publication Database System  --  RPDS v6.0\n");
    printf("  Department of Mechanical Engineering, BUET\n");
    hr2(); printf("\n");
    if(admin) printf("  Logged in as: %s\n\n",g_admin);

    printf("  ---- View / Search ----\n");
    printf("    [1] View All Faculty\n");
    printf("    [2] View All Publications\n");
    printf("    [3] Search\n");
    printf("    [4] System Overview\n");
    printf("    [5] Generate Report\n");

    if(admin){
        printf("\n  ---- Admin ----\n");
        printf("    [6] Add Faculty\n");
        printf("    [7] Edit Faculty\n");
        printf("    [8] Delete Faculty\n");
        printf("    [9] Add Publication\n");
        printf("    [A] Edit Publication\n");
        printf("    [B] Delete Publication\n");
        printf("    [C] Undo Last Change\n");
        printf("    [D] Activity Log\n");
        printf("    [E] Logout\n");
    } else {
        printf("\n    [6] Admin Login\n");
    }
    printf("\n    [0] Exit\n\n");
    hr();
}

static void main_menu(void)
{
    char sel[8];
    while(1){
        clrscr();
        show_menu(logged_in());
        prompt("Choice",sel,sizeof(sel));

        /* Exact single-character matching -- reject "AQ" etc. */
        if(strlen(sel)!=1){
            printf("  [Error] Invalid choice.\n");
            pause_enter(); continue;
        }

        char c=(char)toupper((unsigned char)sel[0]);

        if(c=='0') break;

        switch(c){
            case '1': screen_view_faculty(); break;
            case '2': screen_view_pubs();    break;
            case '3': screen_search();       break;
            case '4': screen_overview();     break;
            case '5': screen_generate_report(); break;
            case '6':
                if(logged_in()) screen_add_faculty();
                else            screen_login();
                break;
            case '7': if(logged_in()) screen_edit_faculty();   else{printf("  [Error] Admin login required.\n");pause_enter();}break;
            case '8': if(logged_in()) screen_delete_faculty(); else{printf("  [Error] Admin login required.\n");pause_enter();}break;
            case '9': if(logged_in()) screen_add_pub();        else{printf("  [Error] Admin login required.\n");pause_enter();}break;
            case 'A': if(logged_in()) screen_edit_pub();       else{printf("  [Error] Admin login required.\n");pause_enter();}break;
            case 'B': if(logged_in()) screen_delete_pub();     else{printf("  [Error] Admin login required.\n");pause_enter();}break;
            case 'C': if(logged_in()) screen_undo();           else{printf("  [Error] Admin login required.\n");pause_enter();}break;
            case 'D': if(logged_in()) screen_history();        else{printf("  [Error] Admin login required.\n");pause_enter();}break;
            case 'E': if(logged_in()) screen_logout(); break;
            default:
                printf("  [Error] Invalid choice '%c'. Please try again.\n",c);
                pause_enter();
                break;
        }
    }
    pause_any_key();
}

/* ================================================================
   ENTRY POINT
   ================================================================ */
int main(void)
{
    enable_ansi();
    MKDIR(REPORTS_DIR);
    load_faculty();
    load_pubs();
    main_menu();
    return 0;
}
