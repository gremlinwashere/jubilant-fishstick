#ifndef __STDC_VERSION__
  #error "rpds.c requires C99 or later. In Code::Blocks: Project > Build Options > Other compiler options > add: -std=c99"
#elif __STDC_VERSION__ < 199901L
  #error "rpds.c requires C99 or later. In Code::Blocks: Project > Build Options > Other compiler options > add: -std=c99"
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>

/* Forward declaration of ANSI support flag -- set by enable_ansi() */
static int g_ansi_ok = 0;   /* 1 if terminal supports ANSI/VT100 escape codes */

#ifdef _WIN32
  #include <direct.h>
  #include <conio.h>
  #define MKDIR(p)   _mkdir(p)          /* Windows directory creation */
  #define CLEAR_CMD  "cls"              /* Windows screen clear command */
  /* Enable VT100 / ANSI on Windows 10+ (for hyperlinks only) */
  #include <windows.h>
  /* Attempts to enable VT100 processing on the Windows console handle */
  static void enable_ansi(void){
      HANDLE h=GetStdHandle(STD_OUTPUT_HANDLE);   /* Get stdout console handle */
      DWORD m=0;
      if(GetConsoleMode(h,&m)){                   /* Read current console mode flags */
          if(SetConsoleMode(h,m|ENABLE_VIRTUAL_TERMINAL_PROCESSING))  /* Add VT100 flag */
              g_ansi_ok=1;                        /* Mark ANSI as available if successful */
      }
  }
#else
  #include <sys/stat.h>
  #include <unistd.h>
  #define MKDIR(p)   mkdir((p),0755)    /* POSIX directory creation with rwxr-xr-x permissions */
  #define CLEAR_CMD  "clear"            /* POSIX screen clear command */
  static void enable_ansi(void){ g_ansi_ok=1; }  /* ANSI always supported on POSIX terminals */
#endif

/* ================================================================
   CONSTANTS
   ================================================================ */
#define MAX_FACULTY        200    /* Maximum number of faculty records in memory */
#define MAX_PUBS           500    /* Maximum number of publication records in memory */
#define MAX_RA             10     /* Maximum research areas per faculty member */
#define MAX_AUTHORS        10     /* Maximum authors per publication */
#define MAX_STR            256    /* General-purpose string buffer size */
#define MAX_TITLE          512    /* Larger buffer for titles, URLs, and long fields */
#define MAX_HIST           2000   /* Maximum history log lines to load at once */
#define MAX_LOGIN_TRIES    3      /* Wrong credentials before triggering lockout */
#define LOCKOUT_SECS       15     /* Lockout duration in seconds after too many bad logins */
#define BAR_WIDTH          40     /* Width of ASCII bar chart bars in characters */

/* Data files */
#define FACULTY_FILE      "faculty.txt"           /* Primary faculty data file */
#define PUB_FILE          "publications.txt"       /* Primary publications data file */
#define UNDO_FAC_FILE     "undo_faculty.txt"       /* Undo snapshot for faculty */
#define UNDO_PUB_FILE     "undo_publications.txt"  /* Undo snapshot for publications */
#define HISTORY_FILE      "history.txt"            /* Activity log file */
#define REPORTS_DIR       "reports"                /* Output directory for generated reports */

/* ================================================================
   DATA STRUCTURES
   ================================================================ */
typedef struct {
    char id[MAX_STR];               /* Unique faculty ID, e.g. "MEF-01" */
    char sn[MAX_STR];               /* Short name / initials, e.g. "MHK" */
    char full_name[MAX_STR];        /* Full name in title case */
    char desi[MAX_STR];             /* Designation, e.g. "Professor" */
    char ra[MAX_RA][MAX_STR];       /* Array of research area strings */
    int  ra_count;                  /* Number of research areas actually filled */
    char profile_url[MAX_TITLE];    /* URL to faculty profile page (optional) */
    char last_edited_by[MAX_STR];   /* Admin ID who last modified this record */
    char last_edited_at[MAX_STR];   /* Timestamp of last modification */
} Faculty;

typedef struct {
    char title[MAX_TITLE];              /* Full publication title */
    char year[MAX_STR];                 /* Publication year as string */
    char type[MAX_STR];                 /* Type: Journal / Conference / Review / Book Chapter */
    char authors[MAX_AUTHORS][MAX_STR]; /* Array of author short names (SNs) */
    int  author_count;                  /* Number of authors actually filled */
    char journal[MAX_TITLE];            /* Journal or conference name */
    char url[MAX_TITLE];                /* DOI or URL (optional) */
    char indexing[MAX_STR];             /* Indexing info, e.g. "Scopus, SCI" */
    int  citations;                     /* Citation count */
    char last_edited_by[MAX_STR];       /* Admin ID who last modified this record */
    char last_edited_at[MAX_STR];       /* Timestamp of last modification */
} Publication;

/* ================================================================
   GLOBALS
   ================================================================ */
static Faculty     g_fac[MAX_FACULTY];      /* In-memory array of all faculty records */
static int         g_fac_count  = 0;        /* Current number of loaded faculty records */
static Publication g_pub[MAX_PUBS];         /* In-memory array of all publication records */
static int         g_pub_count  = 0;        /* Current number of loaded publication records */
static char        g_admin[MAX_STR] = "";   /* Currently logged-in admin ID; empty if no one logged in */
static int         g_attempts        = 0;   /* Consecutive failed login attempts counter */
static time_t      g_locked_until    = 0;   /* Unix timestamp until which login is locked out */

/* Hardcoded admin credentials -- IDs and matching passwords in parallel arrays */
static const char *ADMIN_IDS[6] =
    {"admin-1","admin-2","admin-3","admin-4","admin-5","admin-6"};
static const char *ADMIN_PWD[6] =
    {"jannat67","abiba68","nirob69","nafis70","rahat71","hridoy72"};

/* ================================================================
   STRING HELPERS
   ================================================================ */

/* Removes leading and trailing whitespace from string s in-place */
static void trim(char *s)
{
    char *p=s;
    while(isspace((unsigned char)*p)) p++;          /* Advance past leading whitespace */
    if(p!=s) memmove(s,p,strlen(p)+1);              /* Shift string left to remove leading spaces */
    int n=(int)strlen(s);
    while(n>0&&isspace((unsigned char)s[n-1])) s[--n]='\0';  /* Null-terminate to strip trailing spaces */
}

/* Converts string s to uppercase in-place */
static void str_upper(char *s)
{ for(;*s;s++) *s=(char)toupper((unsigned char)*s); }

/* Converts string s to title case (first letter of each word uppercased) in-place */
static void to_title_case(char *s)
{
    int nw=1;                                                   /* Flag: next char starts a new word */
    for(;*s;s++){
        if(isspace((unsigned char)*s))      nw=1;              /* Space resets the new-word flag */
        else if(nw){*s=(char)toupper((unsigned char)*s);nw=0;} /* Capitalize first letter of word */
        else         *s=(char)tolower((unsigned char)*s);      /* Lowercase rest of word */
    }
}

/* Case-insensitive equality check: returns 1 if strings a and b are equal, 0 otherwise */
static int str_ieq(const char *a,const char *b)
{
    char ca[MAX_TITLE],cb[MAX_TITLE];
    strncpy(ca,a,MAX_TITLE-1); ca[MAX_TITLE-1]='\0';   /* Copy a into local buffer safely */
    strncpy(cb,b,MAX_TITLE-1); cb[MAX_TITLE-1]='\0';   /* Copy b into local buffer safely */
    str_upper(ca); str_upper(cb);                        /* Uppercase both for comparison */
    return strcmp(ca,cb)==0;                             /* Return 1 if equal after normalizing case */
}

/* Case-insensitive substring search: returns 1 if ndl is found in hay (or ndl is empty) */
static int str_ihas(const char *hay,const char *ndl)
{
    char h[MAX_TITLE],n[MAX_TITLE];
    if(!ndl||!ndl[0]) return 1;                         /* Empty needle always matches */
    strncpy(h,hay,MAX_TITLE-1); h[MAX_TITLE-1]='\0';   /* Copy haystack safely */
    strncpy(n,ndl,MAX_TITLE-1); n[MAX_TITLE-1]='\0';   /* Copy needle safely */
    str_upper(h); str_upper(n);                          /* Uppercase both for case-insensitive search */
    return strstr(h,n)!=NULL;                            /* Return 1 if needle found in haystack */
}

/* Writes current local date-time into buf as "YYYY-MM-DD HH:MM:SS" */
static void now_str(char *buf)
{
    time_t t=time(NULL);                             /* Get current Unix timestamp */
    struct tm *tm=localtime(&t);                     /* Convert to local time struct */
    strftime(buf,MAX_STR,"%Y-%m-%d %H:%M:%S",tm);   /* Format timestamp into buffer */
}

/* Safe string copy macro: copies src into dst, always null-terminates using sizeof(dst) */
#define SCOPY(dst,src) do{strncpy((dst),(src),sizeof(dst)-1);(dst)[sizeof(dst)-1]='\0';}while(0)

/* ================================================================
   PIPE-FIELD HELPERS
   ================================================================ */

/* Extracts the next pipe-delimited field from *ln into out (max sz bytes); advances *ln past the '|' */
static int next_field(const char **ln, char *out, int sz)
{
    out[0]='\0';
    if(!*ln||!**ln) return 0;                                       /* Nothing left to parse */
    const char *s=*ln, *e=strchr(s,'|');                            /* Find next pipe delimiter */
    if(e){ int n=(int)(e-s); if(n>sz-1)n=sz-1; strncpy(out,s,n); out[n]='\0'; *ln=e+1; }  /* Field before pipe */
    else { strncpy(out,s,sz-1); out[sz-1]='\0'; *ln=s+strlen(s); }                         /* Last field, no pipe */
    trim(out); return 1;                                            /* Trim whitespace and return success */
}

/* Splits semicolon-separated string s into items array (max mx items); returns item count */
static int split_list(const char *s, char items[][MAX_STR], int mx)
{
    int c=0; char cp[MAX_TITLE];
    strncpy(cp,s,MAX_TITLE-1); cp[MAX_TITLE-1]='\0';   /* Copy input to writable buffer */
    int n=(int)strlen(cp);
    while(n>0&&cp[n-1]==';') cp[--n]='\0';              /* Strip trailing semicolons */
    if(!cp[0]) return 0;                                 /* Empty string: return 0 items */
    char *t=strtok(cp,";");                              /* Tokenize by semicolon */
    while(t&&c<mx){ trim(t); if(t[0]){strncpy(items[c],t,MAX_STR-1);items[c][MAX_STR-1]='\0';c++;} t=strtok(NULL,";"); }  /* Collect non-empty tokens */
    return c;                                            /* Return number of items found */
}

/* Joins items array of c strings into out (max sz bytes) separated by semicolons */
static void join_list(char items[][MAX_STR], int c, char *out, int sz)
{
    out[0]='\0';
    for(int i=0;i<c;i++){
        if(i>0) strncat(out,";",sz-strlen(out)-1);         /* Append semicolon separator between items */
        strncat(out,items[i],sz-strlen(out)-1);             /* Append item, respecting buffer limit */
    }
}

/* ================================================================
   DISPLAY / UI HELPERS
   ================================================================ */
static void clrscr(void) { system(CLEAR_CMD); }    /* Clear the terminal screen */
static void hr(void)     { printf("----------------------------------------------------------------\n"); }   /* Print a single-line horizontal rule */
static void hr2(void)    { printf("================================================================\n"); }   /* Print a double-line horizontal rule */

/* Prints a section header with double-line rules above and below */
static void section(const char *t){ hr2(); printf("  %s\n",t); hr2(); }

/* Prints string s in a fixed-width column of w chars: pads with spaces or hard-clips, no truncation marker */
static void pcol(const char *s, int w)
{
    int n=(int)strlen(s);
    if(n<=w){ printf("%s",s); for(int i=n;i<w;i++) putchar(' '); }  /* Fits: print then pad */
    else     { for(int i=0;i<w;i++) putchar(s[i]); }                 /* Too long: hard clip to w chars */
}

/* Displays a labeled prompt, reads a line into buf; returns 1 if non-empty result */
static int prompt(const char *lbl, char *buf, int sz)
{
    printf("  %-30s: ",lbl); fflush(stdout);              /* Print left-aligned label, flush */
    if(!fgets(buf,sz,stdin)){buf[0]='\0';return 0;}        /* Read input; return 0 on EOF/error */
    int n=(int)strlen(buf);
    if(n>0&&buf[n-1]=='\n') buf[n-1]='\0';                /* Strip trailing newline */
    n=(int)strlen(buf);
    if(n>0&&buf[n-1]=='\r') buf[n-1]='\0';                /* Strip trailing carriage return (Windows) */
    trim(buf); return buf[0]!='\0';                        /* Trim whitespace; return 1 if non-empty */
}

/* Reads a password with '*' masking on Windows, plain echo on POSIX */
static void read_password(char *buf, int sz)
{
    printf("  %-30s: ","Password"); fflush(stdout);
#ifdef _WIN32
    int i=0,c;
    while(i<sz-1){
        c=_getch();                                             /* Read char without echo */
        if(c=='\r'||c=='\n') break;                            /* Enter key ends input */
        if((c=='\b'||c==127)&&i>0){i--;printf("\b \b");fflush(stdout);continue;}  /* Backspace handling */
        if(c<32) continue;                                      /* Ignore other control characters */
        buf[i++]=(char)c; printf("*"); fflush(stdout);         /* Store char, print mask */
    }
    buf[i]='\0'; printf("\n");
#else
    if(!fgets(buf,sz,stdin)){buf[0]='\0';return;}    /* Read plain line on POSIX */
    int n=(int)strlen(buf);
    if(n>0&&buf[n-1]=='\n') buf[n-1]='\0';           /* Strip newline */
    printf("\n");
#endif
}

/* Reads a raw line from stdin without printing a prompt; trims result */
static void read_line(char *buf, int sz)
{
    if(!fgets(buf,sz,stdin)){buf[0]='\0';return;}    /* Read line; handle EOF/error */
    int n=(int)strlen(buf);
    if(n>0&&buf[n-1]=='\n') buf[n-1]='\0';           /* Strip newline */
    n=(int)strlen(buf);
    if(n>0&&buf[n-1]=='\r') buf[n-1]='\0';           /* Strip carriage return */
    trim(buf);                                         /* Remove any remaining whitespace */
}

/* Prints "Press Enter to continue..." and waits for the user to press Enter */
static void pause_enter(void)
{
    printf("\n  Press Enter to continue..."); fflush(stdout);
    int c; while((c=getchar())!='\n'&&c!=EOF);   /* Consume input until newline or EOF */
}

/* Prints "Press any key to exit..." and waits for a single keypress */
static void pause_any_key(void)
{
    printf("\n  Press any key to exit..."); fflush(stdout);
#ifdef _WIN32
    _getch();       /* Windows: read one key without echo */
#else
    getchar();      /* POSIX: wait for Enter */
#endif
}

/* Countdown timer printed on the SAME LINE, overwriting in place.
   Prints: "  Please wait XX seconds." and counts down to 0.       */
/* Displays a live countdown from secs to 0, overwriting the same terminal line each second */
static void countdown(int secs)
{
    for(int s=secs; s>=0; s--){
        printf("\r  Please wait %2d second(s)...  ", s);   /* Overwrite line with current count */
        fflush(stdout);
        if(s>0){
#ifdef _WIN32
            Sleep(1000);    /* Wait 1000ms on Windows */
#else
            sleep(1);       /* Wait 1 second on POSIX */
#endif
        }
    }
    printf("\n");
}

/* ================================================================
   ANSI OSC-8 HYPERLINK helpers
   Prints: ESC ] 8 ; ; url ST  display_text  ESC ] 8 ; ; ST
   Falls back to plain text if url is empty.
   ================================================================ */

/* Prints display text as an ANSI OSC-8 hyperlink in a fixed-width column w;
   falls back to plain pcol() if ANSI is unsupported or url is empty */
static void pcol_link(const char *display, const char *url, int w)
{
    int n=(int)strlen(display);
    if(g_ansi_ok && url && url[0]){
        printf("\033]8;;%s\033\\", url);                          /* Emit OSC-8 hyperlink open sequence */
        if(n<=w){ printf("%s",display); for(int i=n;i<w;i++) putchar(' '); }  /* Print text, pad to width */
        else     { for(int i=0;i<w;i++) putchar(display[i]); }               /* Hard clip if too long */
        printf("\033]8;;\033\\");                                  /* Emit OSC-8 hyperlink close sequence */
    } else {
        pcol(display, w);    /* No ANSI support: fall back to plain fixed-width print */
    }
}

/* Write a cell to a file table with word-wrap continuation rows */

/* Prints a border row for a console table: "+---+---+..." based on column widths */
static void tbl_border(const int *cw, int nc)
{
    printf("  +");
    for(int i=0;i<nc;i++){ for(int j=0;j<cw[i]+2;j++) putchar('-'); putchar('+'); }  /* Print dashes + padding per column */
    printf("\n");
}

/* Print a plain table row */
static void tbl_row_plain(const char **cells, const int *cw, int nc);  /* forward decl */

/* Print a hyperlink in a fixed-width column using ANSI OSC-8 */

/* Writes exactly w chars of string s to file f: clips if too long, pads with spaces if too short */
static void fwrite_col(FILE *f, const char *s, int w)
{
    int n=(int)strlen(s);
    if(n>w) n=w;                              /* Clip to column width */
    for(int i=0;i<n;i++) fputc(s[i],f);      /* Write actual characters */
    for(int i=n;i<w;i++) fputc(' ',f);        /* Pad remainder with spaces */
}

/* Returns how many characters of s fit in width w with word-boundary wrapping */
static int first_chunk_w(const char *s, int w)
{
    int len=(int)strlen(s);
    if(len<=w) return len;                    /* Entire string fits: return full length */
    int k=w; while(k>0&&s[k]!=' ') k--;      /* Walk back from w to find last space */
    return (k>0)?k:w;                         /* Use word boundary if found, else hard clip */
}

/* Prints a plain table row to stdout with cells padded/clipped to their column widths */
static void tbl_row_plain(const char **cells, const int *cw, int nc)
{
    printf("  |");
    for(int i=0;i<nc;i++){ printf(" "); pcol(cells[i],cw[i]); printf(" |"); }  /* Print each cell with borders */
    printf("\n");
}

/* tbl_row with ANSI links for specified columns.
   link_col: index of col that gets a link, or -1 for none.
   link_url: the URL to embed.                                */
/* Wrap a long string into multiple lines, each fitting 'w' chars,
   printing continuation lines with 'indent' leading spaces.
   Returns number of lines printed. */
/* File-based table helpers (for reports) */

/* Writes a border row to file f for a report table: "+---+---+..." per column widths */
static void ftbl_border(FILE *f, const int *cw, int nc)
{
    fprintf(f,"  +");
    for(int i=0;i<nc;i++){ for(int j=0;j<cw[i]+2;j++) fputc('-',f); fputc('+',f); }  /* Dashes + padding per column */
    fprintf(f,"\n");
}

/* Writes a data row to file f for a report table, padding/clipping each cell to its column width */
static void ftbl_row(FILE *f, const char **cells, const int *cw, int nc)
{
    fprintf(f,"  |");
    for(int i=0;i<nc;i++){
        fprintf(f," ");
        int len=(int)strlen(cells[i]);
        if(len<=cw[i]){ fprintf(f,"%s",cells[i]); for(int j=len;j<cw[i];j++) fputc(' ',f); }  /* Fits: print and pad */
        else           { for(int j=0;j<cw[i];j++) fputc(cells[i][j],f); }                      /* Too long: hard clip */
        fprintf(f," |");
    }
    fprintf(f,"\n");
}

/* Prints an ASCII horizontal bar chart row: label, a '#' bar scaled to val/mx, and the value */
static void bar_chart(const char *lbl, int val, int mx, int bw)
{
    int f=(mx>0)?(val*bw/mx):0;             /* Compute filled bar length proportionally */
    printf("  %-38s | ",lbl);               /* Print left-aligned label */
    for(int i=0;i<f;i++) putchar('#');       /* Print filled portion */
    for(int i=f;i<bw;i++) putchar('.');      /* Print unfilled portion */
    printf(" | %d\n",val);                   /* Print numeric value */
}

/* ================================================================
   SAVE / LOAD
   The text files are now formatted as human-readable tables.
   The pipe-delimited data rows are preceded by a decorative header.
   Loading still uses the pipe-delimited parser (ignores # lines).
   ================================================================ */

/* Writes all faculty records to path as a human-readable pipe-delimited file with a decorative header */
static void save_fac_to(const char *path)
{
    FILE *f=fopen(path,"w");
    if(!f){fprintf(stderr,"ERROR: Cannot write %s\n",path);return;}  /* Abort if file cannot be created */

    /* Compute dynamic column widths from actual data */
    int w_id=2, w_sn=2, w_name=9, w_desi=11, w_ra=16, w_url=11;  /* Initialize minimum widths */
    for(int i=0;i<g_fac_count;i++){
        Faculty *m=&g_fac[i];
        char ra_str[MAX_TITLE]="";
        for(int r=0;r<m->ra_count;r++){
            if(r>0) strncat(ra_str," / ",sizeof(ra_str)-strlen(ra_str)-1);  /* Separate areas with " / " */
            strncat(ra_str,m->ra[r],sizeof(ra_str)-strlen(ra_str)-1);       /* Append each research area */
        }
        int n;
        n=(int)strlen(m->id);           if(n>w_id)   w_id=n;    /* Expand ID column if needed */
        n=(int)strlen(m->sn);           if(n>w_sn)   w_sn=n;    /* Expand SN column if needed */
        n=(int)strlen(m->full_name);    if(n>w_name) w_name=n;  /* Expand Name column if needed */
        n=(int)strlen(m->desi);         if(n>w_desi) w_desi=n;  /* Expand Designation column if needed */
        n=(int)strlen(ra_str);          if(n>w_ra)   w_ra=n;    /* Expand RA column if needed */
        n=(int)strlen(m->profile_url);  if(n>w_url)  w_url=n;   /* Expand URL column if needed */
    }

    /* Header */
    fprintf(f,"# ================================================================\n");
    fprintf(f,"# RPDS Faculty Data  --  Department of Mechanical Engineering, BUET\n");
    fprintf(f,"# Fields: ID|SN|FullName|Designation|ResearchAreas(;sep)|ProfileURL|EditedBy|EditedAt\n");
    fprintf(f,"# ----------------------------------------------------------------\n");
    /* Decorative table header using actual widths */
    fprintf(f,"# %-*s | %-*s | %-*s | %-*s | %-*s | %-*s\n",
            w_id,"ID", w_sn,"SN", w_name,"Full Name",
            w_desi,"Designation", w_ra,"Research Area(s)", w_url,"Profile URL");
    /* Separator row */
    fprintf(f,"# ");
    for(int k=0;k<w_id;  k++) fputc('-',f);    /* Dashes under ID column */
    fprintf(f," | ");
    for(int k=0;k<w_sn;  k++) fputc('-',f);    /* Dashes under SN column */
    fprintf(f," | ");
    for(int k=0;k<w_name;k++) fputc('-',f);    /* Dashes under Full Name column */
    fprintf(f," | ");
    for(int k=0;k<w_desi;k++) fputc('-',f);    /* Dashes under Designation column */
    fprintf(f," | ");
    for(int k=0;k<w_ra;  k++) fputc('-',f);    /* Dashes under Research Area column */
    fprintf(f," | ");
    for(int k=0;k<w_url; k++) fputc('-',f);    /* Dashes under Profile URL column */
    fprintf(f,"\n");

    for(int i=0;i<g_fac_count;i++){
        Faculty *m=&g_fac[i];
        char ra_str[MAX_TITLE]="";
        join_list(m->ra,m->ra_count,ra_str,sizeof(ra_str));  /* Join research areas with semicolons */
        fprintf(f,"%s|%s|%s|%s|%s|%s|%s|%s\n",              /* Write one pipe-delimited record per faculty */
                m->id,m->sn,m->full_name,m->desi,ra_str,
                m->profile_url,m->last_edited_by,m->last_edited_at);
    }
    fprintf(f,"# ----------------------------------------------------------------\n");
    fprintf(f,"# Total records: %d\n",g_fac_count);  /* Footer showing total record count */
    fclose(f);
}

/* Loads faculty records from path into g_fac[]; resets g_fac_count before loading */
static void load_fac_from(const char *path)
{
    g_fac_count=0;
    FILE *f=fopen(path,"r"); if(!f) return;    /* Silently return if file doesn't exist */
    char line[MAX_TITLE*4];
    while(fgets(line,sizeof(line),f)){
        int n=(int)strlen(line);
        while(n>0&&(line[n-1]=='\n'||line[n-1]=='\r')) line[--n]='\0';  /* Strip line endings */
        if(line[0]=='#'||line[0]=='\0') continue;                        /* Skip comment and blank lines */
        Faculty m; memset(&m,0,sizeof(m));                               /* Zero-init new faculty struct */
        const char *p=line;
        char ra_str[MAX_TITLE]="";
        next_field(&p,m.id,sizeof(m.id));                   /* Parse ID field */
        next_field(&p,m.sn,sizeof(m.sn));                   /* Parse SN field */
        next_field(&p,m.full_name,sizeof(m.full_name));     /* Parse Full Name field */
        next_field(&p,m.desi,sizeof(m.desi));               /* Parse Designation field */
        next_field(&p,ra_str,sizeof(ra_str));               /* Parse raw semicolon-joined RA string */
        next_field(&p,m.profile_url,sizeof(m.profile_url)); /* Parse Profile URL field */
        next_field(&p,m.last_edited_by,sizeof(m.last_edited_by)); /* Parse editor ID */
        next_field(&p,m.last_edited_at,sizeof(m.last_edited_at)); /* Parse edit timestamp */
        m.ra_count=split_list(ra_str,m.ra,MAX_RA);          /* Split RA string into individual areas */
        if(m.id[0]&&g_fac_count<MAX_FACULTY) g_fac[g_fac_count++]=m;  /* Add if valid and within limit */
    }
    fclose(f);
}

/* Writes all publication records to path as a human-readable pipe-delimited file with a decorative header */
static void save_pub_to(const char *path)
{
    FILE *f=fopen(path,"w");
    if(!f){fprintf(stderr,"ERROR: Cannot write %s\n",path);return;}  /* Abort if file cannot be created */

    fprintf(f,"# ================================================================\n");
    fprintf(f,"# RPDS Publications Data  --  Department of Mechanical Engineering, BUET\n");
    fprintf(f,"# ================================================================\n");
    fprintf(f,"# Fields (pipe-delimited):\n");
    fprintf(f,"#   Title | Year | Type | Authors(;sep) | Journal | URL |\n");
    fprintf(f,"#   Indexing | Citations | LastEditedBy | LastEditedAt\n");
    fprintf(f,"# ----------------------------------------------------------------\n");

    /* Compute dynamic widths from actual data */
    int pw_num=1, pw_title=5, pw_year=4, pw_type=4,
        pw_auth=9, pw_jour=7, pw_idx=8, pw_cit=3;   /* Initialize minimum column widths */
    for(int i=0;i<g_pub_count;i++){
        Publication *p=&g_pub[i];
        char auth_str2[MAX_TITLE]="";
        join_list((char(*)[MAX_STR])p->authors,p->author_count,auth_str2,sizeof(auth_str2));  /* Join authors */
        char num2[16]; snprintf(num2,sizeof(num2),"%d",i+1);   /* Format serial number */
        char cit2[8]; snprintf(cit2,sizeof(cit2),"%d",p->citations);  /* Format citation count */
        int n;
        n=(int)strlen(num2);       if(n>pw_num)   pw_num=n;    /* Expand # column if needed */
        n=(int)strlen(p->title);   if(n>pw_title) pw_title=n;  /* Expand Title column if needed */
        n=(int)strlen(p->year);    if(n>pw_year)  pw_year=n;   /* Expand Year column if needed */
        n=(int)strlen(p->type);    if(n>pw_type)  pw_type=n;   /* Expand Type column if needed */
        n=(int)strlen(auth_str2);  if(n>pw_auth)  pw_auth=n;   /* Expand Author(s) column if needed */
        n=(int)strlen(p->journal); if(n>pw_jour)  pw_jour=n;   /* Expand Journal column if needed */
        n=(int)strlen(p->indexing);if(n>pw_idx)   pw_idx=n;    /* Expand Indexing column if needed */
        n=(int)strlen(cit2);       if(n>pw_cit)   pw_cit=n;    /* Expand Citations column if needed */
    }
    if(pw_title>60) pw_title=60;   /* Cap title to avoid overly wide decorative header */
    if(pw_jour >40) pw_jour =40;   /* Cap journal name width */
    if(pw_auth >20) pw_auth =20;   /* Cap authors width */

    /* Decorative column header line */
    fprintf(f,"# %-*s | %-*s | %-*s | %-*s | %-*s | %-*s | %-*s | %-*s\n",
            pw_num,"#", pw_title,"Title", pw_year,"Year", pw_type,"Type",
            pw_auth,"Author(s)", pw_jour,"Journal", pw_idx,"Indexing", pw_cit,"Cit");
    /* Separator dashes under each column */
    fprintf(f,"# ");
    for(int k=0;k<pw_num;  k++) fputc('-',f);
    fprintf(f," | ");
    for(int k=0;k<pw_title;k++) fputc('-',f);
    fprintf(f," | ");
    for(int k=0;k<pw_year; k++) fputc('-',f);
    fprintf(f," | ");
    for(int k=0;k<pw_type; k++) fputc('-',f);
    fprintf(f," | ");
    for(int k=0;k<pw_auth; k++) fputc('-',f);
    fprintf(f," | ");
    for(int k=0;k<pw_jour; k++) fputc('-',f);
    fprintf(f," | ");
    for(int k=0;k<pw_idx;  k++) fputc('-',f);
    fprintf(f," | ");
    for(int k=0;k<pw_cit;  k++) fputc('-',f);
    fprintf(f,"\n");

    for(int i=0;i<g_pub_count;i++){
        Publication *p=&g_pub[i];
        char auth_str[MAX_TITLE]="";
        join_list(p->authors,p->author_count,auth_str,sizeof(auth_str));  /* Join authors with semicolons */
        fprintf(f,"%s|%s|%s|%s|%s|%s|%s|%d|%s|%s\n",                     /* Write one pipe-delimited record */
                p->title,p->year,p->type,auth_str,p->journal,
                p->url,p->indexing,p->citations,
                p->last_edited_by,p->last_edited_at);
    }
    fprintf(f,"# ----------------------------------------------------------------\n");
    fprintf(f,"# Total records: %d\n",g_pub_count);   /* Footer with total record count */
    fclose(f);
}

/* Loads publication records from path into g_pub[]; resets g_pub_count before loading */
static void load_pub_from(const char *path)
{
    g_pub_count=0;
    FILE *f=fopen(path,"r"); if(!f) return;    /* Silently return if file doesn't exist */
    char line[MAX_TITLE*4];
    while(fgets(line,sizeof(line),f)){
        int n=(int)strlen(line);
        while(n>0&&(line[n-1]=='\n'||line[n-1]=='\r')) line[--n]='\0';  /* Strip line endings */
        if(line[0]=='#'||line[0]=='\0') continue;                        /* Skip comments and blank lines */
        Publication p; memset(&p,0,sizeof(p));                           /* Zero-init new publication struct */
        const char *ptr=line;
        char auth_str[MAX_TITLE]="", cit_str[MAX_STR]="";
        next_field(&ptr,p.title,sizeof(p.title));           /* Parse Title */
        next_field(&ptr,p.year,sizeof(p.year));             /* Parse Year */
        next_field(&ptr,p.type,sizeof(p.type));             /* Parse Type */
        next_field(&ptr,auth_str,sizeof(auth_str));         /* Parse raw semicolon-joined authors string */
        next_field(&ptr,p.journal,sizeof(p.journal));       /* Parse Journal */
        next_field(&ptr,p.url,sizeof(p.url));               /* Parse URL */
        next_field(&ptr,p.indexing,sizeof(p.indexing));     /* Parse Indexing */
        next_field(&ptr,cit_str,sizeof(cit_str));           /* Parse citations as string */
        next_field(&ptr,p.last_edited_by,sizeof(p.last_edited_by));  /* Parse editor ID */
        next_field(&ptr,p.last_edited_at,sizeof(p.last_edited_at));  /* Parse edit timestamp */
        p.author_count=split_list(auth_str,p.authors,MAX_AUTHORS);   /* Split authors into array */
        p.citations=cit_str[0]?atoi(cit_str):0;            /* Convert citation string to int; default 0 */
        if(p.title[0]&&g_pub_count<MAX_PUBS) g_pub[g_pub_count++]=p; /* Add if valid and within limit */
    }
    fclose(f);
}

/* Convenience wrappers: save/load using the default file paths */
static void save_faculty(void) { save_fac_to(FACULTY_FILE); }
static void load_faculty(void) { load_fac_from(FACULTY_FILE); }
static void save_pubs(void)    { save_pub_to(PUB_FILE); }
static void load_pubs(void)    { load_pub_from(PUB_FILE); }

/* ================================================================
   UNDO  -- in-memory snapshot (100% reliable, no file I/O issues)
   ================================================================ */
static Faculty     g_undo_fac[MAX_FACULTY];    /* In-memory undo snapshot of faculty array */
static int         g_undo_fac_count = 0;       /* Faculty count saved in undo snapshot */
static Publication g_undo_pub[MAX_PUBS];        /* In-memory undo snapshot of publications array */
static int         g_undo_pub_count = 0;        /* Publication count saved in undo snapshot */
static int         g_undo_valid     = 0;        /* 1 = a valid snapshot exists in memory */

/* Saves the current state of faculty and publication arrays into undo buffers and disk files */
static void save_undo_snapshot(void)
{
    /* Copy current arrays into undo buffers */
    g_undo_fac_count = g_fac_count;
    memcpy(g_undo_fac, g_fac, sizeof(Faculty) * (size_t)g_fac_count);      /* Snapshot faculty array */
    g_undo_pub_count = g_pub_count;
    memcpy(g_undo_pub, g_pub, sizeof(Publication) * (size_t)g_pub_count);  /* Snapshot publications array */
    g_undo_valid = 1;                                                         /* Mark snapshot as valid */
    /* Also persist to disk so undo survives a program restart */
    save_fac_to(UNDO_FAC_FILE);    /* Write faculty snapshot to disk */
    save_pub_to(UNDO_PUB_FILE);    /* Write publications snapshot to disk */
}

/* Restores faculty and publication data from the most recent undo snapshot;
   returns 1 on success, 0 if no snapshot exists */
static int restore_undo_snapshot(void)
{
    if(!g_undo_valid){
        /* Try loading from disk if in-memory snapshot not set */
        FILE *ff=fopen(UNDO_FAC_FILE,"r");
        FILE *fp=fopen(UNDO_PUB_FILE,"r");
        if(!ff||!fp){ if(ff)fclose(ff); if(fp)fclose(fp); return 0; }  /* Both files must exist */
        fclose(ff); fclose(fp);
        load_fac_from(UNDO_FAC_FILE);   /* Restore faculty from disk snapshot */
        load_pub_from(UNDO_PUB_FILE);   /* Restore publications from disk snapshot */
    } else {
        /* Restore directly from in-memory snapshot */
        g_fac_count = g_undo_fac_count;
        memcpy(g_fac, g_undo_fac, sizeof(Faculty) * (size_t)g_undo_fac_count);      /* Restore faculty */
        g_pub_count = g_undo_pub_count;
        memcpy(g_pub, g_undo_pub, sizeof(Publication) * (size_t)g_undo_pub_count);  /* Restore publications */
        g_undo_valid = 0;  /* Consume the snapshot so it can't be applied twice */
    }
    /* Write the restored state to disk */
    save_faculty();   /* Persist restored faculty to main file */
    save_pubs();      /* Persist restored publications to main file */
    return 1;
}

/* ================================================================
   LOGGING
   ================================================================ */

/* Appends a timestamped action log entry to the history file */
static void log_action(const char *adm, const char *act, const char *det)
{
    FILE *f=fopen(HISTORY_FILE,"a"); if(!f) return;   /* Open log in append mode; skip if unavailable */
    char ts[MAX_STR]; now_str(ts);                     /* Get current timestamp */
    fprintf(f,"[%s] | Admin: %s | Action: %s | %s\n",ts,adm,act,det);  /* Write formatted log entry */
    fclose(f);
}

/* Reads the last log entry and extracts its timestamp into buf; returns "No edits recorded yet" if empty */
static void get_last_edit_time(char *buf)
{
    buf[0]='\0';
    FILE *f=fopen(HISTORY_FILE,"r"); if(!f){strcpy(buf,"No edits recorded yet");return;}  /* No log file */
    char last[MAX_TITLE]="";
    char line[MAX_TITLE];
    while(fgets(line,sizeof(line),f)){
        int n=(int)strlen(line);
        while(n>0&&(line[n-1]=='\n'||line[n-1]=='\r')) line[--n]='\0';  /* Strip line endings */
        if(line[0]) strncpy(last,line,MAX_TITLE-1);                       /* Keep updating last with each non-empty line */
    }
    fclose(f);
    if(!last[0]){strcpy(buf,"No edits recorded yet");return;}   /* Log file was empty */
    /* Extract timestamp: line starts with [YYYY-MM-DD HH:MM:SS] */
    if(last[0]=='['){
        int end=0; while(last[end]&&last[end]!=']') end++;   /* Find closing bracket */
        int len=end-1; if(len>MAX_STR-1)len=MAX_STR-1;
        strncpy(buf,last+1,len); buf[len]='\0';               /* Copy timestamp without brackets */
    } else strncpy(buf,last,MAX_STR-1);                        /* Fallback: copy entire line */
}

/* ================================================================
   BUSINESS LOGIC HELPERS
   ================================================================ */

/* Generates the next available faculty ID in the format "MEF-NN" by scanning existing IDs */
static void next_fac_id(char *buf)
{
    int mx=0;
    for(int i=0;i<g_fac_count;i++){
        const char *d=strchr(g_fac[i].id,'-');                     /* Find '-' in ID like "MEF-05" */
        if(d){ int n=atoi(d+1); if(n>mx) mx=n; }                  /* Track highest numeric suffix */
    }
    sprintf(buf,"MEF-%02d",mx+1);   /* Produce next ID with zero-padded two-digit number */
}

/* Returns 1 if short name sn is already used by another faculty (excluding the one with ID excl) */
static int sn_taken(const char *sn, const char *excl)
{
    for(int i=0;i<g_fac_count;i++){
        if(str_ieq(g_fac[i].sn,sn)){
            if(excl&&excl[0]&&strcmp(g_fac[i].id,excl)==0) continue;  /* Skip the excluded record */
            return 1;                                                    /* Found a duplicate */
        }
    }
    return 0;
}

/* Returns 1 if publication title t already exists (excluding index excl; pass -1 to check all) */
static int title_taken(const char *t, int excl)
{
    for(int i=0;i<g_pub_count;i++){
        if(i==excl) continue;                      /* Skip the record being edited */
        if(str_ieq(g_pub[i].title,t)) return 1;   /* Found a duplicate title */
    }
    return 0;
}

/* Returns the number of publications that list faculty member with short name sn as an author */
static int pubs_for_sn(const char *sn)
{
    int c=0;
    for(int i=0;i<g_pub_count;i++)
        for(int a=0;a<g_pub[i].author_count;a++)
            if(str_ieq(g_pub[i].authors[a],sn)){c++;break;}  /* Count once per publication */
    return c;
}

/* Builds a deduplicated semicolon-separated research areas string for publication p
   by looking up all its authors' research areas in the faculty list; writes "--" if none found */
static void pub_ra_display(Publication *p, char *out, int sz)
{
    out[0]='\0';
    for(int a=0;a<p->author_count;a++)            /* Loop through each author */
        for(int f=0;f<g_fac_count;f++){
            if(!str_ieq(g_fac[f].sn,p->authors[a])) continue;  /* Find matching faculty by SN */
            for(int r=0;r<g_fac[f].ra_count;r++)
                if(!str_ihas(out,g_fac[f].ra[r])){              /* Only add if not already present */
                    if(out[0]) strncat(out,"; ",sz-strlen(out)-1);
                    strncat(out,g_fac[f].ra[r],sz-strlen(out)-1);
                }
        }
    if(!out[0]) strncpy(out,"--",sz-1);   /* No research areas found: use placeholder */
}

/* Builds a comma-separated authors string from publication p's author SNs; writes "--" if empty */
static void authors_str(Publication *p, char *out, int sz)
{
    out[0]='\0';
    for(int a=0;a<p->author_count;a++){
        if(!p->authors[a][0]) continue;                           /* Skip empty author slots */
        if(out[0]) strncat(out,", ",sz-strlen(out)-1);           /* Add comma separator */
        strncat(out,p->authors[a],sz-strlen(out)-1);             /* Append author SN */
    }
    if(!out[0]) strncpy(out,"--",sz-1);   /* No authors: use placeholder */
}

/* Returns 1 if id matches one of the 6 valid admin IDs, 0 otherwise */
static int valid_admin_id(const char *id)
{
    for(int i=0;i<6;i++) if(strcmp(id,ADMIN_IDS[i])==0) return 1;
    return 0;
}

/* ================================================================
   AUTH
   ================================================================ */
/* Returns 1 if an admin is currently logged in (g_admin is non-empty) */
static int logged_in(void) { return g_admin[0]!='\0'; }

/* Returns 1 if login is currently locked out due to too many failed attempts;
   resets lockout state automatically if the lockout period has expired */
static int is_locked(void)
{
    if(g_attempts<MAX_LOGIN_TRIES) return 0;           /* Not enough failed attempts: not locked */
    if(time(NULL)<g_locked_until)  return 1;           /* Still within lockout window: locked */
    g_attempts=0; g_locked_until=0; return 0;          /* Lockout expired: reset and unlock */
}

/* Returns 1 if the given id and pw match a valid admin credential pair, 0 otherwise */
static int check_creds(const char *id, const char *pw)
{
    for(int i=0;i<6;i++)
        if(strcmp(id,ADMIN_IDS[i])==0&&strcmp(pw,ADMIN_PWD[i])==0) return 1;  /* Match found */
    return 0;
}

/* ================================================================
   SCREEN: LOGIN  (stays open; retry / back-to-menu; countdown)
   ================================================================ */
/* Handles the admin login flow: validates ID, reads password, enforces lockout after MAX_LOGIN_TRIES failures */
static void screen_login(void)
{
    while(1){
        clrscr(); section("ADMIN LOGIN");
        printf("\n  Available IDs: admin-1  admin-2  admin-3  admin-4  admin-5  admin-6\n\n");

        /* ---- Check lockout ---- */
        if(is_locked()){
            long secs=(long)(g_locked_until-time(NULL));           /* Remaining lockout seconds */
            printf("  Login Portal locked due to too many wrong attempts.\n");
            printf("  Try again after ");
            /* live countdown */
            for(long s=secs;s>=0;s--){
                printf("\r  Try again after %2ld second(s)...  ",s);   /* Overwrite line each second */
                fflush(stdout);
                if(s>0){
#ifdef _WIN32
                    Sleep(1000);
#else
                    sleep(1);
#endif
                }
            }
            printf("\n\n  Lockout expired. ");
            /* fall through to retry */
            g_attempts=0; g_locked_until=0;   /* Reset lockout state after countdown */
        }

        /* ---- Credential input ---- */
        char id[MAX_STR]="", pw[MAX_STR]="";
        printf("  %-30s: ","Admin ID"); fflush(stdout);
        read_line(id,sizeof(id));   /* Read admin ID without prompt label */

        /* Validate ID format first */
        if(!id[0]){
            printf("\n  [ERROR] Admin ID cannot be empty.\n");
            printf("\n  [1] Retry   [2] Back to menu\n");
            char opt[4]=""; prompt("Choice",opt,sizeof(opt));
            if(opt[0]=='2') return;    /* User chose to go back to main menu */
            continue;
        }
        if(!valid_admin_id(id)){
            printf("\n  [ERROR] '%s' is not a valid Admin ID.\n",id);
            printf("  Valid IDs: admin-1 through admin-6\n");
            printf("\n  [1] Retry   [2] Back to menu\n");
            char opt[4]=""; prompt("Choice",opt,sizeof(opt));
            if(opt[0]=='2') return;
            continue;
        }

        read_password(pw,sizeof(pw));   /* Read password with masking */

        if(check_creds(id,pw)){
            SCOPY(g_admin,id);                                   /* Store logged-in admin ID */
            g_attempts=0;                                         /* Reset failed attempt counter */
            log_action(id,"LOGIN","Logged in successfully");      /* Record successful login */
            printf("\n  Welcome, %s!\n",id);
            pause_enter();
            return;
        }

        /* ---- Wrong credentials ---- */
        g_attempts++;                                                        /* Increment failure count */
        char det[MAX_TITLE];
        snprintf(det,sizeof(det),"Admin ID: %s  (wrong credentials)",id);
        log_action(id,"FAILED_LOGIN",det);                                   /* Log failed attempt */

        if(g_attempts>=MAX_LOGIN_TRIES){
            g_locked_until=time(NULL)+LOCKOUT_SECS;    /* Set lockout expiry timestamp */
            printf("\n  [ERROR] Wrong credentials entered too many times.\n");
            printf("  Please wait ");
            countdown(LOCKOUT_SECS);                    /* Show live countdown */
            g_attempts=0; g_locked_until=0;
            printf("\n  Lockout expired. You may try again.\n");
            printf("\n  [1] Retry   [2] Back to menu\n");
            char opt[4]=""; prompt("Choice",opt,sizeof(opt));
            if(opt[0]=='2') return;
            /* opt[0]=='1': loop back for retry */
        } else {
            int left=MAX_LOGIN_TRIES-g_attempts;
            printf("\n  [ERROR] Wrong credentials. %d attempt(s) remaining.\n",left);  /* Warn user of remaining attempts */
            printf("\n  [1] Retry   [2] Back to menu\n");
            char opt[4]=""; prompt("Choice",opt,sizeof(opt));
            if(opt[0]=='2') return;
            /* loop: retry */
        }
    }
}

/* Logs out the current admin, clears g_admin, and logs the event */
static void screen_logout(void)
{
    log_action(g_admin,"LOGOUT","Logged out");   /* Record logout in history */
    printf("\n  Logged out (%s).\n",g_admin);
    g_admin[0]='\0';                              /* Clear logged-in admin ID */
    pause_enter();
}

/* ================================================================
   SHARED: PRINT FACULTY TABLE  (screen version with ANSI links)
   ================================================================ */
/* Columns: ID(8) SN(6) Full Name+ANSI-link(28) Designation(22)
            Research Area(s)(38) Publications(12) -- URL anchored to name */
#define FC_ID   0   /* Column index: Faculty ID */
#define FC_SN   1   /* Column index: Short Name */
#define FC_NAME 2   /* Column index: Full Name (with ANSI hyperlink) */
#define FC_DESI 3   /* Column index: Designation */
#define FC_RA   4   /* Column index: Research Area(s) */
#define FC_PUBS 5   /* Column index: Publication count */
static const int FAC_CW[]={8,6,30,22,42,12};   /* Fixed column widths for faculty screen table */
static const int FAC_NC=6;                       /* Number of columns in faculty screen table */
static const char *FAC_HDR[]={"ID","SN","Full Name","Designation","Research Area(s)","Publications"};  /* Column headers */

/* Prints a formatted faculty table to stdout for the given indices subset;
   Full Name links to profile URL via ANSI OSC-8, Research Area wraps across continuation rows */
static void print_fac_table_screen(int *indices, int count)
{
    tbl_border(FAC_CW,FAC_NC);            /* Print top border */
    tbl_row_plain(FAC_HDR,FAC_CW,FAC_NC);/* Print header row */
    tbl_border(FAC_CW,FAC_NC);            /* Print separator border */

    for(int ii=0;ii<count;ii++){
        Faculty *m=&g_fac[indices[ii]];   /* Get pointer to current faculty */
        char ra_buf[MAX_TITLE]="";
        for(int r=0;r<m->ra_count;r++){
            if(r>0) strncat(ra_buf," / ",sizeof(ra_buf)-strlen(ra_buf)-1);  /* Separator between areas */
            strncat(ra_buf,m->ra[r],sizeof(ra_buf)-strlen(ra_buf)-1);       /* Append research area */
        }
        if(!ra_buf[0]) strcpy(ra_buf,"--");                                  /* Placeholder if no areas */
        char pc[8]; sprintf(pc,"%d",pubs_for_sn(m->sn));                    /* Publication count string */

        /* Print row: Full Name is ANSI hyperlink to profile URL (no URL column) */
        printf("  |");
        printf(" "); pcol(m->id,   FAC_CW[FC_ID]);   printf(" |");                              /* ID cell */
        printf(" "); pcol(m->sn,   FAC_CW[FC_SN]);   printf(" |");                              /* SN cell */
        printf(" "); pcol_link(m->full_name,m->profile_url,FAC_CW[FC_NAME]); printf(" |");      /* Name cell with ANSI link */
        printf(" "); pcol(m->desi, FAC_CW[FC_DESI]); printf(" |");                              /* Designation cell */
        /* RA: first line in the row */
        {
            int ra_len=(int)strlen(ra_buf);
            int tw=FAC_CW[FC_RA];
            printf(" ");
            int first_chunk=(ra_len<=tw)?ra_len:tw;   /* Default: entire RA or column width */
            /* word-wrap first line */
            if(ra_len>tw){
                int k=tw; while(k>0&&ra_buf[k]!=' ') k--; if(k>0) first_chunk=k;  /* Break at word boundary */
            }
            for(int k=0;k<first_chunk;k++) putchar(ra_buf[k]);     /* Print first chunk of RA */
            for(int k=first_chunk;k<tw;k++) putchar(' ');           /* Pad RA column with spaces */
            printf(" |");
            printf(" "); pcol(pc, FAC_CW[FC_PUBS]); printf(" |");  /* Publications count cell */
            printf("\n");
            /* continuation lines for RA -- no blank line between them */
            int pos=first_chunk;
            while(pos<ra_len&&ra_buf[pos]==' ') pos++;   /* Skip spaces after first chunk */
            while(pos<ra_len){
                int chunk=tw; if(pos+chunk>=ra_len) chunk=ra_len-pos;                    /* Last chunk: remaining text */
                else{int k=chunk;while(k>0&&ra_buf[pos+k]!=' ')k--;if(k>0)chunk=k;}     /* Word-boundary break */
                printf("  |");
                for(int ci=0;ci<FC_RA;ci++){printf(" ");for(int k=0;k<FAC_CW[ci];k++) putchar(' ');printf(" |");}  /* Empty cells for alignment */
                printf(" ");
                for(int k=0;k<chunk;k++) putchar(ra_buf[pos+k]);    /* Print this RA chunk */
                for(int k=chunk;k<tw;k++) putchar(' ');              /* Pad RA column */
                printf(" |");
                for(int k=0;k<FAC_CW[FC_PUBS];k++) putchar(' ');   /* Empty Publications cell */
                printf(" |");
                printf("\n");
                pos+=chunk; while(pos<ra_len&&ra_buf[pos]==' ') pos++;  /* Advance past chunk and spaces */
            }
        }
    }
    tbl_border(FAC_CW,FAC_NC);   /* Print bottom border */
}

/* ================================================================
   SHARED: PRINT PUBLICATIONS TABLE (screen version with ANSI links)
   ================================================================ */
/* Columns: #(3) Title+link(42, wraps) Year(4) Type(11)
            Authors(14) Journal(26) RA(26) Indexing(14) Cit(4) */
#define PC_NUM   0   /* Column index: serial number */
#define PC_TITLE 1   /* Column index: title (with ANSI hyperlink) */
#define PC_YEAR  2   /* Column index: year */
#define PC_TYPE  3   /* Column index: publication type */
#define PC_AUTH  4   /* Column index: authors */
#define PC_JOUR  5   /* Column index: journal */
#define PC_RA    6   /* Column index: research areas */
#define PC_IDX   7   /* Column index: indexing */
#define PC_CIT   8   /* Column index: citations */
static const int PUB_CW[]={3,42,4,11,14,26,26,14,4};    /* Fixed column widths for publications screen table */
static const int PUB_NC=9;                                /* Number of columns in publications screen table */
static const char *PUB_HDR[]={"#","Title","Year","Type","Author(s)","Journal","Research Area(s)","Indexing","Cit"};  /* Column headers */

/* Prints a formatted publications table to stdout for the given indices subset;
   Title is an ANSI OSC-8 hyperlink; Title, Journal, and RA wrap independently across continuation rows */
static void print_pub_table_screen(int *indices, int count)
{
    tbl_border(PUB_CW,PUB_NC);            /* Print top border */
    tbl_row_plain(PUB_HDR,PUB_CW,PUB_NC);/* Print header row */
    tbl_border(PUB_CW,PUB_NC);            /* Print separator border */

    for(int ii=0;ii<count;ii++){
        int idx=indices[ii];
        Publication *p=&g_pub[idx];                                          /* Get current publication */
        char num[16]; snprintf(num,sizeof(num),"%d",ii+1);                  /* Format serial number */
        char cit[8];  sprintf(cit,"%d",p->citations);                       /* Format citation count */
        char auth[MAX_STR]; authors_str(p,auth,sizeof(auth));               /* Build authors string */
        char ra_buf[MAX_TITLE]; pub_ra_display(p,ra_buf,sizeof(ra_buf));    /* Build research areas string */

        /* Helper macro: print a wrapped string in a column, returns lines used */
        #define WRAP_COL_START(str, colw, url_str) do { \
            int _len=(int)strlen(str), _tw=(colw); \
            int _fc=_tw; if(_len>_tw){int _k=_tw;while(_k>0&&(str)[_k]!=' ')_k--;if(_k>0)_fc=_k;} \
            else _fc=_len; \
            printf(" "); \
            if(g_ansi_ok&&(url_str)&&(url_str)[0]) printf("\033]8;;%s\033\\",(url_str));  /* Open OSC-8 link */ \
            for(int _k=0;_k<_fc;_k++) putchar((str)[_k]);    /* Print first chunk */ \
            for(int _k=_fc;_k<_tw;_k++) putchar(' ');         /* Pad column */ \
            if(g_ansi_ok&&(url_str)&&(url_str)[0]) printf("\033]8;;\033\\");   /* Close OSC-8 link */ \
        } while(0)

        int title_len=(int)strlen(p->title);    /* Total title length */
        int jour_len=(int)strlen(p->journal);   /* Total journal name length */
        int ra_len=(int)strlen(ra_buf);          /* Total research areas string length */
        int tw=PUB_CW[PC_TITLE];                 /* Title column width */
        int jw=PUB_CW[PC_JOUR];                  /* Journal column width */
        int rw=PUB_CW[PC_RA];                    /* Research Area column width */

        /* --- compute first-line chunks for wrapping columns --- */
        int t_fc=tw; /* title first chunk */
        if(title_len>tw){int k=tw;while(k>0&&p->title[k]!=' ')k--;if(k>0)t_fc=k;} else t_fc=title_len;
        int j_fc=jw; /* journal first chunk */
        if(jour_len>jw){int k=jw;while(k>0&&p->journal[k]!=' ')k--;if(k>0)j_fc=k;} else j_fc=jour_len;
        int r_fc=rw; /* RA first chunk */
        if(ra_len>rw){int k=rw;while(k>0&&ra_buf[k]!=' ')k--;if(k>0)r_fc=k;} else r_fc=ra_len;

        /* --- First row --- */
        printf("  |");
        printf(" "); pcol(num,PUB_CW[PC_NUM]); printf(" |");               /* Serial number cell */
        WRAP_COL_START(p->title,tw,p->url); printf(" |");                   /* Title cell with ANSI link, first chunk */
        printf(" "); pcol(p->year,    PUB_CW[PC_YEAR]); printf(" |");      /* Year cell */
        printf(" "); pcol(p->type,    PUB_CW[PC_TYPE]); printf(" |");      /* Type cell */
        printf(" "); pcol(auth,       PUB_CW[PC_AUTH]); printf(" |");      /* Authors cell */
        printf(" ");
        for(int k=0;k<j_fc;k++) putchar(p->journal[k]);   /* First journal chunk */
        for(int k=j_fc;k<jw;k++) putchar(' ');             /* Pad journal column */
        printf(" |");
        printf(" ");
        for(int k=0;k<r_fc;k++) putchar(ra_buf[k]);        /* First RA chunk */
        for(int k=r_fc;k<rw;k++) putchar(' ');              /* Pad RA column */
        printf(" |");
        printf(" "); pcol(p->indexing,PUB_CW[PC_IDX]);  printf(" |");      /* Indexing cell */
        printf(" "); pcol(cit,        PUB_CW[PC_CIT]);  printf(" |");      /* Citations cell */
        printf("\n");
        #undef WRAP_COL_START

        /* --- Continuation rows (title, journal, RA can all wrap independently) --- */
        {
            int t_pos=t_fc; while(t_pos<title_len&&p->title[t_pos]==' ') t_pos++;      /* Skip spaces after title chunk */
            int j_pos=j_fc; while(j_pos<jour_len&&p->journal[j_pos]==' ') j_pos++;     /* Skip spaces after journal chunk */
            int r_pos=r_fc; while(r_pos<ra_len&&ra_buf[r_pos]==' ') r_pos++;           /* Skip spaces after RA chunk */
            while(t_pos<title_len||j_pos<jour_len||r_pos<ra_len){  /* Continue while any field has remaining text */
                printf("  |");
                /* # col blank */
                printf(" "); for(int k=0;k<PUB_CW[PC_NUM];k++) putchar(' '); printf(" |");   /* Empty # cell */
                /* title continuation */
                printf(" ");
                if(t_pos<title_len){
                    int chunk=tw; if(t_pos+chunk>=title_len) chunk=title_len-t_pos;               /* Last chunk of title */
                    else{int k=chunk;while(k>0&&p->title[t_pos+k]!=' ')k--;if(k>0)chunk=k;}       /* Word-boundary break */
                    if(g_ansi_ok&&p->url[0]) printf("\033]8;;%s\033\\",p->url);                    /* Open ANSI link */
                    for(int k=0;k<chunk;k++) putchar(p->title[t_pos+k]);                           /* Print chunk */
                    for(int k=chunk;k<tw;k++) putchar(' ');                                         /* Pad column */
                    if(g_ansi_ok&&p->url[0]) printf("\033]8;;\033\\");                             /* Close ANSI link */
                    t_pos+=chunk; while(t_pos<title_len&&p->title[t_pos]==' ') t_pos++;            /* Advance position */
                } else { for(int k=0;k<tw;k++) putchar(' '); }    /* Title exhausted: print empty cell */
                printf(" |");
                /* year/type/auth blank */
                printf(" "); for(int k=0;k<PUB_CW[PC_YEAR];k++) putchar(' '); printf(" |");  /* Empty Year cell */
                printf(" "); for(int k=0;k<PUB_CW[PC_TYPE];k++) putchar(' '); printf(" |");  /* Empty Type cell */
                printf(" "); for(int k=0;k<PUB_CW[PC_AUTH];k++) putchar(' '); printf(" |");  /* Empty Authors cell */
                /* journal continuation */
                printf(" ");
                if(j_pos<jour_len){
                    int chunk=jw; if(j_pos+chunk>=jour_len) chunk=jour_len-j_pos;                 /* Last journal chunk */
                    else{int k=chunk;while(k>0&&p->journal[j_pos+k]!=' ')k--;if(k>0)chunk=k;}    /* Word-boundary break */
                    for(int k=0;k<chunk;k++) putchar(p->journal[j_pos+k]);                        /* Print chunk */
                    for(int k=chunk;k<jw;k++) putchar(' ');                                        /* Pad column */
                    j_pos+=chunk; while(j_pos<jour_len&&p->journal[j_pos]==' ') j_pos++;          /* Advance position */
                } else { for(int k=0;k<jw;k++) putchar(' '); }    /* Journal exhausted: empty cell */
                printf(" |");
                /* RA continuation */
                printf(" ");
                if(r_pos<ra_len){
                    int chunk=rw; if(r_pos+chunk>=ra_len) chunk=ra_len-r_pos;                     /* Last RA chunk */
                    else{int k=chunk;while(k>0&&ra_buf[r_pos+k]!=' ')k--;if(k>0)chunk=k;}         /* Word-boundary break */
                    for(int k=0;k<chunk;k++) putchar(ra_buf[r_pos+k]);                            /* Print chunk */
                    for(int k=chunk;k<rw;k++) putchar(' ');                                        /* Pad column */
                    r_pos+=chunk; while(r_pos<ra_len&&ra_buf[r_pos]==' ') r_pos++;                /* Advance position */
                } else { for(int k=0;k<rw;k++) putchar(' '); }    /* RA exhausted: empty cell */
                printf(" |");
                /* indexing/cit blank */
                printf(" "); for(int k=0;k<PUB_CW[PC_IDX];k++) putchar(' '); printf(" |");  /* Empty Indexing cell */
                printf(" "); for(int k=0;k<PUB_CW[PC_CIT];k++) putchar(' '); printf(" |");  /* Empty Citations cell */
                printf("\n");
            }
        }
    }
    tbl_border(PUB_CW,PUB_NC);   /* Print bottom border */
}

/* ================================================================
   SCREEN: VIEW ALL FACULTY
   ================================================================ */
/* Displays all faculty in a formatted screen table; shows count at bottom */
static void screen_view_faculty(void)
{
    clrscr(); section("ALL FACULTY");
    if(g_fac_count==0){printf("\n  No faculty records.\n");pause_enter();return;}  /* Early exit if empty */
    printf("\n");
    int indices[MAX_FACULTY];
    for(int i=0;i<g_fac_count;i++) indices[i]=i;    /* Build sequential index array for all faculty */
    print_fac_table_screen(indices,g_fac_count);
    printf("  Total: %d faculty member(s)\n",g_fac_count);
    pause_enter();
}

/* ================================================================
   SCREEN: VIEW ALL PUBLICATIONS
   ================================================================ */
/* Displays all publications in a formatted screen table; shows count at bottom */
static void screen_view_pubs(void)
{
    clrscr(); section("ALL PUBLICATIONS");
    if(g_pub_count==0){printf("\n  No publications.\n");pause_enter();return;}  /* Early exit if empty */
    printf("\n");
    int indices[MAX_PUBS];
    for(int i=0;i<g_pub_count;i++) indices[i]=i;    /* Build sequential index array for all publications */
    print_pub_table_screen(indices,g_pub_count);
    printf("  Total: %d publication(s)\n",g_pub_count);
    pause_enter();
}

/* ================================================================
   SCREEN: ADD FACULTY
   ================================================================ */
/* Interactive form to create a new faculty record: prompts for SN, name, designation, RAs, and URL;
   auto-assigns an ID; validates for uniqueness; saves and logs on success */
static void screen_add_faculty(void)
{
    clrscr(); section("ADD FACULTY");
    Faculty m; memset(&m,0,sizeof(m));
    next_fac_id(m.id);                                         /* Auto-generate next available ID */
    printf("\n  Auto-assigned ID: %s\n\n",m.id);

    if(!prompt("Short Name / Initials (e.g. MHK)",m.sn,sizeof(m.sn)))
        {printf("  [Error] Required.\n");pause_enter();return;}
    str_upper(m.sn);                                           /* Normalize SN to uppercase */
    if(sn_taken(m.sn,""))
        {printf("  [Error] '%s' already in use.\n",m.sn);pause_enter();return;}  /* Reject duplicate SN */

    if(!prompt("Full Name",m.full_name,sizeof(m.full_name)))
        {printf("  [Error] Required.\n");pause_enter();return;}
    to_title_case(m.full_name);    /* Normalize name to title case */

    while(1){
        printf("\n  1=Professor  2=Associate Professor  3=Assistant Professor  4=Lecturer\n");
        char ch[4]=""; prompt("Designation (1-4)",ch,sizeof(ch));
        if(strlen(ch)==1){
            switch(ch[0]){
                case '1': SCOPY(m.desi,"Professor");           goto desi_ok;
                case '2': SCOPY(m.desi,"Associate Professor"); goto desi_ok;
                case '3': SCOPY(m.desi,"Assistant Professor"); goto desi_ok;
                case '4': SCOPY(m.desi,"Lecturer");            goto desi_ok;
            }
        }
        printf("  [Error] Please enter 1, 2, 3, or 4.\n");
    }
    desi_ok:;

    printf("\n  Enter research areas one per line (blank line to finish):\n");
    m.ra_count=0;
    while(m.ra_count<MAX_RA){
        char ra[MAX_STR]="";
        printf("  Area %d: ",m.ra_count+1); fflush(stdout);
        if(!fgets(ra,sizeof(ra),stdin)) break;
        int n=(int)strlen(ra); if(n>0&&ra[n-1]=='\n') ra[n-1]='\0'; trim(ra);
        if(!ra[0]) break;                   /* Blank line ends entry */
        to_title_case(ra);                  /* Normalize to title case */
        /* Check for duplicate research area */
        int dup=0;
        for(int _d=0;_d<m.ra_count;_d++)
            if(str_ieq(m.ra[_d],ra)){dup=1;break;}
        if(dup){printf("  [Error] '%s' is already listed as a research area.\n",ra);continue;}  /* Reject duplicate */
        SCOPY(m.ra[m.ra_count],ra); m.ra_count++;
    }
    if(m.ra_count==0){printf("  [Error] At least one required.\n");pause_enter();return;}

    prompt("Profile URL (optional)",m.profile_url,sizeof(m.profile_url));
    SCOPY(m.last_edited_by,g_admin); now_str(m.last_edited_at);   /* Record editor and timestamp */

    save_undo_snapshot();
    g_fac[g_fac_count++]=m; save_faculty();                       /* Append and persist */
    char det[MAX_TITLE]; snprintf(det,sizeof(det),"Name: %.100s, ID: %s",m.full_name,m.id);
    log_action(g_admin,"ADD_FACULTY",det);                         /* Log the addition */
    printf("\n  [OK] '%s' added (ID: %s).\n",m.full_name,m.id);
    pause_enter();
}

/* ================================================================
   SCREEN: EDIT FACULTY
   ================================================================ */
/* Lists all faculty and lets the admin select one to edit; supports updating SN, name,
   designation, research areas, and URL; validates uniqueness; saves undo snapshot first */
static void screen_edit_faculty(void)
{
    clrscr(); section("EDIT FACULTY");
    if(g_fac_count==0){printf("\n  No faculty.\n");pause_enter();return;}
    printf("\n");
    for(int i=0;i<g_fac_count;i++)
        printf("  [%d] %s -- %s (%s)\n",i+1,g_fac[i].id,g_fac[i].full_name,g_fac[i].sn);  /* List faculty for selection */
    printf("\n");
    while(1){
        char sel[8]=""; prompt("Number to edit (0=cancel)",sel,sizeof(sel));
        if(sel[0]=='0'){printf("  Cancelled.\n");pause_enter();return;}
        int idx=atoi(sel)-1;
        if(idx>=0&&idx<g_fac_count) {
            Faculty *m=&g_fac[idx];
            char buf[MAX_TITLE]="";
            save_undo_snapshot();   /* snapshot BEFORE any edits */
            printf("\n  Editing: %s  (blank = keep current)\n\n",m->full_name);

            printf("  Short Name [%s]: ",m->sn); fflush(stdout);
            read_line(buf,sizeof(buf));
            if(buf[0]){ str_upper(buf); if(sn_taken(buf,m->id)){printf("  [Error] Taken.\n");pause_enter();return;} SCOPY(m->sn,buf); }  /* Update SN if non-blank and unique */

            printf("  Full Name [%s]: ",m->full_name); fflush(stdout);
            read_line(buf,sizeof(buf));
            if(buf[0]){ to_title_case(buf); SCOPY(m->full_name,buf); }  /* Update name if non-blank */

            while(1){
                printf("  Designation [%s]\n  1=Prof 2=Assoc 3=Asst 4=Lecturer 0=Keep\n",m->desi);
                prompt("  Choice",buf,sizeof(buf));
                if(strlen(buf)==1){
                    if(buf[0]=='0') break;                                        /* Keep existing designation */
                    if(buf[0]=='1'){SCOPY(m->desi,"Professor");           break;}
                    if(buf[0]=='2'){SCOPY(m->desi,"Associate Professor"); break;}
                    if(buf[0]=='3'){SCOPY(m->desi,"Assistant Professor"); break;}
                    if(buf[0]=='4'){SCOPY(m->desi,"Lecturer");            break;}
                }
                printf("  [Error] Enter 0-4.\n");
            }

            printf("\n  Current RAs: ");
            for(int r=0;r<m->ra_count;r++){if(r>0)printf(" / ");printf("%s",m->ra[r]);}  /* Show existing RAs */
            printf("\n  Replace all? (y/N): "); fflush(stdout);
            read_line(buf,sizeof(buf));
            if(buf[0]=='y'||buf[0]=='Y'){
                m->ra_count=0;                      /* Clear all existing research areas */
                while(m->ra_count<MAX_RA){
                    char ra[MAX_STR]="";
                    printf("  Area %d: ",m->ra_count+1); fflush(stdout);
                    if(!fgets(ra,sizeof(ra),stdin)) break;
                    int rn=(int)strlen(ra); if(rn>0&&ra[rn-1]=='\n') ra[rn-1]='\0'; trim(ra);
                    if(!ra[0]) break;
                    to_title_case(ra);
                    /* Check for duplicate research area */
                    int dup=0;
                    for(int _d=0;_d<m->ra_count;_d++)
                        if(str_ieq(m->ra[_d],ra)){dup=1;break;}
                    if(dup){printf("  [Error] '%s' is already listed as a research area.\n",ra);continue;}
                    SCOPY(m->ra[m->ra_count],ra); m->ra_count++;
                }
            }

            printf("  Profile URL [%s]: ",m->profile_url); fflush(stdout);
            read_line(buf,sizeof(buf));
            if(buf[0]) SCOPY(m->profile_url,buf);   /* Update URL if non-blank */

            SCOPY(m->last_edited_by,g_admin); now_str(m->last_edited_at);  /* Record editor and timestamp */
            save_faculty();
            char det[MAX_TITLE]; snprintf(det,sizeof(det),"ID: %s, Name: %.100s",m->id,m->full_name);
            log_action(g_admin,"EDIT_FACULTY",det);
            printf("\n  [OK] Faculty updated.\n"); pause_enter(); return;
        }
        printf("  [Error] Invalid number. Enter 1-%d or 0 to cancel.\n",g_fac_count);
    }
}

/* ================================================================
   SCREEN: DELETE FACULTY
   ================================================================ */
/* Lists all faculty and lets the admin select one to delete after 'yes' confirmation;
   saves undo snapshot, removes by shifting array, persists, and logs */
static void screen_delete_faculty(void)
{
    clrscr(); section("DELETE FACULTY");
    if(g_fac_count==0){printf("\n  No faculty.\n");pause_enter();return;}
    printf("\n");
    for(int i=0;i<g_fac_count;i++)
        printf("  [%d] %s -- %s\n",i+1,g_fac[i].id,g_fac[i].full_name);  /* List faculty for selection */
    printf("\n");
    while(1){
        char sel[8]=""; prompt("Number to delete (0=cancel)",sel,sizeof(sel));
        if(sel[0]=='0'){printf("  Cancelled.\n");pause_enter();return;}
        int idx=atoi(sel)-1;
        if(idx>=0&&idx<g_fac_count){
            printf("\n  Delete: %s (%s)\n",g_fac[idx].full_name,g_fac[idx].id);
            char cf[16]=""; prompt("Type 'yes' to confirm",cf,sizeof(cf));
            if(strcmp(cf,"yes")!=0){printf("  Cancelled.\n");pause_enter();return;}
            char name[MAX_STR],idc[MAX_STR];
            SCOPY(name,g_fac[idx].full_name); SCOPY(idc,g_fac[idx].id);  /* Save name/ID before deletion */
            save_undo_snapshot();
            for(int i=idx;i<g_fac_count-1;i++) g_fac[i]=g_fac[i+1];     /* Shift array left to fill gap */
            g_fac_count--; save_faculty();
            char det[MAX_TITLE]; snprintf(det,sizeof(det),"ID: %s, Name: %.100s",idc,name);
            log_action(g_admin,"DELETE_FACULTY",det);
            printf("\n  [OK] '%s' deleted.\n",name); pause_enter(); return;
        }
        printf("  [Error] Invalid number. Enter 1-%d or 0 to cancel.\n",g_fac_count);
    }
}

/* ================================================================
   SCREEN: ADD PUBLICATION
   ================================================================ */
/* Interactive form to create a new publication: prompts for title, year, type, authors,
   journal, URL, indexing, and citations; validates uniqueness and required fields; saves and logs */
static void screen_add_pub(void)
{
    clrscr(); section("ADD PUBLICATION");
    if(g_fac_count==0){printf("\n  Add faculty first.\n");pause_enter();return;}  /* Authors must exist */
    Publication p; memset(&p,0,sizeof(p));

    if(!prompt("Title",p.title,sizeof(p.title))){printf("  [Error] Required.\n");pause_enter();return;}
    to_title_case(p.title);
    if(title_taken(p.title,-1)){printf("  [Error] Title already exists.\n");pause_enter();return;}  /* Reject duplicate */

    while(1){
        if(!prompt("Year (1876-2026)",p.year,sizeof(p.year)))
            {printf("  [Error] Year is required.\n");continue;}
        int yr=atoi(p.year);
        if(yr<1876||yr>2026)
            {printf("  [Error] Year must be between 1876 and 2026. Please try again.\n");continue;}
        break;
    }

    while(1){
        printf("\n  1=Journal  2=Conference  3=Review  4=Book Chapter\n");
        char ch[4]=""; prompt("Type (1-4)",ch,sizeof(ch));
        if(strlen(ch)==1){
            switch(ch[0]){
                case '1': SCOPY(p.type,"Journal");      goto type_ok;
                case '2': SCOPY(p.type,"Conference");   goto type_ok;
                case '3': SCOPY(p.type,"Review");       goto type_ok;
                case '4': SCOPY(p.type,"Book Chapter"); goto type_ok;
            }
        }
        printf("  [Error] Please enter 1, 2, 3, or 4.\n");
    }
    type_ok:;

    /* Author selection with validation */
    while(1){
        printf("\n  Faculty:\n");
        for(int i=0;i<g_fac_count;i++)
            printf("    [%d] %s -- %s\n",i+1,g_fac[i].sn,g_fac[i].full_name);  /* List faculty for author selection */
        printf("  Author numbers (space-separated): "); fflush(stdout);
        char al[MAX_STR]=""; read_line(al,sizeof(al));
        p.author_count=0;
        int bad=0;
        char tmp[MAX_STR]; strncpy(tmp,al,MAX_STR-1); tmp[MAX_STR-1]='\0';
        char *t=strtok(tmp," ,\t");   /* Tokenize by space/comma/tab */
        while(t){
            int ai=atoi(t)-1;
            if(ai<0||ai>=g_fac_count){
                printf("  [Error] '%s' is not a valid faculty number.\n",t);
                bad=1; break;
            }
            /* Check for duplicate author */
            int dup=0;
            for(int _d=0;_d<p.author_count;_d++)
                if(str_ieq(p.authors[_d],g_fac[ai].sn)){dup=1;break;}
            if(dup){
                printf("  [Error] '%s' (%s) is already listed as an author.\n",
                       g_fac[ai].sn,g_fac[ai].full_name);
                bad=1; break;
            }
            if(p.author_count<MAX_AUTHORS) SCOPY(p.authors[p.author_count++],g_fac[ai].sn);  /* Store author SN */
            t=strtok(NULL," ,\t");
        }
        if(!bad&&p.author_count>0) break;
        if(!bad) printf("  [Error] At least one author required.\n");
    }

    if(!prompt("Journal / Conference Name",p.journal,sizeof(p.journal)))
        {printf("  [Error] Required.\n");pause_enter();return;}
    to_title_case(p.journal);
    prompt("URL / DOI (optional)",p.url,sizeof(p.url));
    prompt("Indexing (e.g. Scopus, SCI)",p.indexing,sizeof(p.indexing));
    char cb[16]=""; prompt("Citations (default 0)",cb,sizeof(cb));
    p.citations=cb[0]?atoi(cb):0;    /* Default to 0 if blank */

    SCOPY(p.last_edited_by,g_admin); now_str(p.last_edited_at);
    save_undo_snapshot();
    g_pub[g_pub_count++]=p; save_pubs();    /* Append and persist */
    char det[MAX_TITLE]; snprintf(det,sizeof(det),"Title: %.200s, Year: %s",p.title,p.year);
    log_action(g_admin,"ADD_PUBLICATION",det);
    printf("\n  [OK] Publication added.\n"); pause_enter();
}

/* ================================================================
   SCREEN: EDIT PUBLICATION
   ================================================================ */
/* Lists all publications and lets the admin select one to edit; supports updating all fields;
   validates title uniqueness and year range; saves undo snapshot first */
static void screen_edit_pub(void)
{
    clrscr(); section("EDIT PUBLICATION");
    if(g_pub_count==0){printf("\n  No publications.\n");pause_enter();return;}
    printf("\n");
    for(int i=0;i<g_pub_count;i++){
        char t[52]; strncpy(t,g_pub[i].title,50); t[50]='\0';
        if((int)strlen(g_pub[i].title)>50) strcat(t,"...");         /* Truncate long titles for display */
        printf("  [%d] %s  (%s)\n",i+1,t,g_pub[i].year);
    }
    printf("\n");
    while(1){
        char sel[8]=""; prompt("Number to edit (0=cancel)",sel,sizeof(sel));
        if(sel[0]=='0'){printf("  Cancelled.\n");pause_enter();return;}
        int idx=atoi(sel)-1;
        if(idx>=0&&idx<g_pub_count){
            Publication *p=&g_pub[idx];
            char buf[MAX_TITLE]="";
            save_undo_snapshot();   /* snapshot BEFORE any edits */
            printf("\n  Editing: %s  (blank = keep)\n\n",p->title);

            printf("  Title [%s]: ",p->title); fflush(stdout);
            read_line(buf,sizeof(buf));
            if(buf[0]){to_title_case(buf);if(title_taken(buf,idx)){printf("  [Error] Title exists.\n");pause_enter();return;}SCOPY(p->title,buf);}  /* Update if non-blank and unique */

            while(1){
                printf("  Year [%s]: ",p->year); fflush(stdout);
                read_line(buf,sizeof(buf));
                if(!buf[0]) break;  /* blank = keep current */
                int y=atoi(buf);
                if(y<1876||y>2026)
                    {printf("  [Error] Year must be between 1876 and 2026. Please try again.\n");continue;}
                SCOPY(p->year,buf); break;
            }

            while(1){
                printf("  Type [%s] 1=Journal 2=Conference 3=Review 4=Book Chapter 0=Keep\n",p->type);
                prompt("  Choice",buf,sizeof(buf));
                if(strlen(buf)==1){
                    if(buf[0]=='0') break;
                    if(buf[0]=='1'){SCOPY(p->type,"Journal");      break;}
                    if(buf[0]=='2'){SCOPY(p->type,"Conference");   break;}
                    if(buf[0]=='3'){SCOPY(p->type,"Review");       break;}
                    if(buf[0]=='4'){SCOPY(p->type,"Book Chapter"); break;}
                }
                printf("  [Error] Enter 0-4.\n");
            }

            printf("  Current authors: ");
            for(int a=0;a<p->author_count;a++){if(a>0)printf(", ");printf("%s",p->authors[a]);}  /* Show existing authors */
            printf("\n  Replace? (y/N): "); fflush(stdout);
            read_line(buf,sizeof(buf));
            if(buf[0]=='y'||buf[0]=='Y'){
                while(1){
                    printf("  Faculty:\n");
                    for(int i=0;i<g_fac_count;i++) printf("    [%d] %s -- %s\n",i+1,g_fac[i].sn,g_fac[i].full_name);
                    printf("  Numbers: "); fflush(stdout);
                    char al[MAX_STR]=""; read_line(al,sizeof(al));
                    p->author_count=0; int bad=0;
                    char tmp[MAX_STR]; strncpy(tmp,al,MAX_STR-1); tmp[MAX_STR-1]='\0';
                    char *tk=strtok(tmp," ,\t");
                    while(tk){
                        int ai=atoi(tk)-1;
                        if(ai<0||ai>=g_fac_count){printf("  [Error] '%s' is not valid.\n",tk);bad=1;break;}
                        /* Check for duplicate author */
                        int dup=0;
                        for(int _d=0;_d<p->author_count;_d++)
                            if(str_ieq(p->authors[_d],g_fac[ai].sn)){dup=1;break;}
                        if(dup){
                            printf("  [Error] '%s' (%s) is already listed as an author.\n",
                                   g_fac[ai].sn,g_fac[ai].full_name);
                            bad=1; break;
                        }
                        if(p->author_count<MAX_AUTHORS) SCOPY(p->authors[p->author_count++],g_fac[ai].sn);
                        tk=strtok(NULL," ,\t");
                    }
                    if(!bad&&p->author_count>0) break;
                    if(!bad) printf("  [Error] At least one required.\n");
                }
            }

            printf("  Journal [%s]: ",p->journal); fflush(stdout);
            read_line(buf,sizeof(buf)); if(buf[0]){to_title_case(buf);SCOPY(p->journal,buf);}   /* Update journal */
            printf("  URL [%s]: ",p->url); fflush(stdout);
            read_line(buf,sizeof(buf)); if(buf[0]) SCOPY(p->url,buf);                           /* Update URL */
            printf("  Indexing [%s]: ",p->indexing); fflush(stdout);
            read_line(buf,sizeof(buf)); if(buf[0]) SCOPY(p->indexing,buf);                      /* Update indexing */
            printf("  Citations [%d]: ",p->citations); fflush(stdout);
            read_line(buf,sizeof(buf)); if(buf[0]) p->citations=atoi(buf);                      /* Update citation count */

            SCOPY(p->last_edited_by,g_admin); now_str(p->last_edited_at);  /* Record editor and timestamp */
            save_pubs();
            char det[MAX_TITLE]; snprintf(det,sizeof(det),"Title: %.200s",p->title);
            log_action(g_admin,"EDIT_PUBLICATION",det);
            printf("\n  [OK] Updated.\n"); pause_enter(); return;
        }
        printf("  [Error] Invalid number. Enter 1-%d or 0 to cancel.\n",g_pub_count);
    }
}

/* ================================================================
   SCREEN: DELETE PUBLICATION
   ================================================================ */
/* Lists all publications and lets the admin select one to delete after 'yes' confirmation;
   saves undo snapshot, removes by shifting array, persists, and logs */
static void screen_delete_pub(void)
{
    clrscr(); section("DELETE PUBLICATION");
    if(g_pub_count==0){printf("\n  No publications.\n");pause_enter();return;}
    printf("\n");
    for(int i=0;i<g_pub_count;i++){
        char t[52]; strncpy(t,g_pub[i].title,50); t[50]='\0';
        if((int)strlen(g_pub[i].title)>50) strcat(t,"...");    /* Truncate long titles for display list */
        printf("  [%d] %s  (%s)\n",i+1,t,g_pub[i].year);
    }
    printf("\n");
    while(1){
        char sel[8]=""; prompt("Number to delete (0=cancel)",sel,sizeof(sel));
        if(sel[0]=='0'){printf("  Cancelled.\n");pause_enter();return;}
        int idx=atoi(sel)-1;
        if(idx>=0&&idx<g_pub_count){
            printf("\n  Deleting: %s\n",g_pub[idx].title);
            char cf[16]=""; prompt("Type 'yes' to confirm",cf,sizeof(cf));
            if(strcmp(cf,"yes")!=0){printf("  Cancelled.\n");pause_enter();return;}
            char tc[MAX_TITLE]; SCOPY(tc,g_pub[idx].title);   /* Save title before deletion for log */
            save_undo_snapshot();
            for(int i=idx;i<g_pub_count-1;i++) g_pub[i]=g_pub[i+1];  /* Shift array left to fill gap */
            g_pub_count--; save_pubs();
            char det[MAX_TITLE]; snprintf(det,sizeof(det),"Title: %.200s",tc);
            log_action(g_admin,"DELETE_PUBLICATION",det);
            printf("\n  [OK] Deleted.\n"); pause_enter(); return;
        }
        printf("  [Error] Invalid number. Enter 1-%d or 0 to cancel.\n",g_pub_count);
    }
}

/* ================================================================
   SCREEN: SEARCH  (stays in loop until option 6 is chosen)
   ================================================================ */
/* Provides 5 search modes (keyword, faculty, year, type, RA); displays matching faculty and/or
   publications tables for each query; loops until user exits */
static void screen_search(void)
{
    while(1){
        clrscr(); section("SEARCH");
        printf("\n  Search modes:\n");
        printf("    [1] Keyword     (title / journal / indexing)\n");
        printf("    [2] Faculty     (SN / ID / name / designation)\n");
        printf("    [3] Year\n");
        printf("    [4] Publication Type\n");
        printf("    [5] Research Area\n");
        printf("    [6] Exit Search\n\n");

        char sel[4]="";
        while(1){
            prompt("Mode (1-6)",sel,sizeof(sel));
            if(strlen(sel)==1&&sel[0]>='1'&&sel[0]<='6') break;   /* Accept only 1-6 */
            printf("  [Error] Please enter a number from 1 to 6.\n");
        }
        if(sel[0]=='6') return;   /* Exit search loop */

        char query[MAX_TITLE]="";
        prompt("Query",query,sizeof(query));
        trim(query);
        if(!query[0]){printf("  Empty query. Returning to search menu.\n");pause_enter();continue;}

        int mode=atoi(sel);
        int fhits=0, phits=0;
        printf("\n"); hr2();

        /* Faculty matches -- shown for faculty search, RA search, and keyword */
        if(mode==1||mode==2||mode==5){
            printf("  FACULTY MATCHES\n\n");
            int fi[MAX_FACULTY]; int fc=0;
            for(int i=0;i<g_fac_count;i++){
                Faculty *m=&g_fac[i]; int hit=0;
                if(mode==2) hit=str_ieq(m->id,query)||str_ieq(m->sn,query)||str_ihas(m->full_name,query)||str_ihas(m->desi,query);  /* Faculty-specific match */
                else if(mode==5){ for(int r=0;r<m->ra_count&&!hit;r++) if(str_ihas(m->ra[r],query)) hit=1; }  /* RA match */
                else if(mode==1){
                    hit=str_ihas(m->full_name,query)||str_ieq(m->sn,query)||str_ihas(m->desi,query);
                    for(int r=0;r<m->ra_count&&!hit;r++) if(str_ihas(m->ra[r],query)) hit=1;   /* Keyword includes RA */
                }
                if(hit) fi[fc++]=i;
            }
            fhits=fc;
            if(fc>0) print_fac_table_screen(fi,fc);   /* Show matching faculty table */
            else printf("  (no faculty matched)\n");
            printf("\n");
        }

        /* Publication matches */
        printf("  PUBLICATION MATCHES\n\n");
        int pi[MAX_PUBS]; int pc=0;
        for(int i=0;i<g_pub_count;i++){
            Publication *p=&g_pub[i]; int hit=0;
            if(mode==1) hit=str_ihas(p->title,query)||str_ihas(p->journal,query)||str_ihas(p->indexing,query);  /* Keyword search in title/journal/indexing */
            else if(mode==2){
                for(int f=0;f<g_fac_count&&!hit;f++){
                    Faculty *m=&g_fac[f];
                    int fh=str_ieq(m->id,query)||str_ieq(m->sn,query)||str_ihas(m->full_name,query)||str_ihas(m->desi,query);
                    if(fh) for(int a=0;a<p->author_count&&!hit;a++) if(str_ieq(p->authors[a],m->sn)) hit=1;   /* Match via faculty membership */
                }
            } else if(mode==3) hit=str_ieq(p->year,query);                /* Exact year match */
            else if(mode==4) hit=str_ihas(p->type,query);                  /* Publication type match */
            else if(mode==5){
                for(int f=0;f<g_fac_count&&!hit;f++){
                    Faculty *m=&g_fac[f]; int fh=0;
                    for(int r=0;r<m->ra_count&&!fh;r++) if(str_ihas(m->ra[r],query)) fh=1;   /* Faculty matches RA */
                    if(fh) for(int a=0;a<p->author_count&&!hit;a++) if(str_ieq(p->authors[a],m->sn)) hit=1;  /* Publication authored by that faculty */
                }
            }
            if(hit) pi[pc++]=i;
        }
        phits=pc;
        if(pc>0) print_pub_table_screen(pi,pc);   /* Show matching publications table */
        else printf("  (no publications matched)\n");

        hr2();
        printf("  Results: %d faculty,  %d publications\n",fhits,phits);
        pause_enter();
        /* loop back to search menu */
    }
}

/* ================================================================
   SCREEN: SYSTEM OVERVIEW
   ================================================================ */
/* Displays comprehensive statistics: totals, faculty by designation, RA breakdown,
   year/type/faculty publication counts, and ASCII bar charts for all dimensions */
static void screen_overview(void)
{
    clrscr(); section("SYSTEM OVERVIEW");

    float avg=(g_fac_count>0)?(float)g_pub_count/g_fac_count:0.0f;    /* Average publications per faculty */
    int mny=9999,mxy=0;
    for(int i=0;i<g_pub_count;i++){int y=atoi(g_pub[i].year);if(y>0){if(y<mny)mny=y;if(y>mxy)mxy=y;}}  /* Find year range */

    printf("\n  Total Faculty      : %d\n",g_fac_count);
    printf("  Total Publications : %d\n",g_pub_count);
    printf("  Avg Publications/Faculty   : %.2f\n",avg);
    if(g_pub_count>0&&mny<=mxy) printf("  Publication Span   : %d -- %d\n",mny,mxy);

    /* ---- Faculty by Designation ---- */
    printf("\n"); hr();
    printf("  NUMBER OF FACULTY BY DESIGNATION\n"); hr();
    const char *ds[]={"Professor","Associate Professor","Assistant Professor","Lecturer"};
    int dc[4]={0,0,0,0};
    for(int i=0;i<g_fac_count;i++) for(int d=0;d<4;d++) if(strcmp(g_fac[i].desi,ds[d])==0) dc[d]++;  /* Count per designation */
    {int cw[]={26,12}; int nc=2; const char *hdr[]={"Designation","Count"};
     tbl_border(cw,nc); tbl_row_plain(hdr,cw,nc); tbl_border(cw,nc);
     for(int d=0;d<4;d++){char c[8];sprintf(c,"%d",dc[d]);const char *r[]={ds[d],c};tbl_row_plain(r,cw,nc);}  /* One row per designation */
     char tot[8]; sprintf(tot,"%d",g_fac_count); const char *tr[]={"TOTAL",tot}; tbl_row_plain(tr,cw,nc);     /* Total row */
     tbl_border(cw,nc);}

    /* ---- RA table ---- */
    printf("\n"); hr();
    printf("  FACULTY AND PUBLICATIONS BY RESEARCH AREA\n"); hr();
    static char all_ra[MAX_FACULTY*MAX_RA][MAX_STR];
    int n_ra=0; memset(all_ra,0,sizeof(all_ra));
    for(int i=0;i<g_fac_count;i++)
        for(int r=0;r<g_fac[i].ra_count;r++){
            int dup=0; for(int x=0;x<n_ra;x++) if(strcmp(all_ra[x],g_fac[i].ra[r])==0){dup=1;break;}
            if(!dup&&n_ra<MAX_FACULTY*MAX_RA){strncpy(all_ra[n_ra],g_fac[i].ra[r],MAX_STR-1);all_ra[n_ra][MAX_STR-1]='\0';n_ra++;}  /* Build deduplicated RA list */
        }
    {int cw[]={40,10,14}; int nc=3; const char *hdr[]={"Research Area","Faculty","Publications"};
     tbl_border(cw,nc); tbl_row_plain(hdr,cw,nc); tbl_border(cw,nc);
     for(int ri=0;ri<n_ra;ri++){
         int fc=0,pc2=0;
         for(int i=0;i<g_fac_count;i++)
             for(int r=0;r<g_fac[i].ra_count;r++)
                 if(strcmp(g_fac[i].ra[r],all_ra[ri])==0){fc++;pc2+=pubs_for_sn(g_fac[i].sn);break;}  /* Count faculty and publications per RA */
         char fc_s[8],pc_s[8]; sprintf(fc_s,"%d",fc); sprintf(pc_s,"%d",pc2);
         const char *row[]={all_ra[ri],fc_s,pc_s}; tbl_row_plain(row,cw,nc);
     }
     if(!n_ra) printf("  (no data)\n");
     tbl_border(cw,nc);}

    /* ---- Year table ---- */
    printf("\n"); hr(); printf("  PUBLICATION COUNT BY YEAR\n"); hr();
    char yrs[64][8]; int yrc[64]; int ny=0;
    for(int i=0;i<g_pub_count;i++){
        int f=0; for(int y=0;y<ny;y++) if(strcmp(yrs[y],g_pub[i].year)==0){yrc[y]++;f=1;break;}
        if(!f&&ny<64){strncpy(yrs[ny],g_pub[i].year,7);yrs[ny][7]='\0';yrc[ny++]=1;}  /* Accumulate counts per year */
    }
    for(int a=0;a<ny-1;a++) for(int b=a+1;b<ny;b++) if(strcmp(yrs[a],yrs[b])>0){char ty[8];strcpy(ty,yrs[a]);strcpy(yrs[a],yrs[b]);strcpy(yrs[b],ty);int tc=yrc[a];yrc[a]=yrc[b];yrc[b]=tc;}  /* Bubble sort years ascending */
    {int cw[]={10,12}; int nc=2; const char *hdr[]={"Year","Count"};
     tbl_border(cw,nc); tbl_row_plain(hdr,cw,nc); tbl_border(cw,nc);
     for(int y=0;y<ny;y++){char c[8];sprintf(c,"%d",yrc[y]);const char *r[]={yrs[y],c};tbl_row_plain(r,cw,nc);}
     if(!ny) printf("  (no data)\n");
     tbl_border(cw,nc); }

    /* ---- Type table ---- */
    printf("\n"); hr(); printf("  PUBLICATION COUNT BY TYPE\n"); hr();
    char tps[10][MAX_STR]; int tpc[10]; int nt=0;
    for(int i=0;i<g_pub_count;i++){
        int f=0; for(int t=0;t<nt;t++) if(strcmp(tps[t],g_pub[i].type)==0){tpc[t]++;f=1;break;}
        if(!f&&nt<10){SCOPY(tps[nt],g_pub[i].type);tpc[nt++]=1;}   /* Accumulate counts per publication type */
    }
    {int cw[]={18,12}; int nc=2; const char *hdr[]={"Type","Count"};
     tbl_border(cw,nc); tbl_row_plain(hdr,cw,nc); tbl_border(cw,nc);
     for(int t=0;t<nt;t++){char c[8];sprintf(c,"%d",tpc[t]);const char *r[]={tps[t],c};tbl_row_plain(r,cw,nc);}
     if(!nt) printf("  (no data)\n");
     tbl_border(cw,nc); }

    /* ---- Faculty publications table ---- */
    printf("\n"); hr(); printf("  PUBLICATION COUNT BY FACULTY\n"); hr();
    int order[MAX_FACULTY];
    for(int i=0;i<g_fac_count;i++) order[i]=i;
    for(int a=0;a<g_fac_count-1;a++) for(int b=a+1;b<g_fac_count;b++)
        if(pubs_for_sn(g_fac[order[a]].sn)<pubs_for_sn(g_fac[order[b]].sn)){int t=order[a];order[a]=order[b];order[b]=t;}  /* Sort faculty by publication count descending */
    {int cw[]={8,30,14}; int nc=3; const char *hdr[]={"SN","Name","Publications"};
     tbl_border(cw,nc); tbl_row_plain(hdr,cw,nc); tbl_border(cw,nc);
     for(int i=0;i<g_fac_count;i++){Faculty *m=&g_fac[order[i]];char c[8];sprintf(c,"%d",pubs_for_sn(m->sn));const char *r[]={m->sn,m->full_name,c};tbl_row_plain(r,cw,nc);}
     if(!g_fac_count) printf("  (no data)\n");
     tbl_border(cw,nc); }

    /* ---- ASCII bar charts ---- */
    int maxRApub=0;
    for(int ri=0;ri<n_ra;ri++){int pc2=0;for(int i=0;i<g_fac_count;i++) for(int r=0;r<g_fac[i].ra_count;r++) if(strcmp(g_fac[i].ra[r],all_ra[ri])==0){pc2+=pubs_for_sn(g_fac[i].sn);break;} if(pc2>maxRApub) maxRApub=pc2;}  /* Find max pubs/RA for bar scaling */
    int maxRAfac=0;
    for(int ri=0;ri<n_ra;ri++){int fc=0;for(int i=0;i<g_fac_count;i++) for(int r=0;r<g_fac[i].ra_count;r++) if(strcmp(g_fac[i].ra[r],all_ra[ri])==0){fc++;break;} if(fc>maxRAfac) maxRAfac=fc;}  /* Find max faculty/RA for bar scaling */
    int maxYr=0; for(int y=0;y<ny;y++) if(yrc[y]>maxYr) maxYr=yrc[y];    /* Find max year count for bar scaling */
    int maxTp=0; for(int t=0;t<nt;t++) if(tpc[t]>maxTp) maxTp=tpc[t];    /* Find max type count for bar scaling */

    printf("\n"); hr2(); printf("  CHART: PUBLICATIONS PER RESEARCH AREA\n"); hr2();
    printf("  %-38s | %-*s | Count\n","Research Area",BAR_WIDTH,"Bar"); hr();
    for(int ri=0;ri<n_ra;ri++){int pc2=0;for(int i=0;i<g_fac_count;i++) for(int r=0;r<g_fac[i].ra_count;r++) if(strcmp(g_fac[i].ra[r],all_ra[ri])==0){pc2+=pubs_for_sn(g_fac[i].sn);break;} bar_chart(all_ra[ri],pc2,maxRApub>0?maxRApub:1,BAR_WIDTH);}
    if(!n_ra) printf("  (no data)\n");

    printf("\n"); hr2(); printf("  CHART: FACULTY PER RESEARCH AREA\n"); hr2();
    printf("  %-38s | %-*s | Count\n","Research Area",BAR_WIDTH,"Bar"); hr();
    for(int ri=0;ri<n_ra;ri++){int fc=0;for(int i=0;i<g_fac_count;i++) for(int r=0;r<g_fac[i].ra_count;r++) if(strcmp(g_fac[i].ra[r],all_ra[ri])==0){fc++;break;} bar_chart(all_ra[ri],fc,maxRAfac>0?maxRAfac:1,BAR_WIDTH);}
    if(!n_ra) printf("  (no data)\n");

    printf("\n"); hr2(); printf("  CHART: YEAR-WISE PUBLICATION COUNT\n"); hr2();
    printf("  %-38s | %-*s | Count\n","Year",BAR_WIDTH,"Bar"); hr();
    for(int y=0;y<ny;y++) bar_chart(yrs[y],yrc[y],maxYr>0?maxYr:1,BAR_WIDTH);
    if(!ny) printf("  (no data)\n");

    printf("\n"); hr2(); printf("  CHART: PUBLICATIONS BY TYPE\n"); hr2();
    printf("  %-38s | %-*s | Count\n","Type",BAR_WIDTH,"Bar"); hr();
    for(int t=0;t<nt;t++) bar_chart(tps[t],tpc[t],maxTp>0?maxTp:1,BAR_WIDTH);
    if(!nt) printf("  (no data)\n");

    pause_enter();
}


/* ================================================================
   REPORT HELPERS: write one aligned text table cell (w chars, pad/clip)
   ================================================================ */
/* fwrite_col already defined earlier */

/* ================================================================
   REPORT: HTML faculty table
   Full Name is <a href="profile_url">Full Name</a>
   ================================================================ */
/* Writes a complete HTML faculty table to file h; Full Name links to profile URL if available */
static void html_fac_table(FILE *h)
{
    fprintf(h,"<table>\n<thead><tr>"
              "<th>ID</th><th>SN</th><th>Full Name</th>"
              "<th>Designation</th><th>Research Area(s)</th>"
              "<th>Publications</th></tr></thead>\n<tbody>\n");   /* Write table header */
    for(int i=0;i<g_fac_count;i++){
        Faculty *m=&g_fac[i];
        char ra_buf[MAX_TITLE]="";
        for(int r=0;r<m->ra_count;r++){
            if(r>0) strncat(ra_buf,"; ",sizeof(ra_buf)-strlen(ra_buf)-1);   /* Semicolon separator */
            strncat(ra_buf,m->ra[r],sizeof(ra_buf)-strlen(ra_buf)-1);       /* Append each RA */
        }
        if(!ra_buf[0]) strcpy(ra_buf,"--");                                  /* Placeholder if no RAs */
        char pc[8]; sprintf(pc,"%d",pubs_for_sn(m->sn));                    /* Publication count */
        fprintf(h,"<tr><td>%s</td><td>%s</td><td>",m->id,m->sn);           /* Write ID and SN cells */
        if(m->profile_url[0])
            fprintf(h,"<a href=\"%s\">%s</a>",m->profile_url,m->full_name); /* Name as hyperlink if URL exists */
        else
            fprintf(h,"%s",m->full_name);                                    /* Plain name if no URL */
        fprintf(h,"</td><td>%s</td><td>%s</td><td>%s</td></tr>\n",
                m->desi,ra_buf,pc);                                          /* Designation, RAs, pub count cells */
    }
    fprintf(h,"</tbody>\n</table>\n");
}

/* ================================================================
   REPORT: HTML publication table
   Title is <a href="url">Title</a>
   ================================================================ */
/* Writes a complete HTML publications table to file h for the given indices;
   Title links to DOI/URL if available */
static void html_pub_table(FILE *h, int *indices, int count)
{
    fprintf(h,"<table>\n<thead><tr>"
              "<th>#</th><th>Title</th><th>Year</th><th>Type</th>"
              "<th>Author(s)</th><th>Journal</th>"
              "<th>Research Area(s)</th><th>Indexing</th><th>Cit</th>"
              "</tr></thead>\n<tbody>\n");   /* Write table header row */
    for(int ii=0;ii<count;ii++){
        Publication *p=&g_pub[indices[ii]];
        char auth[MAX_STR]; authors_str(p,auth,sizeof(auth));             /* Build authors string */
        char ra_buf[MAX_TITLE]; pub_ra_display(p,ra_buf,sizeof(ra_buf)); /* Build research areas string */
        fprintf(h,"<tr><td>%d</td><td>",ii+1);                           /* Serial number cell */
        if(p->url[0])
            fprintf(h,"<a href=\"%s\">%s</a>",p->url,p->title);          /* Title as hyperlink if URL exists */
        else
            fprintf(h,"%s",p->title);                                     /* Plain title if no URL */
        fprintf(h,"</td><td>%s</td><td>%s</td><td>%s</td>"
                  "<td>%s</td><td>%s</td><td>%s</td><td>%d</td></tr>\n",
                p->year,p->type,auth,p->journal,ra_buf,p->indexing,p->citations);  /* Remaining cells */
    }
    fprintf(h,"</tbody>\n</table>\n");
}

/* ================================================================
   REPORT: TXT faculty table  (ID | SN | Full Name | Desi | RA | Profile URL)
   Profile URL is a separate column.
   ================================================================ */
/* Generates a formatted plain-text faculty table with dynamic column widths,
   handling multi-line wrapping for long Research Area entries, and writes it to file 'f' */
static void txt_fac_table(FILE *f)
{
    /* Compute dynamic widths */
    int w_id=2, w_sn=2, w_name=9, w_desi=11, w_ra=16, w_url=12;  /* Initialize minimum column widths */
    for(int i=0;i<g_fac_count;i++){
        Faculty *m=&g_fac[i];
        char ra_tmp[MAX_TITLE]="";
        for(int r=0;r<m->ra_count;r++){
            if(r>0) strncat(ra_tmp," / ",sizeof(ra_tmp)-strlen(ra_tmp)-1);   /* Separator between areas */
            strncat(ra_tmp,m->ra[r],sizeof(ra_tmp)-strlen(ra_tmp)-1);        /* Append research area */
        }
        int n;
        n=(int)strlen(m->id);          if(n>w_id)   w_id=n;    /* Expand ID column if needed */
        n=(int)strlen(m->sn);          if(n>w_sn)   w_sn=n;    /* Expand SN column if needed */
        n=(int)strlen(m->full_name);   if(n>w_name) w_name=n;  /* Expand Full Name column if needed */
        n=(int)strlen(m->desi);        if(n>w_desi) w_desi=n;  /* Expand Designation column if needed */
        n=(int)strlen(ra_tmp);         if(n>w_ra)   w_ra=n;    /* Expand Research Area column if needed */
        n=(int)strlen(m->profile_url); if(n>w_url)  w_url=n;   /* Expand Profile URL column if needed */
    }
    if(w_ra  >50) w_ra  =50;   /* Cap Research Area column to prevent excessively wide tables */
    if(w_url >60) w_url =60;   /* Cap Profile URL column width */
    /* Ensure header labels fit */
    if(w_id  <2)  w_id  =2;    /* Minimum width for "ID" header */
    if(w_sn  <2)  w_sn  =2;    /* Minimum width for "SN" header */
    if(w_name<9)  w_name=9;    /* Minimum width for "Full Name" header */
    if(w_desi<11) w_desi=11;   /* Minimum width for "Designation" header */
    if(w_url <11) w_url =11;   /* Minimum width for "Profile URL" header */

    int nc=6;                                                         /* Total number of columns */
    int cw[]={w_id,w_sn,w_name,w_desi,w_ra,w_url};                   /* Final computed column widths */
    const char *hdr[]={"ID","SN","Full Name","Designation","Research Area(s)","Profile URL"};  /* Column headers */
    ftbl_border(f,cw,nc);       /* Print top border */
    ftbl_row(f,hdr,cw,nc);      /* Print header row */
    ftbl_border(f,cw,nc);       /* Print separator border below header */

    for(int i=0;i<g_fac_count;i++){
        Faculty *m=&g_fac[i];
        char ra_buf[MAX_TITLE]="";
        for(int r=0;r<m->ra_count;r++){
            if(r>0) strncat(ra_buf," / ",sizeof(ra_buf)-strlen(ra_buf)-1);   /* Separator between areas */
            strncat(ra_buf,m->ra[r],sizeof(ra_buf)-strlen(ra_buf)-1);        /* Append research area */
        }
        if(!ra_buf[0]) strcpy(ra_buf,"--");   /* Placeholder if no research areas */

        int ra_len=(int)strlen(ra_buf);        /* Total RA string length */
        int r_fc=first_chunk_w(ra_buf,w_ra);   /* Width of first displayable RA chunk */

        fprintf(f,"  |");
        fprintf(f," "); fwrite_col(f,m->id,w_id);        fprintf(f," |");  /* ID cell */
        fprintf(f," "); fwrite_col(f,m->sn,w_sn);        fprintf(f," |");  /* SN cell */
        fprintf(f," "); fwrite_col(f,m->full_name,w_name);fprintf(f," |"); /* Full Name cell */
        fprintf(f," "); fwrite_col(f,m->desi,w_desi);    fprintf(f," |");  /* Designation cell */
        fprintf(f," ");
        for(int k=0;k<r_fc;k++) fputc(ra_buf[k],f);      /* Print first chunk of RA */
        for(int k=r_fc;k<w_ra;k++) fputc(' ',f);          /* Pad RA column */
        fprintf(f," |");
        fprintf(f," "); fwrite_col(f,m->profile_url[0]?m->profile_url:"--",w_url); fprintf(f," |\n");  /* URL or "--" */

        /* RA continuation rows (no blank lines between) */
        int r_pos=r_fc; while(r_pos<ra_len&&ra_buf[r_pos]==' ') r_pos++;  /* Skip spaces after first chunk */
        while(r_pos<ra_len){
            int chunk=w_ra; if(r_pos+chunk>=ra_len) chunk=ra_len-r_pos;              /* Last chunk: remaining */
            else{int k=chunk;while(k>0&&ra_buf[r_pos+k]!=' ')k--;if(k>0)chunk=k;}   /* Word-boundary break */
            fprintf(f,"  |");
            for(int ci=0;ci<4;ci++){fprintf(f," ");fwrite_col(f,"",cw[ci]);fprintf(f," |");}  /* Empty leading cells */
            fprintf(f," ");
            for(int k=0;k<chunk;k++) fputc(ra_buf[r_pos+k],f);   /* Print RA continuation chunk */
            for(int k=chunk;k<w_ra;k++) fputc(' ',f);              /* Pad RA column */
            fprintf(f," |");
            fprintf(f," "); fwrite_col(f,"",w_url); fprintf(f," |\n");  /* Empty URL cell */
            r_pos+=chunk; while(r_pos<ra_len&&ra_buf[r_pos]==' ') r_pos++;  /* Advance past chunk and spaces */
        }
    }
    ftbl_border(f,cw,nc);   /* Print bottom border */
}

/* ================================================================
   REPORT: TXT publication table  (URL is a separate column)
   ================================================================ */
/* Generates a formatted plain-text publications table with dynamic column widths,
   handling independent multi-line wrapping for Title, Journal, Research Area, and URL fields */
static void txt_pub_table(FILE *f, int *indices, int count)
{
    if(count==0){ fprintf(f,"  (no publications)\n"); return; }   /* Early exit with message if empty */

    /* Compute dynamic column widths */
    int w_num=1, w_title=5, w_year=4, w_type=4,
        w_auth=9, w_jour=7, w_ra=16, w_idx=8, w_cit=3, w_url=3;  /* Initialize minimum column widths */
    for(int ii=0;ii<count;ii++){
        Publication *p=&g_pub[indices[ii]];
        char auth[MAX_STR]; authors_str(p,auth,sizeof(auth));             /* Build authors string */
        char ra_buf[MAX_TITLE]; pub_ra_display(p,ra_buf,sizeof(ra_buf)); /* Build research areas string */
        char num[16]; snprintf(num,sizeof(num),"%d",ii+1);                /* Format serial number */
        char cit[8]; snprintf(cit,sizeof(cit),"%d",p->citations);         /* Format citation count */
        int n;
        n=(int)strlen(num);        if(n>w_num)   w_num=n;    /* Expand # column if needed */
        n=(int)strlen(p->title);   if(n>w_title) w_title=n;  /* Expand Title column if needed */
        n=(int)strlen(p->year);    if(n>w_year)  w_year=n;   /* Expand Year column if needed */
        n=(int)strlen(p->type);    if(n>w_type)  w_type=n;   /* Expand Type column if needed */
        n=(int)strlen(auth);       if(n>w_auth)  w_auth=n;   /* Expand Author(s) column if needed */
        n=(int)strlen(p->journal); if(n>w_jour)  w_jour=n;   /* Expand Journal column if needed */
        n=(int)strlen(ra_buf);     if(n>w_ra)    w_ra=n;     /* Expand Research Area column if needed */
        n=(int)strlen(p->indexing);if(n>w_idx)   w_idx=n;    /* Expand Indexing column if needed */
        n=(int)strlen(cit);        if(n>w_cit)   w_cit=n;    /* Expand Citations column if needed */
        n=(int)strlen(p->url);     if(n>w_url)   w_url=n;    /* Expand URL column if needed */
    }
    /* Cap wrapping columns */
    if(w_title>60) w_title=60;   /* Cap Title to prevent excessively wide table */
    if(w_jour >40) w_jour =40;   /* Cap Journal column */
    if(w_ra   >40) w_ra   =40;   /* Cap Research Area column */
    if(w_auth >20) w_auth =20;   /* Cap Author(s) column */
    if(w_idx  >16) w_idx  =16;   /* Cap Indexing column */
    if(w_url  >60) w_url  =60;   /* Cap URL column */
    /* Ensure header labels fit */
    if(w_url  < 3) w_url  = 3;   /* Minimum width for "URL" header */

    int nc=10;   /* Total number of columns */
    int cw[]={w_num,w_title,w_year,w_type,w_auth,w_jour,w_ra,w_idx,w_cit,w_url};  /* Final column widths */
    const char *hdr[]={"#","Title","Year","Type","Author(s)",
                       "Journal","Research Area(s)","Indexing","Cit","URL"};        /* Column headers */
    ftbl_border(f,cw,nc);    /* Print top border */
    ftbl_row(f,hdr,cw,nc);   /* Print header row */
    ftbl_border(f,cw,nc);    /* Print separator border */

    for(int ii=0;ii<count;ii++){
        Publication *p=&g_pub[indices[ii]];
        char num[16]; snprintf(num,sizeof(num),"%d",ii+1);                 /* Format serial number */
        char cit[8];  snprintf(cit,sizeof(cit),"%d",p->citations);         /* Format citation count */
        char auth[MAX_STR];     authors_str(p,auth,sizeof(auth));           /* Build authors string */
        char ra_buf[MAX_TITLE]; pub_ra_display(p,ra_buf,sizeof(ra_buf));   /* Build research areas string */

        int title_len=(int)strlen(p->title);   /* Total title length */
        int jour_len =(int)strlen(p->journal); /* Total journal length */
        int ra_len   =(int)strlen(ra_buf);     /* Total RA string length */
        int url_len  =(int)strlen(p->url);     /* Total URL length */

        int t_fc=first_chunk_w(p->title,  w_title);  /* First title chunk width */
        int j_fc=first_chunk_w(p->journal,w_jour);   /* First journal chunk width */
        int r_fc=first_chunk_w(ra_buf,    w_ra);     /* First RA chunk width */
        int u_fc=first_chunk_w(p->url,    w_url);    /* First URL chunk width */

        /* First row */
        fprintf(f,"  |");
        fprintf(f," "); fwrite_col(f,num,w_num);    fprintf(f," |");              /* # cell */
        fprintf(f," ");
        for(int k=0;k<t_fc;k++) fputc(p->title[k],f);    /* First title chunk */
        for(int k=t_fc;k<w_title;k++) fputc(' ',f);       /* Pad title column */
        fprintf(f," |");
        fprintf(f," "); fwrite_col(f,p->year,    w_year); fprintf(f," |");        /* Year cell */
        fprintf(f," "); fwrite_col(f,p->type,    w_type); fprintf(f," |");        /* Type cell */
        fprintf(f," "); fwrite_col(f,auth,        w_auth); fprintf(f," |");       /* Authors cell */
        fprintf(f," ");
        for(int k=0;k<j_fc;k++) fputc(p->journal[k],f);  /* First journal chunk */
        for(int k=j_fc;k<w_jour;k++) fputc(' ',f);        /* Pad journal column */
        fprintf(f," |");
        fprintf(f," ");
        for(int k=0;k<r_fc;k++) fputc(ra_buf[k],f);      /* First RA chunk */
        for(int k=r_fc;k<w_ra;k++) fputc(' ',f);          /* Pad RA column */
        fprintf(f," |");
        fprintf(f," "); fwrite_col(f,p->indexing,w_idx); fprintf(f," |");         /* Indexing cell */
        fprintf(f," "); fwrite_col(f,cit,         w_cit); fprintf(f," |");        /* Citations cell */
        fprintf(f," ");
        for(int k=0;k<u_fc;k++) fputc(p->url[k],f);      /* First URL chunk */
        for(int k=u_fc;k<w_url;k++) fputc(' ',f);         /* Pad URL column */
        fprintf(f," |\n");

        /* Continuation rows -- title, journal, RA, URL each wrap independently */
        {
            int t_pos=t_fc; while(t_pos<title_len&&p->title[t_pos]==' ')   t_pos++;  /* Skip spaces after title chunk */
            int j_pos=j_fc; while(j_pos<jour_len &&p->journal[j_pos]==' ') j_pos++;  /* Skip spaces after journal chunk */
            int r_pos=r_fc; while(r_pos<ra_len   &&ra_buf[r_pos]==' ')     r_pos++;  /* Skip spaces after RA chunk */
            int u_pos=u_fc; while(u_pos<url_len  &&p->url[u_pos]==' ')     u_pos++;  /* Skip spaces after URL chunk */
            while(t_pos<title_len||j_pos<jour_len||r_pos<ra_len||u_pos<url_len){  /* Continue while any field has remaining text */
                fprintf(f,"  |");
                fprintf(f," "); fwrite_col(f,"",w_num); fprintf(f," |");   /* Empty # cell */
                /* title */
                fprintf(f," ");
                if(t_pos<title_len){
                    int chunk=w_title; if(t_pos+chunk>=title_len) chunk=title_len-t_pos;        /* Last title chunk */
                    else{int k=chunk;while(k>0&&p->title[t_pos+k]!=' ')k--;if(k>0)chunk=k;}    /* Word-boundary break */
                    for(int k=0;k<chunk;k++) fputc(p->title[t_pos+k],f);                        /* Print chunk */
                    for(int k=chunk;k<w_title;k++) fputc(' ',f);                                 /* Pad column */
                    t_pos+=chunk; while(t_pos<title_len&&p->title[t_pos]==' ') t_pos++;         /* Advance */
                } else fwrite_col(f,"",w_title);   /* Title exhausted: empty cell */
                fprintf(f," |");
                fprintf(f," "); fwrite_col(f,"",w_year); fprintf(f," |");  /* Empty Year cell */
                fprintf(f," "); fwrite_col(f,"",w_type); fprintf(f," |");  /* Empty Type cell */
                fprintf(f," "); fwrite_col(f,"",w_auth); fprintf(f," |");  /* Empty Authors cell */
                /* journal */
                fprintf(f," ");
                if(j_pos<jour_len){
                    int chunk=w_jour; if(j_pos+chunk>=jour_len) chunk=jour_len-j_pos;             /* Last journal chunk */
                    else{int k=chunk;while(k>0&&p->journal[j_pos+k]!=' ')k--;if(k>0)chunk=k;}   /* Word-boundary break */
                    for(int k=0;k<chunk;k++) fputc(p->journal[j_pos+k],f);                       /* Print chunk */
                    for(int k=chunk;k<w_jour;k++) fputc(' ',f);                                   /* Pad column */
                    j_pos+=chunk; while(j_pos<jour_len&&p->journal[j_pos]==' ') j_pos++;         /* Advance */
                } else fwrite_col(f,"",w_jour);    /* Journal exhausted: empty cell */
                fprintf(f," |");
                /* RA */
                fprintf(f," ");
                if(r_pos<ra_len){
                    int chunk=w_ra; if(r_pos+chunk>=ra_len) chunk=ra_len-r_pos;                   /* Last RA chunk */
                    else{int k=chunk;while(k>0&&ra_buf[r_pos+k]!=' ')k--;if(k>0)chunk=k;}         /* Word-boundary break */
                    for(int k=0;k<chunk;k++) fputc(ra_buf[r_pos+k],f);                            /* Print chunk */
                    for(int k=chunk;k<w_ra;k++) fputc(' ',f);                                      /* Pad column */
                    r_pos+=chunk; while(r_pos<ra_len&&ra_buf[r_pos]==' ') r_pos++;                /* Advance */
                } else fwrite_col(f,"",w_ra);      /* RA exhausted: empty cell */
                fprintf(f," |");
                fprintf(f," "); fwrite_col(f,"",w_idx); fprintf(f," |");   /* Empty Indexing cell */
                fprintf(f," "); fwrite_col(f,"",w_cit); fprintf(f," |");   /* Empty Citations cell */
                /* URL */
                fprintf(f," ");
                if(u_pos<url_len){
                    int chunk=w_url; if(u_pos+chunk>=url_len) chunk=url_len-u_pos;                /* Last URL chunk */
                    else{int k=chunk;while(k>0&&p->url[u_pos+k]!=' ')k--;if(k>0)chunk=k;}         /* Word-boundary break */
                    for(int k=0;k<chunk;k++) fputc(p->url[u_pos+k],f);                            /* Print chunk */
                    for(int k=chunk;k<w_url;k++) fputc(' ',f);                                     /* Pad column */
                    u_pos+=chunk; while(u_pos<url_len&&p->url[u_pos]==' ') u_pos++;               /* Advance */
                } else fwrite_col(f,"",w_url);     /* URL exhausted: empty cell */
                fprintf(f," |\n");                  /* End continuation row */
            }
        }
    }
    ftbl_border(f,cw,nc);   /* Print bottom border */
}

/* ================================================================
   REPORT: write summary statistics block to file f (txt or html)
   ================================================================ */

/* Writes a plain-text summary statistics block to file f for the given publication subset:
   per-faculty publication counts, year-wise counts, and type-wise counts */
static void write_summary_txt(FILE *f, int *pub_idx, int n_pi)
{
    fprintf(f,"\n----------------------------------------------------------------\n");
    fprintf(f,"  SUMMARY STATISTICS\n");
    fprintf(f,"----------------------------------------------------------------\n");
    fprintf(f,"  Total Faculty         : %d\n",g_fac_count);
    fprintf(f,"  Total Publications    : %d\n\n",n_pi);

    /* Per-faculty */
    fprintf(f,"  Publications per Faculty:\n");
    {
        int w_sn=2,w_name=4,w_desi=11,w_cnt=12;   /* Initialize minimum column widths */
        for(int i=0;i<g_fac_count;i++){
            int n;
            n=(int)strlen(g_fac[i].sn);       if(n>w_sn)   w_sn=n;    /* Expand SN column if needed */
            n=(int)strlen(g_fac[i].full_name); if(n>w_name) w_name=n;  /* Expand Name column if needed */
            n=(int)strlen(g_fac[i].desi);      if(n>w_desi) w_desi=n;  /* Expand Designation column if needed */
        }
        int nc2=4; int cw2[]={w_sn,w_name,w_desi,w_cnt};
        const char *sh[]={"SN","Name","Designation","Publications"};
        ftbl_border(f,cw2,nc2); ftbl_row(f,sh,cw2,nc2); ftbl_border(f,cw2,nc2);
        for(int i=0;i<g_fac_count;i++){
            Faculty *m=&g_fac[i]; int cnt=0;
            for(int k=0;k<n_pi;k++){
                Publication *p=&g_pub[pub_idx[k]];
                for(int a=0;a<p->author_count;a++) if(str_ieq(p->authors[a],m->sn)){cnt++;break;}  /* Count pubs for this faculty in subset */
            }
            char cs[8]; sprintf(cs,"%d",cnt);
            const char *r[]={m->sn,m->full_name,m->desi,cs}; ftbl_row(f,r,cw2,nc2);
        }
        ftbl_border(f,cw2,nc2);
    }

    /* Year-wise */
    fprintf(f,"\n  Year-wise Count:\n");
    {
        char yrs[64][8]; int yrc[64]; int ny=0;
        for(int k=0;k<n_pi;k++){
            int fd=0; for(int y=0;y<ny;y++) if(strcmp(yrs[y],g_pub[pub_idx[k]].year)==0){yrc[y]++;fd=1;break;}
            if(!fd&&ny<64){strncpy(yrs[ny],g_pub[pub_idx[k]].year,7);yrs[ny][7]='\0';yrc[ny++]=1;}  /* Accumulate year counts */
        }
        for(int a=0;a<ny-1;a++) for(int b=a+1;b<ny;b++) if(strcmp(yrs[a],yrs[b])>0){
            char ty[8];strcpy(ty,yrs[a]);strcpy(yrs[a],yrs[b]);strcpy(yrs[b],ty);
            int tc=yrc[a];yrc[a]=yrc[b];yrc[b]=tc;}   /* Bubble sort years ascending */
        int nc2=2; int cw2[]={10,12};
        const char *sh[]={"Year","Count"};
        ftbl_border(f,cw2,nc2); ftbl_row(f,sh,cw2,nc2); ftbl_border(f,cw2,nc2);
        for(int y=0;y<ny;y++){char c[8];sprintf(c,"%d",yrc[y]);const char *r[]={yrs[y],c};ftbl_row(f,r,cw2,nc2);}
        ftbl_border(f,cw2,nc2);
    }

    /* Type-wise */
    fprintf(f,"\n  Type-wise Count:\n");
    {
        char tp[10][MAX_STR]; int tpc[10]; int nt=0;
        for(int k=0;k<n_pi;k++){
            int fd=0; for(int t=0;t<nt;t++) if(strcmp(tp[t],g_pub[pub_idx[k]].type)==0){tpc[t]++;fd=1;break;}
            if(!fd&&nt<10){SCOPY(tp[nt],g_pub[pub_idx[k]].type);tpc[nt++]=1;}  /* Accumulate type counts */
        }
        int nc2=2; int cw2[]={18,12};
        const char *sh[]={"Type","Count"};
        ftbl_border(f,cw2,nc2); ftbl_row(f,sh,cw2,nc2); ftbl_border(f,cw2,nc2);
        for(int t=0;t<nt;t++){char c[8];sprintf(c,"%d",tpc[t]);const char *r[]={tp[t],c};ftbl_row(f,r,cw2,nc2);}
        ftbl_border(f,cw2,nc2);
    }
}

/* Writes an HTML summary statistics section to file h for the given publication subset:
   per-faculty counts, year-wise table, and type-wise table */
static void write_summary_html(FILE *h, int *pub_idx, int n_pi)
{
    fprintf(h,"<h2>Summary Statistics</h2>\n");
    fprintf(h,"<p>Total Faculty: <strong>%d</strong> &nbsp; "
              "Total Publications: <strong>%d</strong></p>\n",g_fac_count,n_pi);

    fprintf(h,"<h3>Publications per Faculty</h3>\n");
    fprintf(h,"<table><thead><tr><th>SN</th><th>Name</th><th>Designation</th><th>Publications</th></tr></thead>\n<tbody>\n");
    for(int i=0;i<g_fac_count;i++){
        Faculty *m=&g_fac[i]; int cnt=0;
        for(int k=0;k<n_pi;k++){
            Publication *p=&g_pub[pub_idx[k]];
            for(int a=0;a<p->author_count;a++) if(str_ieq(p->authors[a],m->sn)){cnt++;break;}  /* Count pubs for this faculty in subset */
        }
        fprintf(h,"<tr><td>%s</td><td>%s</td><td>%s</td><td>%d</td></tr>\n",m->sn,m->full_name,m->desi,cnt);
    }
    fprintf(h,"</tbody></table>\n");

    /* Year-wise */
    {
        char yrs[64][8]; int yrc[64]; int ny=0;
        for(int k=0;k<n_pi;k++){
            int fd=0; for(int y=0;y<ny;y++) if(strcmp(yrs[y],g_pub[pub_idx[k]].year)==0){yrc[y]++;fd=1;break;}
            if(!fd&&ny<64){strncpy(yrs[ny],g_pub[pub_idx[k]].year,7);yrs[ny][7]='\0';yrc[ny++]=1;}  /* Accumulate year counts */
        }
        for(int a=0;a<ny-1;a++) for(int b=a+1;b<ny;b++) if(strcmp(yrs[a],yrs[b])>0){
            char ty[8];strcpy(ty,yrs[a]);strcpy(yrs[a],yrs[b]);strcpy(yrs[b],ty);
            int tc=yrc[a];yrc[a]=yrc[b];yrc[b]=tc;}   /* Bubble sort years ascending */
        fprintf(h,"<h3>Publications by Year</h3>\n<table><thead><tr><th>Year</th><th>Count</th></tr></thead>\n<tbody>\n");
        for(int y=0;y<ny;y++) fprintf(h,"<tr><td>%s</td><td>%d</td></tr>\n",yrs[y],yrc[y]);
        fprintf(h,"</tbody></table>\n");
    }

    /* Type-wise */
    {
        char tp[10][MAX_STR]; int tpc[10]; int nt=0;
        for(int k=0;k<n_pi;k++){
            int fd=0; for(int t=0;t<nt;t++) if(strcmp(tp[t],g_pub[pub_idx[k]].type)==0){tpc[t]++;fd=1;break;}
            if(!fd&&nt<10){SCOPY(tp[nt],g_pub[pub_idx[k]].type);tpc[nt++]=1;}  /* Accumulate type counts */
        }
        fprintf(h,"<h3>Publications by Type</h3>\n<table><thead><tr><th>Type</th><th>Count</th></tr></thead>\n<tbody>\n");
        for(int t=0;t<nt;t++) fprintf(h,"<tr><td>%s</td><td>%d</td></tr>\n",tp[t],tpc[t]);
        fprintf(h,"</tbody></table>\n");
    }
}

/* ================================================================
   SCREEN: GENERATE REPORT  (stays in loop until option 4)
   Produces TWO files per report: .txt (plain table) and .html (styled)
   ================================================================ */
/* Interactive report generator: lets user choose Annual, Accreditation, or Custom Filter report;
   collects filter parameters; writes matching .txt and .html report files to the reports/ directory */
static void screen_generate_report(void)
{
    while(1){
        clrscr(); section("GENERATE REPORT");
        printf("\n  Report types:\n");
        printf("    [1] Annual Departmental Report    (all publications for a chosen year)\n");
        printf("    [2] Accreditation Documentation   (all-time + designation breakdown)\n");
        printf("    [3] Custom Filter Report          (filter by RA / year / type)\n");
        printf("    [4] Exit Report Generation\n\n");

        char sel[4]="";
        while(1){
            prompt("Report type (1-4)",sel,sizeof(sel));
            if(strlen(sel)==1&&sel[0]>='1'&&sel[0]<='4') break;   /* Accept only 1-4 */
            printf("  [Error] Please enter 1, 2, 3, or 4.\n");
        }
        if(sel[0]=='4') return;   /* Exit report generation loop */
        int rtype=atoi(sel);      /* Convert selection to integer report type */

        /* Collect year/type/RA lists */
        char yrs[64][8]; int ny=0;
        for(int i=0;i<g_pub_count;i++){
            int f=0; for(int y=0;y<ny;y++) if(strcmp(yrs[y],g_pub[i].year)==0){f=1;break;}
            if(!f&&ny<64){strncpy(yrs[ny],g_pub[i].year,7);yrs[ny][7]='\0';ny++;}  /* Build unique years list */
        }
        for(int a=0;a<ny-1;a++) for(int b=a+1;b<ny;b++) if(strcmp(yrs[a],yrs[b])>0){char ty[8];strcpy(ty,yrs[a]);strcpy(yrs[a],yrs[b]);strcpy(yrs[b],ty);}  /* Sort years ascending */

        char tps[10][MAX_STR]; int nt=0;
        for(int i=0;i<g_pub_count;i++){int f=0;for(int t=0;t<nt;t++) if(strcmp(tps[t],g_pub[i].type)==0){f=1;break;}if(!f&&nt<10)SCOPY(tps[nt++],g_pub[i].type);}  /* Build unique types list */

        static char all_ra2[MAX_FACULTY*MAX_RA][MAX_STR];
        int n_ra2=0; memset(all_ra2,0,sizeof(all_ra2));
        for(int i=0;i<g_fac_count;i++)
            for(int r=0;r<g_fac[i].ra_count;r++){
                int dup=0; for(int x=0;x<n_ra2;x++) if(strcmp(all_ra2[x],g_fac[i].ra[r])==0){dup=1;break;}
                if(!dup&&n_ra2<MAX_FACULTY*MAX_RA){strncpy(all_ra2[n_ra2],g_fac[i].ra[r],MAX_STR-1);all_ra2[n_ra2][MAX_STR-1]='\0';n_ra2++;}  /* Build deduplicated RA list */
            }

        char selected_year[MAX_STR]="";   /* Year selection for rtype==1 */
        char filter_by[MAX_STR]="";       /* Filter dimension for rtype==3 */
        char filter_val[MAX_STR]="";      /* Filter value for rtype==3 */

        if(rtype==1){
            if(ny==0){printf("  No publications.\n");pause_enter();continue;}
            printf("\n  Available years:\n");
            for(int y=0;y<ny;y++) printf("    [%d] %s\n",y+1,yrs[y]);
            while(1){
                char yrsel[8]=""; prompt("Select year number",yrsel,sizeof(yrsel));
                int yi=atoi(yrsel)-1;
                if(yi>=0&&yi<ny){SCOPY(selected_year,yrs[yi]);break;}   /* Store selected year */
                printf("  [Error] Enter 1-%d.\n",ny);
            }
        } else if(rtype==3){
            printf("\n  Filter by (choose one):\n");
            printf("    [1] Research Area\n    [2] Year\n    [3] Publication Type\n    [0] No filter -- show all publications\n\n");
            char fsub[4]="";
            while(1){
                prompt("Filter choice (0-3)",fsub,sizeof(fsub));
                if(strlen(fsub)==1&&fsub[0]>='0'&&fsub[0]<='3') break;
                printf("  [Error] Enter 0, 1, 2, or 3.\n");
            }
            if(fsub[0]=='1'){
                SCOPY(filter_by,"research_area");
                if(n_ra2==0){printf("  No research areas.\n");pause_enter();continue;}
                printf("  Areas:\n");
                for(int r=0;r<n_ra2;r++) printf("    [%d] %s\n",r+1,all_ra2[r]);
                while(1){
                    char rs[8]=""; prompt("Select number",rs,sizeof(rs));
                    int ri=atoi(rs)-1;
                    if(ri>=0&&ri<n_ra2){SCOPY(filter_val,all_ra2[ri]);break;}   /* Store selected RA */
                    printf("  [Error] Enter 1-%d.\n",n_ra2);
                }
            } else if(fsub[0]=='2'){
                SCOPY(filter_by,"year");
                if(ny==0){printf("  No years.\n");pause_enter();continue;}
                printf("  Years:\n");
                for(int y=0;y<ny;y++) printf("    [%d] %s\n",y+1,yrs[y]);
                while(1){
                    char ys2[8]=""; prompt("Select number",ys2,sizeof(ys2));
                    int yi=atoi(ys2)-1;
                    if(yi>=0&&yi<ny){SCOPY(filter_val,yrs[yi]);break;}   /* Store selected year filter */
                    printf("  [Error] Enter 1-%d.\n",ny);
                }
            } else if(fsub[0]=='3'){
                SCOPY(filter_by,"pub_type");
                if(nt==0){printf("  No types.\n");pause_enter();continue;}
                printf("  Types:\n");
                for(int t=0;t<nt;t++) printf("    [%d] %s\n",t+1,tps[t]);
                while(1){
                    char ts2[8]=""; prompt("Select number",ts2,sizeof(ts2));
                    int ti=atoi(ts2)-1;
                    if(ti>=0&&ti<nt){SCOPY(filter_val,tps[ti]);break;}   /* Store selected type filter */
                    printf("  [Error] Enter 1-%d.\n",nt);
                }
            }
        }

        /* Build publication subset */
        int pub_idx[MAX_PUBS]; int n_pi=0;
        for(int i=0;i<g_pub_count;i++){
            int inc=0;
            if(rtype==1) inc=str_ieq(g_pub[i].year,selected_year);             /* Annual: match selected year */
            else if(rtype==2) inc=1;                                            /* Accreditation: include all */
            else{
                if(!filter_by[0]) inc=1;                                        /* No filter: include all */
                else if(str_ieq(filter_by,"year")) inc=str_ieq(g_pub[i].year,filter_val);   /* Filter by year */
                else if(str_ieq(filter_by,"pub_type")) inc=str_ieq(g_pub[i].type,filter_val); /* Filter by type */
                else if(str_ieq(filter_by,"research_area")){
                    for(int f=0;f<g_fac_count&&!inc;f++){
                        int fm=0;
                        for(int r=0;r<g_fac[f].ra_count&&!fm;r++) if(str_ieq(g_fac[f].ra[r],filter_val)) fm=1;  /* Faculty matches RA */
                        if(fm) for(int a=0;a<g_pub[i].author_count&&!inc;a++) if(str_ieq(g_pub[i].authors[a],g_fac[f].sn)) inc=1;  /* Pub authored by matching faculty */
                    }
                }
            }
            if(inc&&n_pi<MAX_PUBS) pub_idx[n_pi++]=i;   /* Add qualifying publication to subset */
        }

        /* Build base filename (without extension) */
        MKDIR(REPORTS_DIR);
        char ts_fn[MAX_STR]; now_str(ts_fn);
        for(int i=0;ts_fn[i];i++) if(ts_fn[i]==' '||ts_fn[i]==':'||ts_fn[i]=='-') ts_fn[i]='_';  /* Replace separators with underscores for filename */
        ts_fn[19]='\0';                                                                              /* Trim to date+time portion only */
        char base[MAX_TITLE*2];
        if(rtype==1)      snprintf(base,sizeof(base),"%s/annual_%s_%s",REPORTS_DIR,selected_year,ts_fn);   /* Annual report filename */
        else if(rtype==2) snprintf(base,sizeof(base),"%s/accreditation_%s",REPORTS_DIR,ts_fn);             /* Accreditation report filename */
        else              snprintf(base,sizeof(base),"%s/custom_%s",REPORTS_DIR,ts_fn);                    /* Custom report filename */

        char fname_txt[MAX_TITLE*2+8], fname_html[MAX_TITLE*2+8];
        snprintf(fname_txt, sizeof(fname_txt), "%s.txt",  base);    /* Full .txt output path */
        snprintf(fname_html,sizeof(fname_html),"%s.html", base);    /* Full .html output path */

        char ts_now[MAX_STR]; now_str(ts_now);                  /* Current timestamp for report header */
        char last_edit[MAX_STR]; get_last_edit_time(last_edit); /* Last database edit timestamp */

        /* ============================================================
           WRITE TXT REPORT
           ============================================================ */
        FILE *rep=fopen(fname_txt,"w");
        if(!rep){printf("  [Error] Cannot create TXT report.\n");pause_enter();continue;}

        fprintf(rep,"================================================================\n");
        fprintf(rep,"  Department of Mechanical Engineering, BUET\n");
        fprintf(rep,"  Research Publication Database System -- RPDS v6.0\n");
        fprintf(rep,"================================================================\n\n");
        if(rtype==1)      fprintf(rep,"  ANNUAL DEPARTMENTAL REPORT -- Year: %s\n\n  Generated: %s\n\n",selected_year,ts_now);
        else if(rtype==2) fprintf(rep,"  ACCREDITATION DOCUMENTATION\n\n  Generated: %s\n\n",ts_now);
        else{
            fprintf(rep,"  CUSTOM FILTER REPORT\n");
            if(filter_by[0]) fprintf(rep,"  Filter: %s = %s\n",filter_by,filter_val);  /* Show active filter */
            fprintf(rep,"  Generated: %s\n\n",ts_now);
        }

        if(rtype==2){
            fprintf(rep,"----------------------------------------------------------------\n");
            fprintf(rep,"  FACULTY BY DESIGNATION\n");
            fprintf(rep,"----------------------------------------------------------------\n");
            const char *ds2[]={"Professor","Associate Professor","Assistant Professor","Lecturer"};
            int dc2[4]={0,0,0,0};
            for(int i=0;i<g_fac_count;i++) for(int d=0;d<4;d++) if(strcmp(g_fac[i].desi,ds2[d])==0) dc2[d]++;  /* Count per designation */
            for(int d=0;d<4;d++) fprintf(rep,"  %-26s : %d\n",ds2[d],dc2[d]);
            fprintf(rep,"  %-26s : %d\n","TOTAL",g_fac_count);
            fprintf(rep,"\n");
            fprintf(rep,"----------------------------------------------------------------\n");
            fprintf(rep,"  ALL FACULTY  (Profile URL in separate column)\n");
            fprintf(rep,"----------------------------------------------------------------\n\n");
            txt_fac_table(rep);   /* Write faculty plain-text table */
            fprintf(rep,"\n");
        }

        fprintf(rep,"----------------------------------------------------------------\n");
        if(rtype==1) fprintf(rep,"  PUBLICATIONS IN %s  (%d record(s))  -- URL in separate column\n",selected_year,n_pi);
        else         fprintf(rep,"  PUBLICATIONS  (%d record(s))  -- URL in separate column\n",n_pi);
        fprintf(rep,"----------------------------------------------------------------\n\n");
        if(n_pi==0) fprintf(rep,"  No publications match the selected criteria.\n\n");
        else        txt_pub_table(rep,pub_idx,n_pi);   /* Write publications plain-text table */

        if(rtype==1||rtype==2) write_summary_txt(rep,pub_idx,n_pi);   /* Append summary statistics */

        fprintf(rep,"\n================================================================\n");
        fprintf(rep,"  Database last edited: %s\n",last_edit);
        fprintf(rep,"  End of Report\n");
        fprintf(rep,"================================================================\n");
        fclose(rep);

        /* ============================================================
           WRITE HTML REPORT
           ============================================================ */
        FILE *htm=fopen(fname_html,"w");
        if(!htm){printf("  [Error] Cannot create HTML report.\n");pause_enter();continue;}

        /* Determine title string */
        char htitle[MAX_STR*4];
        if(rtype==1)      snprintf(htitle,sizeof(htitle),"Annual Report %s",selected_year);
        else if(rtype==2) snprintf(htitle,sizeof(htitle),"Accreditation Documentation");
        else{
            if(filter_by[0]) snprintf(htitle,sizeof(htitle),"Custom Report: %s = %s",filter_by,filter_val);
            else              snprintf(htitle,sizeof(htitle),"Custom Report (All)");
        }

        fprintf(htm,"<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n");
        fprintf(htm,"<meta charset=\"UTF-8\">\n");
        fprintf(htm,"<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">\n");
        fprintf(htm,"<title>RPDS Report - %s</title>\n",htitle);
        /* Embedded CSS for the HTML report */
        fprintf(htm,"<style>\n"
"  body{font-family:Arial,Helvetica,sans-serif;margin:2em;color:#1a1a1a;background:#f9f9f9;}\n"
"  h1{color:#003366;border-bottom:3px solid #003366;padding-bottom:.4em;}\n"
"  h2{color:#003366;margin-top:1.8em;}\n"
"  h3{color:#005599;margin-top:1.2em;}\n"
"  .meta{color:#555;font-size:.9em;margin-bottom:1.5em;}\n"
"  table{border-collapse:collapse;width:100%%;margin:1em 0;font-size:.9em;}\n"
"  th{background:#003366;color:#fff;padding:8px 10px;text-align:left;white-space:nowrap;}\n"
"  td{padding:6px 10px;border-bottom:1px solid #ddd;vertical-align:top;}\n"
"  tr:nth-child(even){background:#f2f7ff;}\n"
"  tr:hover{background:#ddeeff;}\n"
"  a{color:#0055aa;text-decoration:none;}\n"
"  a:hover{text-decoration:underline;}\n"
"  .stat-block{background:#eef3ff;border-left:4px solid #003366;padding:.8em 1.2em;margin:1em 0;}\n"
"  @media print{body{background:#fff;}th{-webkit-print-color-adjust:exact;}}\n"
"</style>\n</head>\n<body>\n");

        fprintf(htm,"<h1>Department of Mechanical Engineering, BUET</h1>\n");
        fprintf(htm,"<h2>%s</h2>\n",htitle);
        fprintf(htm,"<p class=\"meta\">Generated: %s &nbsp;|&nbsp; Database last edited: %s</p>\n",ts_now,last_edit);

        if(rtype==2){
            fprintf(htm,"<h2>Faculty by Designation</h2>\n");
            const char *ds2[]={"Professor","Associate Professor","Assistant Professor","Lecturer"};
            int dc2[4]={0,0,0,0};
            for(int i=0;i<g_fac_count;i++) for(int d=0;d<4;d++) if(strcmp(g_fac[i].desi,ds2[d])==0) dc2[d]++;  /* Count per designation */
            fprintf(htm,"<table><thead><tr><th>Designation</th><th>Count</th></tr></thead>\n<tbody>\n");
            for(int d=0;d<4;d++) fprintf(htm,"<tr><td>%s</td><td>%d</td></tr>\n",ds2[d],dc2[d]);
            fprintf(htm,"<tr><td><strong>TOTAL</strong></td><td><strong>%d</strong></td></tr>\n",g_fac_count);
            fprintf(htm,"</tbody></table>\n");

            fprintf(htm,"<h2>All Faculty</h2>\n<p><em>Faculty names link to their profile pages.</em></p>\n");
            html_fac_table(htm);   /* Write HTML faculty table */
        }

        if(rtype==1) fprintf(htm,"<h2>Publications in %s (%d record(s))</h2>\n",selected_year,n_pi);
        else         fprintf(htm,"<h2>Publications (%d record(s))</h2>\n",n_pi);
        fprintf(htm,"<p><em>Publication titles link to their DOI / URL.</em></p>\n");
        if(n_pi==0) fprintf(htm,"<p>No publications match the selected criteria.</p>\n");
        else        html_pub_table(htm,pub_idx,n_pi);   /* Write HTML publications table */

        if(rtype==1||rtype==2) write_summary_html(htm,pub_idx,n_pi);   /* Append HTML summary statistics */

        fprintf(htm,"</body>\n</html>\n");
        fclose(htm);

        printf("\n  [OK] Reports saved:\n");
        printf("       TXT : %s\n", fname_txt);
        printf("       HTML: %s\n", fname_html);
        pause_enter();
    }
}

/* ================================================================
   SCREEN: ACTIVITY LOG
   ================================================================ */
/* Reads the history file and displays all log entries in reverse chronological order */
static void screen_history(void)
{
    clrscr(); section("ACTIVITY LOG");
    FILE *f=fopen(HISTORY_FILE,"r");
    if(!f){printf("\n  No activity logged yet.\n");pause_enter();return;}  /* No log file yet */
    char lines[MAX_HIST][MAX_TITLE]; int cnt=0;
    while(cnt<MAX_HIST&&fgets(lines[cnt],MAX_TITLE,f)){
        int n=(int)strlen(lines[cnt]);
        while(n>0&&(lines[cnt][n-1]=='\n'||lines[cnt][n-1]=='\r')) lines[cnt][--n]='\0';  /* Strip line endings */
        cnt++;
    }
    fclose(f);
    if(!cnt){printf("\n  Log empty.\n");pause_enter();return;}
    printf("\n");
    for(int i=cnt-1;i>=0;i--) printf("  %s\n",lines[i]);   /* Print in reverse order (newest first) */
    printf("\n  Total: %d entries\n",cnt);
    pause_enter();
}

/* ================================================================
   SCREEN: UNDO
   ================================================================ */
/* Prompts for 'yes' confirmation then restores the last undo snapshot; logs the action */
static void screen_undo(void)
{
    clrscr(); section("UNDO LAST CHANGE");
    printf("\n  Restores faculty and publications to state before last change.\n\n");
    char cf[16]=""; prompt("Type 'yes' to confirm",cf,sizeof(cf));
    if(strcmp(cf,"yes")!=0){printf("  Cancelled.\n");pause_enter();return;}   /* User cancelled */
    if(restore_undo_snapshot()){
        log_action(g_admin,"UNDO","Restored previous snapshot");
        printf("\n  [OK] Last change has been undone.\n");
    } else {
        printf("\n  [Error] No undo snapshot found.\n");
    }
    pause_enter();
}

/* ================================================================
   MAIN MENU
   ================================================================ */

/* Renders the main menu to stdout; shows admin-only options if logged in */
static void show_menu(int admin)
{
    hr2();
    printf("  Research Publication Database System \n");
    printf("  Department of Mechanical Engineering, BUET\n");
    hr2(); printf("\n");
    if(admin) printf("  Logged in as: %s\n\n",g_admin);   /* Show logged-in admin ID */

    printf("  ---- View / Search ----\n");
    printf("    [1] View All Faculty\n");
    printf("    [2] View All Publications\n");
    printf("    [3] Search\n");
    printf("    [4] System Overview\n");
    printf("    [5] Generate Report\n");

    if(admin){
        printf("\n  ---- Admin ----\n");
        printf("    [6] Add Faculty\n");
        printf("    [7] Edit Faculty\n");
        printf("    [8] Delete Faculty\n");
        printf("    [9] Add Publication\n");
        printf("    [A] Edit Publication\n");
        printf("    [B] Delete Publication\n");
        printf("    [C] Undo Last Change\n");
        printf("    [D] Activity Log\n");
        printf("    [E] Logout\n");
    } else {
        printf("\n    [6] Admin Login\n");   /* Guest users only see login option */
    }
    printf("\n    [0] Exit\n\n");
    hr();
}

/* Main interactive loop: displays the menu, reads single-character selections, and dispatches to screen functions;
   enforces admin login requirement for protected operations */
static void main_menu(void)
{
    char sel[8];
    while(1){
        clrscr();
        show_menu(logged_in());          /* Render menu according to login state */
        prompt("Choice",sel,sizeof(sel));

        /* Exact single-character matching -- reject "AQ" etc. */
        if(strlen(sel)!=1){
            printf("  [Error] Invalid choice.\n");
            pause_enter(); continue;
        }

        char c=(char)toupper((unsigned char)sel[0]);   /* Normalize to uppercase for matching */

        if(c=='0') break;   /* Exit the application */

        switch(c){
            case '1': screen_view_faculty(); break;
            case '2': screen_view_pubs();    break;
            case '3': screen_search();       break;
            case '4': screen_overview();     break;
            case '5': screen_generate_report(); break;
            case '6':
                if(logged_in()) screen_add_faculty();   /* Admin: add faculty */
                else            screen_login();         /* Guest: prompt login */
                break;
            case '7': if(logged_in()) screen_edit_faculty();   else{printf("  [Error] Admin login required.\n");pause_enter();}break;
            case '8': if(logged_in()) screen_delete_faculty(); else{printf("  [Error] Admin login required.\n");pause_enter();}break;
            case '9': if(logged_in()) screen_add_pub();        else{printf("  [Error] Admin login required.\n");pause_enter();}break;
            case 'A': if(logged_in()) screen_edit_pub();       else{printf("  [Error] Admin login required.\n");pause_enter();}break;
            case 'B': if(logged_in()) screen_delete_pub();     else{printf("  [Error] Admin login required.\n");pause_enter();}break;
            case 'C': if(logged_in()) screen_undo();           else{printf("  [Error] Admin login required.\n");pause_enter();}break;
            case 'D': if(logged_in()) screen_history();        else{printf("  [Error] Admin login required.\n");pause_enter();}break;
            case 'E': if(logged_in()) screen_logout(); break;
            default:
                printf("  [Error] Invalid choice '%c'. Please try again.\n",c);
                pause_enter();
                break;
        }
    }
    pause_any_key();   /* Wait for keypress before exiting the program */
}

/* ================================================================
   ENTRY POINT
   ================================================================ */
int main(void)
{
    enable_ansi();       /* Enable ANSI escape codes for colored/formatted terminal output */
    MKDIR(REPORTS_DIR);  /* Create the reports output directory if it doesn't already exist */
    load_faculty();      /* Load faculty data from faculty.txt into global array g_fac[] */
    load_pubs();         /* Load publications data from publications.txt into global array g_pub[] */

    /* Friendly startup notice if no data files found yet */
    if(g_fac_count==0 && g_pub_count==0){        /* Check if both faculty and publication data are empty */
        FILE *tf=fopen(FACULTY_FILE,"r");         /* Try to open the faculty file to verify it exists */
        if(!tf){                                  /* If faculty file couldn't be opened (doesn't exist) */
            printf("\n  NOTE: No data files found in the current directory.\n");          /* Notify user no data files were found */
            printf("  Place faculty.txt and publications.txt next to rpds.exe\n");        /* Instruct where to place data files */
            printf("  and re-run, OR use the Admin menu to add records.\n\n");            /* Offer alternative: use Admin menu */
            printf("  Press Enter to continue...");                                        /* Prompt user to acknowledge the notice */
            fflush(stdout);                                                                /* Flush output buffer to ensure message displays immediately */
            int _c; while((_c=getchar())!='\n'&&_c!=EOF);  /* Wait for user to press Enter, consuming all input until newline or EOF */
        } else {
            fclose(tf);   /* File exists but data is empty; close the handle cleanly, no notice needed */
        }
    }

    main_menu();   /* Launch the main interactive menu loop of the application */
    return 0;      /* Exit program with success code */
}
